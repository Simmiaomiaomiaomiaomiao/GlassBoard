using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

namespace GlassBoard;

public class Controller
{
	private sealed class ColorOwner : System.Windows.Forms.IWin32Window
	{
		public IntPtr Handle { get; private set; }

		public ColorOwner(Window w)
		{
			Handle = new WindowInteropHelper(w).Handle;
		}
	}

	public readonly SystemBridge Systems = new SystemBridge();

	private ControlOrbWindow controlOrb;

	private WidgetManager widgets;

	private bool removalMigrated;

	private bool glassSuppressed;

	public Preferences Prefs;

	public DockWindow Dock;

	public BoardWindow Board;

	public NotifyIcon Tray;

	private bool importing;

	public bool ShuttingDown;

	private readonly bool persistConfiguration;

	private bool settingsOpen;

	private Window settingsWindow;

	private System.Windows.Controls.TabControl settingsTabs;

	private readonly BoardEditHistory editHistory = new BoardEditHistory();

	private UpdateOffer updateOffer;

	private bool updateBusy;

	private CancellationTokenSource updateCancel;

	private string updateMessage = "尚未检查更新。";

	public bool MusicVisible
	{
		get
		{
			if (widgets != null)
			{
				return widgets.MusicVisible;
			}
			return false;
		}
	}

	public bool UiBusy
	{
		get
		{
			if (!settingsOpen)
			{
				return Board.ModalBusy;
			}
			return true;
		}
	}

	private Window OwnerWindow
	{
		get
		{
			if (!Board.IsVisible)
			{
				return Dock;
			}
			return Board;
		}
	}

	public string WidgetStatus
	{
		get
		{
			if (widgets != null)
			{
				return widgets.LastError;
			}
			return "";
		}
	}

	public bool GlassSuppressed => glassSuppressed;

	public bool CanUndoRemoval => editHistory.CanUndo;

	public bool CanRedoBoard => editHistory.CanRedo;

	public string UndoLabel => editHistory.UndoLabel;

	private static Version CurrentVersion => Assembly.GetExecutingAssembly().GetName().Version;

	private event Action UpdateChanged;

	public void CreateBoardFile(string extension, string group)
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			string text3;
			if (extension == null)
			{
				string text = FeatureUi.PickFolder(OwnerWindow, "选择新文件夹的保存位置");
				if (text == null)
				{
					return;
				}
				string text2 = FeatureUi.Ask(OwnerWindow, "新文件夹名称");
				if (text2 == null)
				{
					return;
				}
				text3 = BoardFiles.CreateFolder(text, text2);
			}
			else
			{
				Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
				{
					Title = "新建文件并添加到当前分组",
					FileName = "新建文档" + extension,
					DefaultExt = extension,
					AddExtension = true,
					Filter = "所选格式 (*" + extension + ")|*" + extension,
					InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal)
				};
				if (saveFileDialog.ShowDialog(OwnerWindow) != true)
				{
					return;
				}
				text3 = saveFileDialog.FileName;
				BoardFiles.Create(text3);
			}
			Add(new string[1] { text3 }, manual: true, (group == "全部") ? "未分组" : group);
			Board.ClearSearch();
			Board.SetStatus("已新建：" + Path.GetFileName(text3) + " · 点击打开；移除入口不会删除原文件");
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(OwnerWindow, ex.Message, "新建失败");
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void SaveSession()
	{
		try
		{
			Store.Save(Prefs);
			if (widgets != null)
			{
				widgets.Notes.Flush();
			}
			Store.Trace("SESSION_END entries=" + Prefs.Apps.Count);
		}
		catch (Exception ex)
		{
			Store.Log(ex);
		}
	}

	public void RefreshControlCenter()
	{
		if (ShuttingDown)
		{
			return;
		}
		ControlCenterOptions controlCenter = Prefs.ControlCenter;
		controlCenter.Normalize();
		if (!controlCenter.Enabled)
		{
			if (controlOrb != null)
			{
				controlOrb.Close();
				controlOrb = null;
			}
			return;
		}
		if (controlOrb == null)
		{
			controlOrb = new ControlOrbWindow(this);
		}
		controlOrb.Sync();
		if (GlassSuppressed)
		{
			controlOrb.HideAll();
		}
		else if (!controlOrb.IsVisible)
		{
			controlOrb.Show();
		}
	}

	public void OpenControlCenter()
	{
		Prefs.ControlCenter.Enabled = true;
		RefreshControlCenter();
		Save();
		if (controlOrb != null && !GlassSuppressed)
		{
			controlOrb.OpenPanel();
		}
	}

	private void CloseControlCenter()
	{
		if (controlOrb != null)
		{
			controlOrb.Close();
			controlOrb = null;
		}
		Systems.Dispose();
	}

	private void ControlCenterVisibility(bool visible)
	{
		if (controlOrb != null)
		{
			if (visible && Prefs.ControlCenter.Enabled)
			{
				controlOrb.Show();
			}
			else
			{
				controlOrb.HideAll();
			}
		}
	}

	public void ControlCenterSettings(Window owner)
	{
		Window w = FeatureUi.Dialog("控制中心 · 小球外观", owner, 460.0, 700.0);
		StackPanel root = new StackPanel
		{
			Margin = new Thickness(24.0)
		};
		w.Content = new ScrollViewer
		{
			Content = root
		};
		ControlCenterOptions o = Prefs.ControlCenter;
		Action apply = delegate
		{
			o.Normalize();
			RefreshControlCenter();
			Save();
		};
		Action<string, bool, Action<bool>> obj = delegate(string name, bool value, Action<bool> set)
		{
			System.Windows.Controls.CheckBox b = new System.Windows.Controls.CheckBox
			{
				Content = name,
				IsChecked = value,
				Margin = new Thickness(0.0, 8.0, 0.0, 8.0)
			};
			root.Children.Add(b);
			b.Click += delegate
			{
				set(b.IsChecked == true);
				apply();
			};
		};
		obj("开启控制中心小球", o.Enabled, delegate(bool v)
		{
			o.Enabled = v;
		});
		obj("锁定小球位置", o.Locked, delegate(bool v)
		{
			o.Locked = v;
		});
		obj("始终悬浮在其他软件上方", o.Topmost, delegate(bool v)
		{
			o.Topmost = v;
		});
		obj("展开动画", o.Motion, delegate(bool v)
		{
			o.Motion = v;
		});
		Action<string, double, double, double, Action<double>> obj2 = delegate(string name, double min, double max, double value, Action<double> set)
		{
			TextBlock valueLabel = new TextBlock
			{
				Text = name + " · " + value.ToString("0"),
				Margin = new Thickness(0.0, 12.0, 0.0, 7.0)
			};
			root.Children.Add(valueLabel);
			Slider slider = new Slider
			{
				Minimum = min,
				Maximum = max,
				Value = value,
				TickFrequency = 1.0,
				IsSnapToTickEnabled = true
			};
			root.Children.Add(slider);
			slider.ValueChanged += delegate
			{
				valueLabel.Text = name + " · " + slider.Value.ToString("0");
				set(slider.Value);
				apply();
			};
		};
		obj2("悬浮小球大小", 36.0, 100.0, o.Size, delegate(double v)
		{
			o.Size = v;
		});
		obj2("球内图标大小（受小球边界限制）", 12.0, 72.0, o.IconSize, delegate(double v)
		{
			o.IconSize = v;
		});
		obj2("面板图标大小", 12.0, 36.0, o.PanelIconSize, delegate(double v)
		{
			o.PanelIconSize = v;
		});
		root.Children.Add(new TextBlock
		{
			Text = "悬浮图标样式",
			Margin = new Thickness(0.0, 12.0, 0.0, 7.0)
		});
		System.Windows.Controls.ComboBox iconStyle = new System.Windows.Controls.ComboBox
		{
			ItemsSource = ControlIconRules.Names,
			SelectedIndex = Array.IndexOf(ControlIconRules.Styles, ControlIconRules.Style(o.IconStyle)),
			MinHeight = 36.0
		};
		root.Children.Add(iconStyle);
		iconStyle.SelectionChanged += delegate
		{
			if (iconStyle.SelectedIndex >= 0)
			{
				o.IconStyle = ControlIconRules.Styles[iconStyle.SelectedIndex];
				apply();
			}
		};
		obj2("玻璃不透明度", 15.0, 100.0, o.Opacity, delegate(double v)
		{
			o.Opacity = v;
		});
		root.Children.Add(new TextBlock
		{
			Text = "点缀颜色（例如 #A9C9FF）",
			Margin = new Thickness(0.0, 16.0, 0.0, 8.0)
		});
		System.Windows.Controls.TextBox color = new System.Windows.Controls.TextBox
		{
			Text = o.Color,
			MinHeight = 34.0
		};
		root.Children.Add(color);
		root.Children.Add(FeatureUi.Button("应用颜色", delegate
		{
			try
			{
				if (string.IsNullOrEmpty(WidgetStyle.Color(color.Text)))
				{
					throw new ArgumentException();
				}
				o.Color = WidgetStyle.Color(color.Text);
				apply();
			}
			catch
			{
				System.Windows.MessageBox.Show(w, "请输入有效颜色，例如 #A9C9FF。");
			}
		}));
		root.Children.Add(FeatureUi.Button("恢复默认位置", delegate
		{
			o.Left = (o.Top = null);
			apply();
		}));
		root.Children.Add(new TextBlock
		{
			Text = "单击展开，拖动小球移动，右键打开设置。关闭后可从系统托盘重新开启。",
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
		});
		w.ShowDialog();
	}

	public void RefreshWidgets()
	{
		RefreshControlCenter();
		if (widgets == null)
		{
			widgets = new WidgetManager(this);
		}
		widgets.Sync();
	}

	public void SetWidgetEnabled(string kind, bool value)
	{
		if (widgets == null)
		{
			widgets = new WidgetManager(this);
		}
		widgets.Enable(kind, value);
	}

	public void RecoverWidgets()
	{
		try
		{
			if (File.Exists(Store.FileName))
			{
				File.Copy(Store.FileName, Store.FileName + ".before-widget-recovery-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff"), overwrite: false);
			}
			WidgetRules.Recover(Prefs.Widgets);
			Save();
			Store.Trace("RECOVER enable all widgets, preserve contents and layout");
			ReopenWidgets();
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(ex.Message, "组件恢复失败");
		}
	}

	public void ReopenWidgets()
	{
		if (widgets == null)
		{
			widgets = new WidgetManager(this);
		}
		widgets.Reopen();
		if (!string.IsNullOrEmpty(widgets.LastError))
		{
			System.Windows.MessageBox.Show(widgets.LastError + "\n详细记录位于配置文件夹 error.log。", "组件打开失败");
		}
	}

	public void CloseWidgets()
	{
		if (widgets != null)
		{
			widgets.Dispose();
			widgets = null;
		}
	}

	public void ConfigureWidgets()
	{
		Settings(3);
	}

	public void AddFolder()
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			string text = FeatureUi.PickFolder(OwnerWindow, "选择要放入玻璃板的文件夹（添加文件夹本身）");
			if (text != null)
			{
				Add(new string[1] { text });
				Board.ClearSearch();
				Board.SetStatus("已添加文件夹入口 · 点击打开，右键可固定到 Dock");
			}
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void ShowNotes()
	{
		Prefs.Widgets.Notes = true;
		RefreshWidgets();
		Save();
	}

	public async void ToggleTaskbarAutoHide(bool? enabled = null)
	{
		try
		{
			bool flag = enabled ?? (!TaskbarAutoHide.Enabled);
			if (flag)
			{
				DesktopVisibility.SetHidden(taskbar: true, hide: false);
			}
			TaskbarAutoHide.Set(flag);
			Board.SetStatus("已请求" + (flag ? "启用" : "关闭") + " Windows 任务栏自动隐藏");
			await Task.Delay(250);
			if (System.Windows.Application.Current != null && !System.Windows.Application.Current.Dispatcher.HasShutdownStarted)
			{
				Dock.Refresh();
			}
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(ex.Message, "Windows 任务栏自动隐藏");
		}
	}

	public void Customize(Entry entry)
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("名称与图标", OwnerWindow, 500.0, 280.0);
			StackPanel stackPanel = new StackPanel
			{
				Margin = new Thickness(22.0)
			};
			w.Content = stackPanel;
			stackPanel.Children.Add(new TextBlock
			{
				Text = "显示名称",
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			});
			System.Windows.Controls.TextBox name = new System.Windows.Controls.TextBox
			{
				Text = entry.Name,
				MinHeight = 38.0
			};
			stackPanel.Children.Add(name);
			string icon = entry.IconPath;
			TextBlock info = new TextBlock
			{
				Text = (string.IsNullOrWhiteSpace(icon) ? "使用软件原图标" : "已使用自定义图标"),
				Margin = new Thickness(0.0, 12.0, 0.0, 12.0)
			};
			stackPanel.Children.Add(info);
			WrapPanel wrapPanel = new WrapPanel();
			stackPanel.Children.Add(wrapPanel);
			wrapPanel.Children.Add(FeatureUi.Button("选择图标", delegate
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Filter = "图标图片|*.png;*.ico;*.jpg;*.jpeg;*.bmp"
				};
				if (openFileDialog.ShowDialog(w) == true)
				{
					try
					{
						icon = FeatureUi.StoreIcon(openFileDialog.FileName);
						info.Text = "已选择图标，点击保存应用";
					}
					catch (Exception ex)
					{
						System.Windows.MessageBox.Show(w, ex.Message, "无法读取图标");
					}
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("恢复原图标", delegate
			{
				icon = null;
				info.Text = "使用软件原图标";
			}));
			stackPanel.Children.Add(FeatureUi.Button("保存", delegate
			{
				if (!string.IsNullOrWhiteSpace(name.Text))
				{
					BoardEditState before = BeginBoardEdit();
					entry.Name = name.Text.Trim();
					entry.IconPath = icon;
					EndBoardEdit(before, "自定义名称与图标");
					Refresh();
					w.Close();
				}
			}));
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void AddExistingToGroup(string group)
	{
		if (group == "全部")
		{
			return;
		}
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("添加已有图标到「" + group + "」", Board, 680.0, 620.0);
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(22.0)
			};
			w.Content = dockPanel;
			StackPanel stackPanel = new StackPanel();
			DockPanel.SetDock(stackPanel, System.Windows.Controls.Dock.Top);
			dockPanel.Children.Add(stackPanel);
			stackPanel.Children.Add(new TextBlock
			{
				Text = "同一软件可以出现在多个分组",
				FontSize = 18.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			});
			stackPanel.Children.Add(new TextBlock
			{
				Text = ((group == "未分组") ? "选择后会移回未分组。" : "添加后保留原有分组；全部视图只显示一次。"),
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
			});
			System.Windows.Controls.TextBox query = new System.Windows.Controls.TextBox
			{
				MinHeight = 38.0,
				ToolTip = "搜索已有软件",
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			stackPanel.Children.Add(query);
			WrapPanel wrapPanel = new WrapPanel();
			DockPanel.SetDock(wrapPanel, System.Windows.Controls.Dock.Bottom);
			dockPanel.Children.Add(wrapPanel);
			System.Windows.Controls.ListBox list = new System.Windows.Controls.ListBox
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			dockPanel.Children.Add(list);
			List<Entry> candidates = Prefs.Apps.Where((Entry a) => !FeatureRules.InGroup(a, group)).ToList();
			HashSet<string> selected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			Action fill = delegate
			{
				list.Items.Clear();
				foreach (Entry item in candidates.Where((Entry a) => LayoutRules.Matches(a.Name, query.Text.Trim())))
				{
					Entry entry = item;
					System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
					{
						Content = entry.Name + "  ·  " + string.Join(" / ", FeatureRules.Memberships(entry)),
						IsChecked = selected.Contains(entry.Path),
						Margin = new Thickness(7.0),
						ToolTip = entry.Path
					};
					checkBox.Checked += delegate
					{
						selected.Add(entry.Path);
					};
					checkBox.Unchecked += delegate
					{
						selected.Remove(entry.Path);
					};
					list.Items.Add(checkBox);
				}
			};
			query.TextChanged += delegate
			{
				fill();
			};
			wrapPanel.Children.Add(FeatureUi.Button("全选结果", delegate
			{
				foreach (Entry item2 in candidates.Where((Entry a) => LayoutRules.Matches(a.Name, query.Text.Trim())))
				{
					selected.Add(item2.Path);
				}
				fill();
			}));
			wrapPanel.Children.Add(FeatureUi.Button("取消全选", delegate
			{
				selected.Clear();
				fill();
			}));
			wrapPanel.Children.Add(FeatureUi.Button("添加到本组", delegate
			{
				BoardEditState before = BeginBoardEdit();
				int num = FeatureRules.AddShared(Prefs, selected, group);
				EndBoardEdit(before, "添加已有图标");
				Refresh();
				Board.ClearSearch();
				Board.SetStatus("已添加 " + num + " 个已有图标到「" + group + "」");
				w.Close();
			}));
			wrapPanel.Children.Add(FeatureUi.Button("关闭", delegate
			{
				w.Close();
			}));
			fill();
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void AutoGroupApps(Window owner = null)
	{
		BoardEditState before = BeginBoardEdit();
		AutoGroupRules.ReloadCatalog();
		foreach (Entry item in Prefs.Apps.Where((Entry a) => FeatureRules.GroupName(a) == "未分组"))
		{
			LaunchInfoService.Enrich(item);
		}
		int num = AutoGroupRules.ApplyUnassigned(Prefs);
		EndBoardEdit(before, "自动分组");
		Refresh();
		int num2 = Prefs.Apps.Count((Entry a) => FeatureRules.GroupName(a) == "未分组");
		System.Windows.MessageBox.Show(owner ?? OwnerWindow, "已自动分组 " + num + " 个软件。\n还有 " + num2 + " 个未识别，可手动移动到分组。已有手动分组已保留。", "GlassBoard");
	}

	public void ManageGroups(Window owner = null)
	{
		Board.ClearDragState();
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("软件分组", owner ?? OwnerWindow, 520.0, 450.0);
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(22.0)
			};
			w.Content = dockPanel;
			WrapPanel wrapPanel = new WrapPanel();
			DockPanel.SetDock(wrapPanel, System.Windows.Controls.Dock.Bottom);
			dockPanel.Children.Add(wrapPanel);
			System.Windows.Controls.ListBox list = new System.Windows.Controls.ListBox
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
			};
			dockPanel.Children.Add(list);
			Action reload = delegate
			{
				string text = list.SelectedItem as string;
				list.ItemsSource = null;
				list.ItemsSource = Prefs.Groups.ToList();
				if (text != null)
				{
					list.SelectedItem = text;
				}
			};
			reload();
			wrapPanel.Children.Add(FeatureUi.Button("新增", delegate
			{
				string name = FeatureUi.Ask(w, "新分组名称");
				if (name != null)
				{
					if (name == "全部" || name == "未分组" || name.Length > 32 || Prefs.Groups.Any((string g) => g.Equals(name, StringComparison.CurrentCultureIgnoreCase)))
					{
						System.Windows.MessageBox.Show(w, "名称重复、过长或属于内置分类。");
					}
					else
					{
						BoardEditState before = BeginBoardEdit();
						Prefs.Groups.Add(name);
						EndBoardEdit(before, "新增分组");
						Refresh();
						reload();
					}
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("改名", delegate
			{
				if (list.SelectedItem is string text)
				{
					string text2 = FeatureUi.Ask(w, "分组改名", text);
					if (text2 != null)
					{
						try
						{
							if (text2.Length > 32)
							{
								throw new ArgumentException("名称最多 32 个字");
							}
							BoardEditState before = BeginBoardEdit();
							FeatureRules.RenameGroup(Prefs, text, text2);
							EndBoardEdit(before, "重命名分组");
							Refresh();
							reload();
						}
						catch (Exception ex)
						{
							System.Windows.MessageBox.Show(w, ex.Message);
						}
					}
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("删除分组", delegate
			{
				if (list.SelectedItem is string text && System.Windows.MessageBox.Show(w, "删除分组「" + text + "」？入口保留并移到未分组。", "GlassBoard", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
				{
					BoardEditState before = BeginBoardEdit();
					FeatureRules.DeleteGroup(Prefs, text);
					EndBoardEdit(before, "删除分组");
					Refresh();
					reload();
				}
			}));
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void ManageWorkspaces(Window owner = null)
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("工作区 · 一次打开一组工具", owner ?? OwnerWindow, 780.0, 640.0);
			Grid grid = new Grid
			{
				Margin = new Thickness(22.0)
			};
			w.Content = grid;
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			grid.RowDefinitions.Add(new RowDefinition());
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			StackPanel stackPanel = new StackPanel();
			grid.Children.Add(stackPanel);
			stackPanel.Children.Add(new TextBlock
			{
				Text = "把应用、素材文件夹和项目文件组成一个工作区",
				FontSize = 17.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			});
			System.Windows.Controls.TextBox name = new System.Windows.Controls.TextBox
			{
				Text = "创作工作区",
				MinHeight = 38.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			stackPanel.Children.Add(name);
			Grid grid2 = new Grid();
			grid2.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(190.0)
			});
			grid2.ColumnDefinitions.Add(new ColumnDefinition());
			Grid.SetRow(grid2, 1);
			grid.Children.Add(grid2);
			System.Windows.Controls.ListBox saved = new System.Windows.Controls.ListBox
			{
				Margin = new Thickness(0.0, 0.0, 12.0, 12.0),
				DisplayMemberPath = "Name"
			};
			grid2.Children.Add(saved);
			System.Windows.Controls.ListBox choices = new System.Windows.Controls.ListBox
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			Grid.SetColumn(choices, 1);
			grid2.Children.Add(choices);
			Dictionary<string, System.Windows.Controls.CheckBox> picked = new Dictionary<string, System.Windows.Controls.CheckBox>(StringComparer.OrdinalIgnoreCase);
			Workspace current = null;
			Action<IEnumerable<string>> fill = delegate(IEnumerable<string> paths)
			{
				HashSet<string> hashSet = new HashSet<string>(paths, StringComparer.OrdinalIgnoreCase);
				choices.Items.Clear();
				picked.Clear();
				foreach (Entry item in Prefs.Apps.Concat(from path in hashSet
					where !Prefs.Apps.Any((Entry a) => a.Path.Equals(path, StringComparison.OrdinalIgnoreCase))
					select new Entry
					{
						Name = Path.GetFileNameWithoutExtension(path),
						Path = path
					}).ToList())
				{
					System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
					{
						Content = item.Name,
						ToolTip = item.Path,
						IsChecked = hashSet.Contains(item.Path),
						Margin = new Thickness(5.0)
					};
					picked[item.Path] = checkBox;
					choices.Items.Add(checkBox);
				}
			};
			Action reload = delegate
			{
				saved.ItemsSource = null;
				saved.ItemsSource = Prefs.Workspaces.ToList();
			};
			reload();
			fill(new string[0]);
			saved.SelectionChanged += delegate
			{
				current = saved.SelectedItem as Workspace;
				if (current != null)
				{
					name.Text = current.Name;
					fill(current.Paths);
				}
			};
			WrapPanel wrapPanel = new WrapPanel();
			Grid.SetRow(wrapPanel, 2);
			grid.Children.Add(wrapPanel);
			wrapPanel.Children.Add(FeatureUi.Button("新建", delegate
			{
				saved.SelectedItem = null;
				current = null;
				name.Text = "新工作区";
				fill(new string[0]);
			}));
			wrapPanel.Children.Add(FeatureUi.Button("全选", delegate
			{
				foreach (System.Windows.Controls.CheckBox value in picked.Values)
				{
					value.IsChecked = true;
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("取消全选", delegate
			{
				foreach (System.Windows.Controls.CheckBox value2 in picked.Values)
				{
					value2.IsChecked = false;
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("保存工作区", delegate
			{
				string title = name.Text.Trim();
				List<string> list = (from x in picked
					where x.Value.IsChecked == true
					select x.Key).ToList();
				if (title.Length == 0 || list.Count == 0)
				{
					System.Windows.MessageBox.Show(w, "填写名称并勾选至少一个入口。");
				}
				else if (Prefs.Workspaces.Any((Workspace x) => x != current && x.Name.Equals(title, StringComparison.CurrentCultureIgnoreCase)))
				{
					System.Windows.MessageBox.Show(w, "工作区名称已存在。");
				}
				else
				{
					if (current == null)
					{
						current = new Workspace();
						Prefs.Workspaces.Add(current);
					}
					current.Name = title;
					current.Paths = list;
					Save();
					RefreshTrayMenu();
					Workspace selectedItem = current;
					reload();
					saved.SelectedItem = selectedItem;
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("打开已选", delegate
			{
				Workspace work = new Workspace
				{
					Name = name.Text,
					Paths = (from x in picked
						where x.Value.IsChecked == true
						select x.Key).ToList()
				};
				w.Close();
				LaunchWorkspace(work);
			}));
			wrapPanel.Children.Add(FeatureUi.Button("删除工作区", delegate
			{
				if (current != null)
				{
					Prefs.Workspaces.Remove(current);
					current = null;
					Save();
					RefreshTrayMenu();
					reload();
					fill(new string[0]);
				}
			}));
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public async void LaunchWorkspace(Workspace work)
	{
		work.Normalize();
		Board.CollapseSmooth();
		RunningWindows.Scan();
		List<string> failures = new List<string>();
		foreach (string path in work.Paths)
		{
			if (System.Windows.Application.Current == null || System.Windows.Application.Current.Dispatcher.HasShutdownStarted)
			{
				return;
			}
			try
			{
				if (!RunningWindows.IsRunning(Prefs.Apps.FirstOrDefault((Entry a) => a.Path.Equals(path, StringComparison.OrdinalIgnoreCase)) ?? new Entry
				{
					Path = path,
					Name = Path.GetFileNameWithoutExtension(path)
				}))
				{
					Process.Start(new ProcessStartInfo(path)
					{
						UseShellExecute = true
					});
				}
			}
			catch
			{
				failures.Add(Path.GetFileName(path));
			}
			await Task.Delay(150);
		}
		if (failures.Count > 0)
		{
			System.Windows.MessageBox.Show("这些入口无法打开：\n" + string.Join("\n", failures), work.Name);
		}
	}

	public bool ManageSchemes(Window owner = null)
	{
		bool applied = false;
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("外观方案", owner ?? OwnerWindow, 650.0, 480.0);
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(22.0)
			};
			w.Content = dockPanel;
			TextBlock element = new TextBlock
			{
				Text = "保存配色、尺寸、位置、图标和应用布局；切换保留后来新增的入口。",
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			DockPanel.SetDock(element, System.Windows.Controls.Dock.Top);
			dockPanel.Children.Add(element);
			WrapPanel wrapPanel = new WrapPanel();
			DockPanel.SetDock(wrapPanel, System.Windows.Controls.Dock.Bottom);
			dockPanel.Children.Add(wrapPanel);
			System.Windows.Controls.ListBox list = new System.Windows.Controls.ListBox
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 14.0),
				DisplayMemberPath = "Name"
			};
			dockPanel.Children.Add(list);
			Dictionary<AppearanceScheme, string> files = new Dictionary<AppearanceScheme, string>();
			Action reload = delegate
			{
				files.Clear();
				string[] array = SchemeStore.Files();
				foreach (string text in array)
				{
					try
					{
						AppearanceScheme key = SchemeStore.Load(text);
						files[key] = text;
					}
					catch
					{
					}
				}
				list.ItemsSource = null;
				list.ItemsSource = files.Keys.OrderBy((AppearanceScheme s) => s.Name).ToList();
			};
			reload();
			wrapPanel.Children.Add(FeatureUi.Button("保存当前", delegate
			{
				string text = FeatureUi.Ask(w, "方案名称");
				if (text != null)
				{
					AppearanceScheme data = FeatureRules.Capture(Prefs, text);
					SchemeStore.Embed(data);
					SchemeStore.Save(data, Path.Combine(SchemeStore.Folder, Guid.NewGuid().ToString("N") + ".json"));
					reload();
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("应用方案", delegate
			{
				if (!(list.SelectedItem is AppearanceScheme key))
				{
					return;
				}
				try
				{
					AppearanceScheme appearanceScheme = SchemeStore.Load(files[key]);
					SchemeStore.Materialize(appearanceScheme);
					FeatureRules.Apply(Prefs, appearanceScheme);
					editHistory.Clear();
					applied = true;
					Refresh();
					RefreshTrayMenu();
					Board.Hide();
					w.Close();
				}
				catch (Exception ex)
				{
					System.Windows.MessageBox.Show(w, ex.Message, "无法应用方案");
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("导出", delegate
			{
				if (list.SelectedItem is AppearanceScheme key)
				{
					Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
					{
						FileName = "GlassBoard_外观方案.json",
						Filter = "外观方案|*.json"
					};
					if (saveFileDialog.ShowDialog(w) == true)
					{
						File.Copy(files[key], saveFileDialog.FileName, overwrite: true);
					}
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("导入", delegate
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Filter = "外观方案|*.json"
				};
				if (openFileDialog.ShowDialog(w) != true)
				{
					return;
				}
				try
				{
					SchemeStore.Save(SchemeStore.Load(openFileDialog.FileName), Path.Combine(SchemeStore.Folder, Guid.NewGuid().ToString("N") + ".json"));
					reload();
				}
				catch (Exception ex)
				{
					System.Windows.MessageBox.Show(w, ex.Message, "无法导入方案");
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("删除方案", delegate
			{
				if (list.SelectedItem is AppearanceScheme key && System.Windows.MessageBox.Show(w, "删除保存的方案？当前外观保持。", "GlassBoard", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
				{
					File.Delete(files[key]);
					reload();
				}
			}));
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
		if (applied && settingsWindow != null && owner != settingsWindow)
		{
			settingsWindow.Close();
		}
		return applied;
	}

	public bool ReorderDock(string path, string target, bool before)
	{
		BoardEditState before2 = BeginBoardEdit();
		if (!Dock.MoveLayout(path, target, before))
		{
			return false;
		}
		EndBoardEdit(before2, "调整 Dock 顺序");
		Dock.Refresh(capture: false);
		Board.Render();
		return true;
	}

	public void StepDock(string path, int step)
	{
		BoardEditState before = BeginBoardEdit();
		if (Dock.StepLayout(path, step))
		{
			EndBoardEdit(before, "调整 Dock 顺序");
			Dock.Refresh(capture: false);
			Board.Render();
		}
	}

	private void AddDockWindowMenus(System.Windows.Controls.ContextMenu menu, Entry entry)
	{
		if (entry.IsFolder || Directory.Exists(entry.Path))
		{
			return;
		}
		System.Windows.Controls.MenuItem opened = new System.Windows.Controls.MenuItem
		{
			Header = "切换已打开的窗口"
		};
		System.Windows.Controls.MenuItem associate = new System.Windows.Controls.MenuItem
		{
			Header = "关联正在运行的窗口",
			ToolTip = "用于游戏、特殊启动器或无法自动识别的软件；关联后点击切回该软件"
		};
		menu.Items.Add(opened);
		menu.Items.Add(associate);
		menu.Opened += delegate
		{
			RunningWindows.Scan();
			opened.Items.Clear();
			associate.Items.Clear();
			List<RunningWindow> list = RunningWindows.For(entry);
			opened.IsEnabled = list.Count > 0;
			foreach (RunningWindow item in list)
			{
				RunningWindow selected = item;
				System.Windows.Controls.MenuItem menuItem = new System.Windows.Controls.MenuItem
				{
					Header = WindowLabel(selected),
					ToolTip = selected.Title
				};
				menuItem.Click += delegate
				{
					RunningWindows.ActivateHandle(selected.Handle);
				};
				opened.Items.Add(menuItem);
			}
			List<RunningWindow> list2 = RunningWindows.Snapshot();
			associate.IsEnabled = list2.Count > 0 || !string.IsNullOrEmpty(entry.WindowTarget);
			foreach (RunningWindow item2 in list2)
			{
				RunningWindow selected2 = item2;
				System.Windows.Controls.MenuItem menuItem2 = new System.Windows.Controls.MenuItem
				{
					Header = WindowLabel(selected2),
					ToolTip = selected2.Path,
					IsCheckable = true,
					IsChecked = string.Equals(entry.WindowTarget, selected2.Path, StringComparison.OrdinalIgnoreCase)
				};
				menuItem2.Click += delegate
				{
					BoardEditState before = BeginBoardEdit();
					entry.WindowTarget = selected2.Path;
					EndBoardEdit(before, "关联 Dock 窗口");
					Refresh();
				};
				associate.Items.Add(menuItem2);
			}
			if (!string.IsNullOrEmpty(entry.WindowTarget))
			{
				associate.Items.Add(new Separator());
				System.Windows.Controls.MenuItem menuItem3 = new System.Windows.Controls.MenuItem
				{
					Header = "取消手动关联"
				};
				menuItem3.Click += delegate
				{
					BoardEditState before = BeginBoardEdit();
					entry.WindowTarget = null;
					EndBoardEdit(before, "取消 Dock 窗口关联");
					Refresh();
				};
				associate.Items.Add(menuItem3);
			}
		};
	}

	private static string WindowLabel(RunningWindow window)
	{
		string text = (string.IsNullOrWhiteSpace(window.Title) ? Path.GetFileNameWithoutExtension(window.Path) : window.Title);
		if (text.Length <= 72)
		{
			return text;
		}
		return text.Substring(0, 69) + "…";
	}

	public DockPinResult PinDockPaths(IEnumerable<string> paths, DockDropTarget target)
	{
		List<Entry> list = new List<Entry>();
		foreach (string item in paths.Distinct(StringComparer.OrdinalIgnoreCase))
		{
			if (string.IsNullOrWhiteSpace(item))
			{
				continue;
			}
			string path = EntryPathRules.Normalize(item);
			Entry entry = Prefs.Apps.FirstOrDefault((Entry a) => string.Equals(a.Path, path, StringComparison.OrdinalIgnoreCase));
			if (entry == null)
			{
				if (!File.Exists(path) && !Directory.Exists(path))
				{
					continue;
				}
				entry = new Entry
				{
					Name = EntryPathRules.Name(path),
					Path = path,
					IsFolder = Directory.Exists(path)
				};
				LaunchInfoService.Enrich(entry);
			}
			if (string.IsNullOrEmpty(entry.LaunchTarget) && File.Exists(entry.Path))
			{
				LaunchInfoService.Enrich(entry);
			}
			list.Add(entry);
		}
		BoardEditState before = BeginBoardEdit();
		DockPinResult dockPinResult = DockPinRules.Apply(Prefs, list, target);
		DockLayoutRules.SyncApps(Prefs);
		if (target != null)
		{
			IEnumerable<string> enumerable;
			if (!target.Before)
			{
				enumerable = dockPinResult.Paths.AsEnumerable().Reverse();
			}
			else
			{
				IEnumerable<string> paths2 = dockPinResult.Paths;
				enumerable = paths2;
			}
			foreach (string item2 in enumerable)
			{
				DockLayoutRules.Move(Prefs, item2, target.Path, target.Before);
			}
		}
		EndBoardEdit(before, "拖入 Dock 固定");
		Dock.Refresh(capture: false);
		Board.Render();
		Board.SetStatus((dockPinResult.Paths.Count == 0) ? "未添加入口" : ("已放入 Dock " + dockPinResult.Paths.Count + " 个 · Ctrl+Z 撤销" + ((dockPinResult.Skipped > 0) ? ("；已达 20 个上限，跳过 " + dockPinResult.Skipped + " 个") : "")));
		return dockPinResult;
	}

	private void MigrateRemovalIdentities()
	{
		if (removalMigrated)
		{
			return;
		}
		removalMigrated = true;
		foreach (Entry item in Prefs.Apps.Where((Entry a) => string.IsNullOrWhiteSpace(a.LaunchTarget)))
		{
			try
			{
				LaunchInfoService.Enrich(item);
			}
			catch
			{
			}
		}
		foreach (string path in Prefs.Removed.ToList())
		{
			if (Prefs.Apps.Any((Entry a) => string.Equals(a.Path, path, StringComparison.OrdinalIgnoreCase)) || (!File.Exists(path) && !Directory.Exists(path)))
			{
				continue;
			}
			try
			{
				Entry removed = LaunchInfoService.Read(path);
				if (!Prefs.Apps.Any((Entry a) => RemovalRules.Same(a, removed)))
				{
					RemovalRules.Remember(Prefs, removed);
				}
			}
			catch
			{
			}
		}
		RemovalRules.ReconcileActive(Prefs);
		Save();
	}

	public void ChooseDockFiles()
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
			{
				Title = "添加软件或文件到 Dock",
				Multiselect = true,
				Filter = "所有文件|*.*"
			};
			if (openFileDialog.ShowDialog(OwnerWindow) != true)
			{
				return;
			}
			Add(openFileDialog.FileNames, manual: true, "全部");
			BoardEditState before = BeginBoardEdit();
			string[] fileNames = openFileDialog.FileNames;
			foreach (string path in fileNames)
			{
				Entry entry = Prefs.Apps.FirstOrDefault((Entry a) => string.Equals(a.Path, EntryPathRules.Normalize(path), StringComparison.OrdinalIgnoreCase));
				if (entry != null && !entry.Pinned && Prefs.Apps.Count((Entry a) => a.Pinned) < 20)
				{
					entry.Pinned = true;
				}
			}
			EndBoardEdit(before, "添加到 Dock");
			Refresh();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void SetGameMode(bool enabled)
	{
		Prefs.GameMode = enabled;
		Save();
		ApplyGameMode();
		RefreshTrayMenu();
	}

	public void CheckGameMode()
	{
		if (Prefs.AutoGameMode || Prefs.GameMode || glassSuppressed)
		{
			ApplyGameMode();
		}
	}

	public void ApplyGameMode()
	{
		Dock.GamePolling(Prefs.AutoGameMode);
		bool flag = GameModeRules.Suppressed(Prefs.GameMode, Prefs.AutoGameMode, Prefs.AutoGameMode && FullscreenState.Active(), desktop: false);
		if (flag == glassSuppressed)
		{
			return;
		}
		glassSuppressed = flag;
		ControlCenterVisibility(!flag);
		if (flag)
		{
			Board.Hide();
			SetProcessWorkingSetSize(GetCurrentProcess(), (IntPtr)(-1), (IntPtr)(-1));
			Dock.Hide();
			if (widgets != null)
			{
				widgets.SetVisible(visible: false);
			}
		}
		else
		{
			Dock.Refresh(capture: false);
			Dock.Show();
			if (widgets != null)
			{
				widgets.SetVisible(visible: true);
			}
		}
		if (Tray != null)
		{
			RefreshTrayMenu();
		}
	}

	private void BuildGameSettings(StackPanel panel)
	{
		panel.Children.Add(new TextBlock
		{
			Text = "游戏模式",
			FontSize = 18.0,
			Margin = new Thickness(0.0, 22.0, 0.0, 10.0)
		});
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = "游戏模式：隐藏 Dock、大面板和小组件",
			IsChecked = Prefs.GameMode,
			Margin = new Thickness(0.0, 6.0, 0.0, 8.0)
		};
		panel.Children.Add(checkBox);
		checkBox.Checked += delegate
		{
			SetGameMode(enabled: true);
		};
		checkBox.Unchecked += delegate
		{
			SetGameMode(enabled: false);
		};
		System.Windows.Controls.CheckBox checkBox2 = new System.Windows.Controls.CheckBox
		{
			Content = "检测全屏应用时自动进入（默认关闭）",
			IsChecked = Prefs.AutoGameMode,
			Margin = new Thickness(0.0, 6.0, 0.0, 8.0)
		};
		panel.Children.Add(checkBox2);
		checkBox2.Checked += delegate
		{
			Prefs.AutoGameMode = true;
			Save();
			ApplyGameMode();
		};
		checkBox2.Unchecked += delegate
		{
			Prefs.AutoGameMode = false;
			Save();
			ApplyGameMode();
		};
		panel.Children.Add(new TextBlock
		{
			Text = "游戏模式期间玻璃窗口完全隐藏，避免触碰底边误唤醒。右键系统托盘可退出；自动模式离开全屏后恢复 Dock 和组件。组件配置不关闭或清空。\n提示：手动开关与自动检测请二选一，同时开启时手动开关会让 Dock 一直隐藏。",
			TextWrapping = TextWrapping.Wrap
		});
	}

	public Controller()
		: this(desktop: true)
	{
	}

	internal Controller(bool desktop)
	{
		persistConfiguration = desktop;
		if (!desktop)
		{
			Prefs = new Preferences();
			Board = new BoardWindow(this);
			Dock = new DockWindow(this);
			return;
		}
		Prefs = Store.Load();
		if (!string.IsNullOrEmpty(Store.RecoveryMessage))
		{
			System.Windows.MessageBox.Show(Store.RecoveryMessage, "GlassBoard 配置恢复");
		}
		if (Prefs.Removed.Count > 0 || Prefs.RemovedIdentities.Count > 0)
		{
			MigrateRemovalIdentities();
		}
		Board = new BoardWindow(this);
		Dock = new DockWindow(this);
		glassSuppressed = Prefs.GameMode || (Prefs.AutoGameMode && FullscreenState.Active());
		Tray = new NotifyIcon
		{
			Text = "GlassBoard v0.9.17 · 玻璃启动台",
			Icon = (Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location) ?? SystemIcons.Application),
			Visible = true
		};
		RefreshTrayMenu();
		Tray.DoubleClick += delegate
		{
			Toggle(force: true);
		};
		Dock.Refresh();
		if (!GlassSuppressed)
		{
			Dock.Show();
		}
		if (Prefs.HotkeyMigrationConflict)
		{
			Tray.ShowBalloonTip(4500, "快捷键升级提示", "原有组合与 Ctrl+Alt+H 冲突，已保留原设置并关闭新增项。可在设置中录制新组合。", ToolTipIcon.Info);
			Save();
		}
		RefreshWidgets();
		if (!Prefs.Imported)
		{
			Toggle(force: true);
			Import();
		}
		StartUpdateCheck();
		ApplyGameMode();
		IdleTrim.Start(ReleaseIdleCaches, null);
	}

	private void ReleaseIdleCaches()
	{
		try
		{
			FeatureUi.ReleaseCustomIcons();
		}
		catch
		{
		}
		try
		{
			widgets?.Music?.ReleaseArtworkCache();
		}
		catch
		{
		}
	}

	private string Shortcut(int id)
	{
		return HotkeyRules.Label(Prefs.Hotkeys.First((HotkeySetting k) => k.ActionId == id));
	}

	public void RefreshTrayMenu()
	{
		ContextMenuStrip contextMenuStrip = Tray.ContextMenuStrip;
		ContextMenuStrip contextMenuStrip2 = new ContextMenuStrip();
		contextMenuStrip2.Items.Add("打开应用面板   " + Shortcut(1), null, delegate
		{
			Toggle(force: true);
		});
		contextMenuStrip2.Items.Add(Prefs.GameMode ? "退出游戏模式" : "进入游戏模式", null, delegate
		{
			SetGameMode(!Prefs.GameMode);
		});
		if (Prefs.AutoGameMode)
		{
			contextMenuStrip2.Items.Add("暂停自动游戏模式", null, delegate
			{
				Prefs.AutoGameMode = false;
				Prefs.GameMode = false;
				Save();
				ApplyGameMode();
				RefreshTrayMenu();
			});
		}
		contextMenuStrip2.Items.Add("添加软件   " + Shortcut(4), null, delegate
		{
			AddFromAnywhere();
		});
		contextMenuStrip2.Items.Add("导入开始菜单应用", null, delegate
		{
			Import();
		});
		contextMenuStrip2.Items.Add("外观与快捷键   " + Shortcut(5), null, delegate
		{
			Settings();
		});
		contextMenuStrip2.Items.Add("隐藏 / 显示任务栏   " + Shortcut(2), null, delegate
		{
			ShellAction(1);
		});
		contextMenuStrip2.Items.Add("隐藏 / 显示桌面图标   " + Shortcut(3), null, delegate
		{
			ShellAction(2);
		});
		contextMenuStrip2.Items.Add("恢复任务栏与桌面图标   " + Shortcut(6), null, delegate
		{
			ShellAction(3);
		});
		contextMenuStrip2.Items.Add("Windows 任务栏自动隐藏   " + Shortcut(7), null, delegate
		{
			ToggleTaskbarAutoHide();
		});
		contextMenuStrip2.Items.Add("打开控制中心", null, delegate
		{
			OpenControlCenter();
		});
		contextMenuStrip2.Items.Add("控制中心小球设置", null, delegate
		{
			ControlCenterSettings(null);
		});
		contextMenuStrip2.Items.Add("备忘录记事板", null, delegate
		{
			ShowNotes();
		});
		contextMenuStrip2.Items.Add("组件布局", null, delegate
		{
			ConfigureWidgets();
		});
		contextMenuStrip2.Items.Add("恢复并开启全部组件", null, delegate
		{
			RecoverWidgets();
		});
		string[] kinds = WidgetRules.Kinds;
		foreach (string text in kinds)
		{
			string kind = text;
			contextMenuStrip2.Items.Add("开启组件 · " + WidgetRules.Names[Array.IndexOf(WidgetRules.Kinds, kind)], null, delegate
			{
				SetWidgetEnabled(kind, value: true);
			});
		}
		contextMenuStrip2.Items.Add("工作区管理", null, delegate
		{
			ManageWorkspaces();
		});
		foreach (Workspace workspace2 in Prefs.Workspaces)
		{
			Workspace workspace = workspace2;
			contextMenuStrip2.Items.Add("打开工作区 · " + workspace.Name, null, delegate
			{
				LaunchWorkspace(workspace);
			});
		}
		contextMenuStrip2.Items.Add("外观方案", null, delegate
		{
			ManageSchemes();
		});
		contextMenuStrip2.Items.Add("打开配置文件夹", null, delegate
		{
			Process.Start(new ProcessStartInfo(Store.Folder)
			{
				UseShellExecute = true
			});
		});
		contextMenuStrip2.Items.Add(new ToolStripSeparator());
		contextMenuStrip2.Items.Add("退出 GlassBoard", null, delegate
		{
			Quit();
		});
		Tray.ContextMenuStrip = contextMenuStrip2;
		contextMenuStrip?.Dispose();
	}

	public void Save()
	{
		if (!persistConfiguration)
		{
			return;
		}
		try
		{
			DockOrderRules.Normalize(Prefs);
			Store.Save(Prefs);
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show("布局保存失败：" + ex.Message, "GlassBoard");
		}
	}

	public void Refresh()
	{
		Save();
		Dock.Refresh();
		Board.SyncGroups();
		Board.Render();
		RefreshWidgets();
	}

	public void Toggle(bool force = false)
	{
		if (!GlassSuppressed)
		{
			if (Board.IsVisible && !force)
			{
				Board.CollapseSmooth();
			}
			else
			{
				Board.Open();
			}
		}
	}

	public void Launch(Entry entry)
	{
		try
		{
			if (entry.IsFolder || Directory.Exists(entry.Path) || !RunningWindows.Activate(entry))
			{
				Process.Start(new ProcessStartInfo(entry.Path)
				{
					UseShellExecute = true
				});
			}
			Board.CollapseSmooth();
		}
		catch (Exception ex)
		{
			System.Windows.MessageBox.Show("无法打开「" + entry.Name + "」。\n入口可能已移动或卸载。\n\n" + ex.Message, "GlassBoard");
		}
	}

	public void Add(IEnumerable<string> paths, bool manual = true, string targetGroup = null)
	{
		if (manual && targetGroup == null && Board.IsVisible)
		{
			targetGroup = Board.CurrentGroup;
		}
		if (!manual)
		{
			MigrateRemovalIdentities();
		}
		BoardEditState before = BeginBoardEdit();
		int num = 0;
		foreach (string path2 in paths)
		{
			string path = EntryPathRules.Normalize(path2);
			if ((!File.Exists(path) && !Directory.Exists(path)) || !LayoutRules.AllowImport(path, Prefs.Removed, manual))
			{
				continue;
			}
			Entry entry = Prefs.Apps.FirstOrDefault((Entry a) => string.Equals(EntryPathRules.Normalize(a.Path), path, StringComparison.OrdinalIgnoreCase));
			if (entry != null)
			{
				if (manual && targetGroup != null && targetGroup != "全部")
				{
					num += FeatureRules.AddShared(Prefs, new string[1] { entry.Path }, targetGroup);
				}
				continue;
			}
			Entry entry2 = new Entry
			{
				Name = EntryPathRules.Name(path),
				Path = path,
				IsFolder = Directory.Exists(path)
			};
			LaunchInfoService.Enrich(entry2);
			if (manual || (LaunchInfoService.Primary(entry2) && !RemovalRules.Blocked(Prefs, entry2) && !Prefs.Apps.Any((Entry a) => RemovalRules.Same(a, entry2))))
			{
				if (manual)
				{
					RemovalRules.Forget(Prefs, entry2);
				}
				entry2.Group = FeatureRules.ImportGroup(Prefs, entry2, manual ? targetGroup : null);
				Prefs.Apps.Add(entry2);
				num++;
			}
		}
		if (num > 0)
		{
			EndBoardEdit(before, "添加入口");
			Refresh();
		}
	}

	public void Choose()
	{
		Board.ModalBusy = true;
		try
		{
			new BatchAddWindow(this).ShowDialog();
		}
		finally
		{
			Board.ModalBusy = false;
		}
	}

	public void AddFromAnywhere()
	{
		Toggle(force: true);
		Choose();
	}

	public void Opacity(double percent)
	{
		Prefs.OpacityPercent = LayoutRules.GlassOpacity(percent);
		Board.SetGlassOpacity(Prefs.OpacityPercent.Value);
	}

	public void Remove(Entry a, string scope = null)
	{
		RemoveMany(new string[1] { a.Path }, scope);
	}

	public void RemoveMany(IEnumerable<string> paths, string scope = null)
	{
		string group = scope ?? (Board.IsVisible ? Board.CurrentGroup : "全部");
		HashSet<string> targets = new HashSet<string>(paths, StringComparer.OrdinalIgnoreCase);
		targets.RemoveWhere((string path) => !Prefs.Apps.Any((Entry a) => string.Equals(a.Path, path, StringComparison.OrdinalIgnoreCase) && FeatureRules.InGroup(a, group)));
		int num = Prefs.Apps.Count((Entry a) => targets.Contains(a.Path));
		if (num == 0)
		{
			return;
		}
		Board.ModalBusy = true;
		try
		{
			string messageBoxText = "从「" + group + "」移除已选的 " + num + " 个入口？\n" + ((group == "全部") ? "本次从所有分组与 Dock 移除，原软件和磁盘文件保留。" : "同一软件在其他组中的入口保留；原软件和磁盘文件保留。") + "\n移除后可点击「撤销」。";
			if ((Board.IsVisible ? System.Windows.MessageBox.Show(Board, messageBoxText, "GlassBoard", MessageBoxButton.YesNo) : System.Windows.MessageBox.Show(messageBoxText, "GlassBoard", MessageBoxButton.YesNo)) != MessageBoxResult.Yes)
			{
				return;
			}
			foreach (Entry item in Prefs.Apps.Where((Entry a) => targets.Contains(a.Path)))
			{
				LaunchInfoService.Enrich(item);
			}
			BoardEditState before = BeginBoardEdit();
			EntryRules.Remove(Prefs, targets, group);
			EndBoardEdit(before, "移除入口");
			Board.FinishSelection();
			Refresh();
			Board.SetStatus("已移除 " + num + " 个入口 · 可撤销本次移除");
		}
		finally
		{
			Board.ModalBusy = false;
		}
	}

	public void UndoRemoval()
	{
		UndoBoard();
	}

	public void Pin(Entry a)
	{
		if (!a.Pinned && Prefs.Apps.Count((Entry x) => x.Pinned) >= 20)
		{
			System.Windows.MessageBox.Show("最多固定 20 个入口。请先取消一个固定。", "GlassBoard");
			return;
		}
		BoardEditState before = BeginBoardEdit();
		a.Pinned = !a.Pinned;
		EndBoardEdit(before, "调整 Dock 固定");
		Refresh();
	}

	private static IEnumerable<string> Shortcuts(string root)
	{
		if (!Directory.Exists(root))
		{
			yield break;
		}
		Stack<string> pending = new Stack<string>();
		pending.Push(root);
		int count = 0;
		while (pending.Count > 0 && count < 2500)
		{
			string path = pending.Pop();
			string[] files;
			string[] dirs;
			try
			{
				files = Directory.GetFiles(path);
				dirs = Directory.GetDirectories(path);
			}
			catch
			{
				continue;
			}
			string[] array = files;
			foreach (string text in array)
			{
				switch (Path.GetExtension(text).ToLowerInvariant())
				{
				case ".lnk":
				case ".appref-ms":
				case ".url":
					if (StartupEntryRules.Candidate(text))
					{
						count++;
						yield return text;
					}
					break;
				}
			}
			string[] array2 = dirs;
			foreach (string text2 in array2)
			{
				try
				{
					if ((File.GetAttributes(text2) & FileAttributes.ReparsePoint) == 0)
					{
						pending.Push(text2);
					}
				}
				catch
				{
				}
			}
		}
	}

	public async void Import()
	{
		if (importing)
		{
			return;
		}
		importing = true;
		Board.SetStatus("正在读取开始菜单…");
		try
		{
			string[] paths = await Task.Run(() => Shortcuts(Environment.GetFolderPath(Environment.SpecialFolder.Programs)).Concat(Shortcuts(Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms))).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy((string p) => Path.GetFileNameWithoutExtension(p), StringComparer.CurrentCultureIgnoreCase)
				.ToArray());
			if (ShuttingDown)
			{
				return;
			}
			int count = Prefs.Apps.Count;
			Add(paths, manual: false);
			Prefs.Imported = true;
			if (!Prefs.Apps.Any((Entry a) => a.Pinned))
			{
				string[] common = new string[12]
				{
					"edge", "chrome", "firefox", "微信", "wechat", "qq", "steam", "blender", "maya", "剪映",
					"capcut", "code"
				};
				foreach (Entry item in Prefs.Apps.Where((Entry a) => common.Any((string k) => a.Name.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0)).Take(7))
				{
					item.Pinned = true;
				}
			}
			Refresh();
			Board.SetStatus("已导入 " + (Prefs.Apps.Count - count) + " 个入口 · 可拖入其他软件");
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			Board.SetStatus("导入失败，可使用右上角添加");
		}
		finally
		{
			importing = false;
		}
	}

	public System.Windows.Controls.ContextMenu Menu(Entry a, string scope = "全部")
	{
		System.Windows.Controls.ContextMenu menu = MenuTheme.Create(Prefs.Light);
		Action<string, Action> action = delegate(string title, Action action2)
		{
			System.Windows.Controls.MenuItem menuItem3 = new System.Windows.Controls.MenuItem
			{
				Header = title
			};
			menuItem3.Click += delegate
			{
				action2();
			};
			menu.Items.Add(menuItem3);
		};
		action("打开", delegate
		{
			Launch(a);
		});
		action("打开文件所在位置", delegate
		{
			try
			{
				FileShellActions.Location(a);
			}
			catch (Exception ex)
			{
				System.Windows.MessageBox.Show(ex.Message, "GlassBoard");
			}
		});
		action("文件属性", delegate
		{
			try
			{
				FileShellActions.Properties(a.Path);
			}
			catch (Exception ex)
			{
				System.Windows.MessageBox.Show(ex.Message, "GlassBoard");
			}
		});
		action(a.Pinned ? "取消 Dock 固定" : "固定到 Dock", delegate
		{
			Pin(a);
		});
		if (scope == "Dock")
		{
			action("添加软件或文件到 Dock", delegate
			{
				ChooseDockFiles();
			});
			AddDockWindowMenus(menu, a);
		}
		else
		{
			action("前移一位", delegate
			{
				int num = Prefs.Apps.IndexOf(a);
				if (num > 0)
				{
					Prefs.Apps.RemoveAt(num);
					Prefs.Apps.Insert(num - 1, a);
					Refresh();
				}
			});
			action("后移一位", delegate
			{
				int num = Prefs.Apps.IndexOf(a);
				if (num < Prefs.Apps.Count - 1)
				{
					Prefs.Apps.RemoveAt(num);
					Prefs.Apps.Insert(num + 1, a);
					Refresh();
				}
			});
		}
		action("修改名称与图标", delegate
		{
			Customize(a);
		});
		System.Windows.Controls.MenuItem menuItem = new System.Windows.Controls.MenuItem
		{
			Header = "移动到分组"
		};
		foreach (string item in new string[1] { "未分组" }.Concat(Prefs.Groups))
		{
			string name = item;
			System.Windows.Controls.MenuItem menuItem2 = new System.Windows.Controls.MenuItem
			{
				Header = name
			};
			menuItem2.Click += delegate
			{
				TransferEntries(new string[1] { a.Path }, (scope == "Dock") ? "全部" : scope, name);
			};
			menuItem.Items.Add(menuItem2);
		}
		menu.Items.Add(menuItem);
		action("移除入口", delegate
		{
			Remove(a, (scope == "Dock") ? "全部" : scope);
		});
		return menu;
	}

	internal static ToggleButton VisibilitySwitch()
	{
		ToggleButton obj = new ToggleButton
		{
			Width = 50.0,
			Height = 26.0,
			Cursor = System.Windows.Input.Cursors.Hand,
			VerticalAlignment = VerticalAlignment.Center
		};
		FrameworkElementFactory frameworkElementFactory = new FrameworkElementFactory(typeof(Border));
		frameworkElementFactory.Name = "Track";
		frameworkElementFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(13.0));
		frameworkElementFactory.SetValue(Border.BackgroundProperty, new SolidColorBrush(System.Windows.Media.Color.FromRgb(83, 87, 99)));
		FrameworkElementFactory frameworkElementFactory2 = new FrameworkElementFactory(typeof(Border));
		frameworkElementFactory2.Name = "Thumb";
		frameworkElementFactory2.SetValue(FrameworkElement.WidthProperty, 20.0);
		frameworkElementFactory2.SetValue(FrameworkElement.HeightProperty, 20.0);
		frameworkElementFactory2.SetValue(FrameworkElement.MarginProperty, new Thickness(3.0));
		frameworkElementFactory2.SetValue(FrameworkElement.HorizontalAlignmentProperty, System.Windows.HorizontalAlignment.Left);
		frameworkElementFactory2.SetValue(Border.CornerRadiusProperty, new CornerRadius(10.0));
		frameworkElementFactory2.SetValue(Border.BackgroundProperty, System.Windows.Media.Brushes.White);
		frameworkElementFactory.AppendChild(frameworkElementFactory2);
		ControlTemplate controlTemplate = new ControlTemplate(typeof(ToggleButton))
		{
			VisualTree = frameworkElementFactory
		};
		Trigger trigger = new Trigger
		{
			Property = ToggleButton.IsCheckedProperty,
			Value = true
		};
		trigger.Setters.Add(new Setter(Border.BackgroundProperty, new SolidColorBrush(System.Windows.Media.Color.FromRgb(100, 162, 238)), "Track"));
		trigger.Setters.Add(new Setter(FrameworkElement.HorizontalAlignmentProperty, System.Windows.HorizontalAlignment.Right, "Thumb"));
		controlTemplate.Triggers.Add(trigger);
		obj.Template = controlTemplate;
		return obj;
	}

	public void Settings(int selectedPage = -1)
	{
		if (settingsOpen)
		{
			if (settingsWindow != null)
			{
				if (selectedPage >= 0 && settingsTabs != null)
				{
					settingsTabs.SelectedIndex = Math.Max(0, Math.Min(4, selectedPage));
				}
				if (settingsWindow.WindowState == WindowState.Minimized)
				{
					settingsWindow.WindowState = WindowState.Normal;
				}
				settingsWindow.Activate();
			}
			return;
		}
		settingsOpen = true;
		DispatcherTimer preview = new DispatcherTimer
		{
			Interval = TimeSpan.FromMilliseconds(100.0)
		};
		DispatcherTimer stateTimer = new DispatcherTimer
		{
			Interval = TimeSpan.FromMilliseconds(700.0)
		};
		bool flag = false;
		bool cleaned = false;
		Action cleanup = delegate
		{
			if (cleaned)
			{
				return;
			}
			cleaned = true;
			settingsOpen = false;
			settingsWindow = null;
			settingsTabs = null;
			preview.Stop();
			stateTimer.Stop();
			Save();
			try
			{
				if (!ShuttingDown)
				{
					Dock.Refresh();
					RefreshWidgets();
				}
			}
			catch (Exception ex2)
			{
				Store.Log(ex2);
			}
		};
		try
		{
			Board.Hide();
			Window w = new Window
			{
				Title = "GlassBoard · 个性化与控制 v0.9.17",
				Width = Math.Min(940.0, SystemParameters.WorkArea.Width - 40.0),
				Height = Math.Min(790.0, SystemParameters.WorkArea.Height - 50.0),
				MinWidth = 560.0,
				ResizeMode = ResizeMode.CanResize,
				WindowStartupLocation = WindowStartupLocation.CenterScreen,
				Owner = Dock,
				Topmost = true,
				Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(28, 30, 38)),
				Foreground = System.Windows.Media.Brushes.White
			};
			settingsWindow = w;
			w.Closed += delegate
			{
				cleanup();
			};
			Rect workArea = SystemParameters.WorkArea;
			double[] array = SettingsPlacementRules.Vertical(workArea.Top, workArea.Height, Dock.RestingTop, Dock.Height, 790.0);
			w.WindowStartupLocation = WindowStartupLocation.Manual;
			w.Left = workArea.Left + (workArea.Width - w.Width) / 2.0;
			w.Top = array[0];
			w.Height = array[1];
			Polish.Apply(w, light: false);
			Grid grid = new Grid
			{
				Margin = new Thickness(24.0)
			};
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			grid.RowDefinitions.Add(new RowDefinition());
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			w.Content = grid;
			StackPanel stackPanel = new StackPanel();
			stackPanel.Children.Add(new TextBlock
			{
				Text = "把桌面，变成你的空间",
				FontSize = 25.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 6.0)
			});
			stackPanel.Children.Add(new TextBlock
			{
				Text = "GLASSBOARD  /  个性化、组件与桌面控制",
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 0.0, 0.0, 18.0)
			});
			grid.Children.Add(stackPanel);
			System.Windows.Controls.TabControl tabs = new System.Windows.Controls.TabControl
			{
				Background = System.Windows.Media.Brushes.Transparent,
				BorderThickness = new Thickness(0.0),
				TabStripPlacement = System.Windows.Controls.Dock.Left
			};
			Grid.SetRow(tabs, 1);
			grid.Children.Add(tabs);
			settingsTabs = tabs;
			Func<string, StackPanel> func = delegate(string heading)
			{
				Border border = Polish.Section(heading, "调整会即时预览；关闭窗口保留外观与组件设置。", light: false);
				StackPanel obj2 = (StackPanel)border.Child;
				TextElement.SetForeground(obj2, System.Windows.Media.Brushes.White);
				StackPanel stackPanel10 = new StackPanel
				{
					Margin = new Thickness(10.0, 8.0, 0.0, 8.0)
				};
				stackPanel10.Children.Add(border);
				TabItem newItem = new TabItem
				{
					Header = heading,
					Content = new ScrollViewer
					{
						Content = stackPanel10,
						VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
						HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
					}
				};
				tabs.Items.Add(newItem);
				return obj2;
			};
			StackPanel stackPanel2 = func("面板与主题");
			StackPanel stackPanel3 = func("Dock DIY");
			StackPanel stackPanel4 = func("快捷键与开关");
			StackPanel stackPanel5 = func("桌面组件");
			StackPanel stackPanel6 = func("通用");
			tabs.SelectedIndex = Math.Max(0, Math.Min(4, selectedPage));
			DockOptions draft = Prefs.Dock.Copy();
			bool loading = false;
			preview.Tick += delegate
			{
				preview.Stop();
				Dock.Refresh(capture: false);
			};
			Action live = delegate
			{
				if (!loading)
				{
					draft.ItemOrder = (Prefs.Dock.ItemOrder ?? new List<string>()).ToList();
					draft.RunningOrder = (Prefs.Dock.RunningOrder ?? new List<string>()).ToList();
					draft.Normalize();
					Prefs.Dock = draft.Copy();
					Save();
					if (!preview.IsEnabled)
					{
						preview.Start();
					}
				}
			};
			Func<StackPanel, string, double, double, double, double, string, Action<double>, Slider> func2 = delegate(StackPanel panel, string label, double min, double max, double value3, double tick, string unit, Action<double> change)
			{
				TextBlock caption = new TextBlock
				{
					Text = label + "  " + value3.ToString("0.##") + unit,
					Margin = new Thickness(0.0, 12.0, 0.0, 6.0),
					Foreground = System.Windows.Media.Brushes.White
				};
				panel.Children.Add(caption);
				Slider control = new Slider
				{
					Minimum = min,
					Maximum = max,
					Value = value3,
					TickFrequency = tick,
					IsSnapToTickEnabled = true,
					Margin = new Thickness(0.0, 0.0, 5.0, 4.0)
				};
				panel.Children.Add(control);
				control.ValueChanged += delegate
				{
					caption.Text = label + "  " + control.Value.ToString("0.##") + unit;
					change(control.Value);
				};
				return control;
			};
			Func<StackPanel, string, bool, Action<bool>, System.Windows.Controls.CheckBox> func3 = delegate(StackPanel panel, string label, bool value3, Action<bool> change)
			{
				System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
				{
					Content = label,
					IsChecked = value3,
					Foreground = System.Windows.Media.Brushes.White,
					Margin = new Thickness(0.0, 10.0, 0.0, 8.0)
				};
				panel.Children.Add(checkBox);
				checkBox.Checked += delegate
				{
					change(obj: true);
				};
				checkBox.Unchecked += delegate
				{
					change(obj: false);
				};
				return checkBox;
			};
			Func<StackPanel, string, string[], int, Action<int>, System.Windows.Controls.ComboBox> func4 = delegate(StackPanel panel, string label, string[] items, int selectedIndex, Action<int> change)
			{
				panel.Children.Add(new TextBlock
				{
					Text = label,
					Margin = new Thickness(0.0, 12.0, 0.0, 6.0)
				});
				System.Windows.Controls.ComboBox control = new System.Windows.Controls.ComboBox
				{
					ItemsSource = items,
					SelectedIndex = selectedIndex,
					Height = 32.0
				};
				panel.Children.Add(control);
				control.SelectionChanged += delegate
				{
					if (control.SelectedIndex >= 0)
					{
						change(control.SelectedIndex);
					}
				};
				return control;
			};
			func3(stackPanel2, "使用浅色玻璃", Prefs.Light, delegate(bool light)
			{
				Prefs.Light = light;
				live();
			});
			func4(stackPanel2, "大面板尺寸", new string[3] { "舒适 · 中号", "宽阔 · 大号", "铺满 · 全屏" }, Prefs.PanelSize, delegate(int panelSize)
			{
				Prefs.PanelSize = panelSize;
				Prefs.Placement.PanelWidth = (Prefs.Placement.PanelHeight = null);
				Save();
			});
			string[] startGroups = new string[2 + Prefs.Groups.Count];
			startGroups[0] = "全部";
			startGroups[1] = "未分组";
			Prefs.Groups.CopyTo(startGroups, 2);
			int startGroupIndex = Array.IndexOf(startGroups, Prefs.BoardStartGroup ?? "");
			if (startGroupIndex < 0)
			{
				startGroupIndex = 0;
			}
			func4(stackPanel2, "打开面板时定位到", startGroups, startGroupIndex, delegate(int value)
			{
				Prefs.BoardStartGroup = ((value == 0) ? "" : startGroups[value]);
				Save();
			});
			func2(stackPanel2, "大面板透明度", 0.0, 100.0, 100.0 - (Prefs.OpacityPercent ?? 72.0), 5.0, "%", delegate(double num3)
			{
				Opacity(100.0 - num3);
				Save();
			});
			func3(stackPanel2, "启用界面动效", draft.MotionEnabled, delegate(bool motionEnabled)
			{
				draft.MotionEnabled = motionEnabled;
				live();
			});
			func2(stackPanel2, "动效强度", 0.5, 1.5, draft.MotionLevel, 0.1, " 倍", delegate(double motionLevel)
			{
				draft.MotionLevel = motionLevel;
				live();
			});
			func2(stackPanel2, "玻璃模糊", 0.0, 40.0, draft.BlurRadius, 2.0, "", delegate(double blurRadius)
			{
				draft.BlurRadius = blurRadius;
				live();
			});
			func2(stackPanel2, "边缘高光", 0.2, 2.0, draft.EdgeStrength, 0.1, " 倍", delegate(double edgeStrength)
			{
				draft.EdgeStrength = edgeStrength;
				live();
			});
			func3(stackPanel2, "锁定大面板位置和尺寸", Prefs.Placement.PanelLocked, delegate(bool panelLocked)
			{
				Prefs.Placement.PanelLocked = panelLocked;
				Save();
			});
			func3(stackPanel2, "点击外部自动收起大面板（关闭时方便从桌面拖入文件）", Prefs.BoardDismissOnDeactivate, delegate(bool boardDismissOnDeactivate)
			{
				Prefs.BoardDismissOnDeactivate = boardDismissOnDeactivate;
				Save();
			});
			func3(stackPanel2, "新增软件自动识别分组", Prefs.AutoGrouping, delegate(bool autoGrouping)
			{
				Prefs.AutoGrouping = autoGrouping;
				Save();
			});
			func3(stackPanel2, "隐藏大面板搜索栏", Prefs.BoardHideSearch, delegate(bool boardHideSearch)
			{
				Prefs.BoardHideSearch = boardHideSearch;
				Save();
				Board.ApplyDisplayOptions();
			});
			func3(stackPanel2, "隐藏大面板分组栏，直接显示全部图标", Prefs.BoardHideGroups, delegate(bool boardHideGroups)
			{
				Prefs.BoardHideGroups = boardHideGroups;
				Save();
				Board.ApplyDisplayOptions();
			});
			func3(stackPanel2, "显示快捷方式箭头角标（大面板与 Dock）", draft.ShowShortcutOverlays, delegate(bool showShortcutOverlays)
			{
				draft.ShowShortcutOverlays = showShortcutOverlays;
				Native.ClearIconCache();
				live();
				Board.RefreshIcons();
				Save();
			});
			func3(stackPanel2, "高清图标（大面板与 Dock，默认关闭）", draft.SharperIcons, delegate(bool sharperIcons)
			{
				draft.SharperIcons = sharperIcons;
				Native.ClearIconCache();
				live();
				preview.Stop();
				Dock.Refresh(capture: false);
				Board.RefreshIcons();
				Save();
			});
			stackPanel2.Children.Add(new TextBlock
			{
				Text = "优先读取软件自带的高分辨率图标；仅在加载时处理，不新增后台任务。关闭后清除图标缓存。原始图标像素低时效果有限。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 2.0, 0.0, 8.0)
			});
			BuildMaterialEditor(stackPanel2, "大面板玻璃材质 DIY", Prefs.BoardMaterial, delegate
			{
				Prefs.BoardMaterial.Normalize();
				Board.SetMaterial(Prefs.BoardMaterial);
				Save();
			});
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			};
			stackPanel2.Children.Add(wrapPanel);
			wrapPanel.Children.Add(FeatureUi.Button("外观方案", delegate
			{
				Save();
				if (ManageSchemes(w))
				{
					draft = Prefs.Dock.Copy();
					w.Close();
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("管理分组", delegate
			{
				ManageGroups(w);
			}));
			wrapPanel.Children.Add(FeatureUi.Button("创作工作区", delegate
			{
				ManageWorkspaces(w);
			}));
			wrapPanel.Children.Add(FeatureUi.Button("自动分组未分组软件", delegate
			{
				AutoGroupApps(w);
			}));
			wrapPanel.Children.Add(FeatureUi.Button("重置面板位置和尺寸", delegate
			{
				Prefs.Placement.PanelLeft = (Prefs.Placement.PanelTop = (Prefs.Placement.PanelWidth = (Prefs.Placement.PanelHeight = null)));
				Save();
			}));
			stackPanel2.Children.Add(new TextBlock
			{
				Text = "面板平滑展开、图标逐项淡入、悬停轻抬；关闭动效后直接呈现。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			});
			stackPanel3.Children.Add(new TextBlock
			{
				Text = "独立定制下方玻璃板",
				FontSize = 18.0,
				Foreground = System.Windows.Media.Brushes.White
			});
			BuildMaterialEditor(stackPanel3, "Dock 玻璃材质 DIY", draft.Material, delegate
			{
				live();
			});
			System.Windows.Controls.ComboBox presets = func4(stackPanel3, "一键风格", new string[4] { "自定义", "紧凑", "均衡", "宽松" }, 0, delegate
			{
			});
			Slider icon = func2(stackPanel3, "图标尺寸", 32.0, 64.0, draft.IconSize, 2.0, " px", delegate(double iconSize)
			{
				draft.IconSize = iconSize;
				live();
			});
			Slider spacing = func2(stackPanel3, "图标间距", 0.0, 20.0, draft.Spacing, 1.0, " px", delegate(double spacing2)
			{
				draft.Spacing = spacing2;
				live();
			});
			Slider padding = func2(stackPanel3, "玻璃板内边距", 8.0, 28.0, draft.Padding, 1.0, " px", delegate(double padding2)
			{
				draft.Padding = padding2;
				live();
			});
			Slider radius = func2(stackPanel3, "圆角", 0.0, 48.0, draft.Radius, 2.0, " px", delegate(double radius2)
			{
				draft.Radius = radius2;
				live();
			});
			Slider opacity = func2(stackPanel3, "Dock 透明度", 0.0, 100.0, 100.0 - draft.OpacityPercent, 5.0, "%", delegate(double num3)
			{
				draft.OpacityPercent = 100.0 - num3;
				live();
			});
			Slider zoom = func2(stackPanel3, "悬停放大", 1.0, 1.6, draft.Zoom, 0.05, " 倍", delegate(double zoom2)
			{
				draft.Zoom = zoom2;
				live();
			});
			System.Windows.Controls.CheckBox labels = func3(stackPanel3, "显示图标名称", draft.ShowLabels, delegate(bool showLabels)
			{
				draft.ShowLabels = showLabels;
				live();
			});
			func3(stackPanel3, "显示此电脑", draft.ShowComputer, delegate(bool showComputer)
			{
				draft.ShowComputer = showComputer;
				live();
			});
			func3(stackPanel3, "显示设置图标", draft.ShowSettings, delegate(bool showSettings)
			{
				draft.ShowSettings = showSettings;
				live();
			});
			func3(stackPanel3, "显示电源快捷菜单", draft.ShowPower, delegate(bool showPower)
			{
				draft.ShowPower = showPower;
				live();
			});
			func3(stackPanel3, "Dock 保留控制中心快捷入口", draft.ShowNetwork, delegate(bool showNetwork)
			{
				draft.ShowNetwork = showNetwork;
				live();
			});
			func4(stackPanel3, "此电脑图标样式", new string[2] { "渐变徽章", "简洁线框" }, draft.ComputerStyle, delegate(int computerStyle)
			{
				draft.ComputerStyle = computerStyle;
				live();
			});
			func4(stackPanel3, "强调色", new string[6] { "晴空蓝", "雾紫", "薄荷绿", "暖金", "玫瑰粉", "月光灰" }, draft.Accent, delegate(int accent)
			{
				draft.Accent = accent;
				live();
			});
			func3(stackPanel3, "显示分隔线", draft.ShowSeparator, delegate(bool showSeparator)
			{
				draft.ShowSeparator = showSeparator;
				live();
			});
			func3(stackPanel3, "Dock 保持在窗口最上方", draft.AlwaysOnTop, delegate(bool alwaysOnTop)
			{
				draft.AlwaysOnTop = alwaysOnTop;
				live();
			});
			func3(stackPanel3, "显示软件运行状态", draft.ShowRunning, delegate(bool showRunning)
			{
				draft.ShowRunning = showRunning;
				live();
			});
			func3(stackPanel3, "Dock 自动隐藏，靠近所在屏幕底边唤出", draft.AutoHide, delegate(bool autoHide)
			{
				draft.AutoHide = autoHide;
				live();
			});
			func2(stackPanel3, "自动隐藏延迟", 200.0, 3000.0, draft.HideDelay, 100.0, " ms", delegate(double hideDelay)
			{
				draft.HideDelay = hideDelay;
				live();
			});
			func2(stackPanel3, "底边触发范围", 3.0, 48.0, draft.EdgeRange, 1.0, " px", delegate(double edgeRange)
			{
				draft.EdgeRange = edgeRange;
				live();
			});
			func3(stackPanel3, "弹簧弹出效果（也可右键 Dock 切换）", draft.SpringReveal, delegate(bool springReveal)
			{
				draft.SpringReveal = springReveal;
				live();
			});
			func3(stackPanel3, "锁定 Dock 位置", Prefs.Placement.DockLocked, delegate(bool dockLocked)
			{
				Prefs.Placement.DockLocked = dockLocked;
				live();
			});
			stackPanel3.Children.Add(FeatureUi.Button("重置 Dock 位置", delegate
			{
				Prefs.Placement.DockCenter = (Prefs.Placement.DockLeft = (Prefs.Placement.DockTop = null));
				live();
			}));
			func4(stackPanel3, "水平位置", new string[3] { "靠左", "居中", "靠右" }, draft.Alignment, delegate(int alignment)
			{
				draft.Alignment = alignment;
				Prefs.Placement.DockCenter = (Prefs.Placement.DockLeft = null);
				live();
			});
			func2(stackPanel3, "左右微调", -500.0, 500.0, draft.Offset, 10.0, " px", delegate(double offset)
			{
				draft.Offset = offset;
				Prefs.Placement.DockCenter = (Prefs.Placement.DockLeft = null);
				live();
			});
			func2(stackPanel3, "距工作区底边", 0.0, 160.0, Prefs.DockGap, 2.0, " px", delegate(double dockGap)
			{
				Prefs.DockGap = dockGap;
				Prefs.Placement.DockTop = null;
				live();
			});
			func2(stackPanel3, "固定应用显示数量", 3.0, 20.0, draft.MaxPinned, 1.0, " 个", delegate(double num3)
			{
				draft.MaxPinned = (int)num3;
				live();
			});
			stackPanel3.Children.Add(new TextBlock
			{
				Text = "可固定 20 个入口。数量超限或屏幕放不下时，其余入口收进「更多」。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			});
			presets.SelectionChanged += delegate
			{
				if (presets.SelectedIndex >= 1)
				{
					int selectedIndex = presets.SelectedIndex;
					loading = true;
					icon.Value = selectedIndex switch
					{
						3 => 56, 
						1 => 34, 
						_ => 44, 
					};
					spacing.Value = selectedIndex switch
					{
						3 => 10, 
						1 => 2, 
						_ => 6, 
					};
					padding.Value = selectedIndex switch
					{
						3 => 22, 
						1 => 10, 
						_ => 16, 
					};
					radius.Value = selectedIndex switch
					{
						3 => 36, 
						1 => 20, 
						_ => 28, 
					};
					opacity.Value = selectedIndex switch
					{
						3 => 22, 
						1 => 35, 
						_ => 28, 
					};
					zoom.Value = selectedIndex switch
					{
						3 => 1.3, 
						1 => 1.1, 
						_ => 1.2, 
					};
					labels.IsChecked = selectedIndex == 3;
					loading = false;
					live();
				}
			};
			stackPanel4.Children.Add(new TextBlock
			{
				Text = "快捷键与桌面开关",
				FontSize = 18.0
			});
			stackPanel4.Children.Add(new TextBlock
			{
				Text = "可点击录制直接按组合键，保存后生效。右侧开关即时操作。\n隐藏开关：开启隐藏，关闭显示；自动开关：Windows 任务栏自动隐藏。",
				Foreground = System.Windows.Media.Brushes.LightGray,
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(0.0, 8.0, 0.0, 18.0)
			});
			Dictionary<string, uint> keyChoices = HotkeyRules.Keys();
			Dictionary<int, Tuple<System.Windows.Controls.CheckBox, System.Windows.Controls.ComboBox, System.Windows.Controls.ComboBox>> controls = new Dictionary<int, Tuple<System.Windows.Controls.CheckBox, System.Windows.Controls.ComboBox, System.Windows.Controls.ComboBox>>();
			Dictionary<int, ToggleButton> switches = new Dictionary<int, ToggleButton>();
			Dictionary<int, TextBlock> info = new Dictionary<int, TextBlock>();
			bool syncing = false;
			foreach (HotkeySetting binding in Prefs.Hotkeys.OrderBy((HotkeySetting k) => k.ActionId))
			{
				int id = binding.ActionId;
				StackPanel stackPanel7 = new StackPanel
				{
					Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
				};
				stackPanel4.Children.Add(stackPanel7);
				Grid grid2 = new Grid();
				double[] array2 = new double[4] { 1.7, 1.7, 0.8, 1.1 };
				foreach (double value in array2)
				{
					grid2.ColumnDefinitions.Add(new ColumnDefinition
					{
						Width = new GridLength(value, GridUnitType.Star)
					});
				}
				grid2.ColumnDefinitions.Insert(3, new ColumnDefinition
				{
					Width = new GridLength(64.0)
				});
				stackPanel7.Children.Add(grid2);
				System.Windows.Controls.CheckBox enabled = new System.Windows.Controls.CheckBox
				{
					Content = new TextBlock
					{
						Text = HotkeyRules.Actions[id - 1],
						TextWrapping = TextWrapping.Wrap
					},
					IsChecked = binding.Enabled,
					Foreground = System.Windows.Media.Brushes.White,
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
				};
				grid2.Children.Add(enabled);
				System.Windows.Controls.ComboBox modifiers = new System.Windows.Controls.ComboBox
				{
					ItemsSource = HotkeyRules.ModifierNames,
					SelectedIndex = Array.IndexOf(HotkeyRules.ModifierValues, binding.Modifiers),
					Height = 32.0,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0),
					IsEnabled = binding.Enabled
				};
				Grid.SetColumn(modifiers, 1);
				grid2.Children.Add(modifiers);
				System.Windows.Controls.ComboBox key = new System.Windows.Controls.ComboBox
				{
					ItemsSource = keyChoices.Keys.ToList(),
					SelectedItem = keyChoices.First((KeyValuePair<string, uint> k) => k.Value == binding.Key).Key,
					Height = 32.0,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0),
					IsEnabled = binding.Enabled
				};
				Grid.SetColumn(key, 2);
				grid2.Children.Add(key);
				enabled.Checked += delegate
				{
					modifiers.IsEnabled = true;
					key.IsEnabled = true;
				};
				enabled.Unchecked += delegate
				{
					modifiers.IsEnabled = false;
					key.IsEnabled = false;
				};
				controls[id] = Tuple.Create(enabled, modifiers, key);
				System.Windows.Controls.Button button = new System.Windows.Controls.Button
				{
					Content = "录制",
					Height = 32.0,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
				};
				Grid.SetColumn(button, 3);
				grid2.Children.Add(button);
				button.Click += delegate
				{
					List<HotkeySetting> keys = Dock.SuspendHotkeys();
					HotkeySetting captured;
					try
					{
						captured = FeatureUi.Record(w, id);
					}
					finally
					{
						Dock.ResumeHotkeys(keys);
					}
					if (captured != null)
					{
						enabled.IsChecked = true;
						modifiers.SelectedIndex = Array.IndexOf(HotkeyRules.ModifierValues, captured.Modifiers);
						key.SelectedItem = keyChoices.First((KeyValuePair<string, uint> x) => x.Value == captured.Key).Key;
					}
				};
				if (id == 2 || id == 3 || id == 7)
				{
					StackPanel stackPanel8 = new StackPanel
					{
						Orientation = System.Windows.Controls.Orientation.Horizontal,
						VerticalAlignment = VerticalAlignment.Center
					};
					Grid.SetColumn(stackPanel8, 4);
					grid2.Children.Add(stackPanel8);
					ToggleButton toggleButton = VisibilitySwitch();
					if (id == 7)
					{
						try
						{
							toggleButton.IsChecked = TaskbarAutoHide.Enabled;
						}
						catch
						{
							toggleButton.IsChecked = false;
						}
					}
					else
					{
						toggleButton.IsChecked = DesktopVisibility.DesiredHidden(id == 2);
					}
					toggleButton.ToolTip = ((id == 7) ? "开启 Windows 任务栏自动隐藏" : "开启隐藏，关闭显示");
					stackPanel8.Children.Add(toggleButton);
					stackPanel8.Children.Add(new TextBlock
					{
						Text = ((id == 7) ? "自动" : "隐藏"),
						Margin = new Thickness(6.0, 0.0, 0.0, 0.0),
						VerticalAlignment = VerticalAlignment.Center,
						Foreground = System.Windows.Media.Brushes.White
					});
					switches[id] = toggleButton;
					toggleButton.Checked += delegate
					{
						if (!syncing)
						{
							if (id == 7)
							{
								ToggleTaskbarAutoHide(true);
							}
							else
							{
								ShellAction(id - 1, true);
							}
						}
					};
					toggleButton.Unchecked += delegate
					{
						if (!syncing)
						{
							if (id == 7)
							{
								ToggleTaskbarAutoHide(false);
							}
							else
							{
								ShellAction(id - 1, false);
							}
						}
					};
				}
				TextBlock textBlock = new TextBlock
				{
					Foreground = System.Windows.Media.Brushes.LightGray,
					FontSize = 11.0,
					TextWrapping = TextWrapping.Wrap,
					Margin = new Thickness(0.0, 6.0, 0.0, 0.0)
				};
				stackPanel7.Children.Add(textBlock);
				info[id] = textBlock;
			}
			Action updateState = delegate
			{
				syncing = true;
				foreach (HotkeySetting hotkey in Prefs.Hotkeys)
				{
					string text2 = ((!hotkey.Enabled) ? "快捷键已关闭" : (Dock.HotkeyActive(hotkey.ActionId) ? "快捷键已注册" : "快捷键未注册，请换组合或重新注册"));
					if (hotkey.ActionId == 2 || hotkey.ActionId == 3)
					{
						bool taskbar = hotkey.ActionId == 2;
						bool? flag3 = DesktopVisibility.IsHidden(taskbar);
						text2 = text2 + " · 实际状态：" + ((!flag3.HasValue) ? "未找到系统窗口" : (flag3.Value ? "隐藏" : "显示"));
						switches[hotkey.ActionId].IsChecked = DesktopVisibility.DesiredHidden(taskbar);
					}
					if (hotkey.ActionId == 7)
					{
						try
						{
							bool enabled2 = TaskbarAutoHide.Enabled;
							switches[7].IsChecked = enabled2;
							text2 = text2 + " · 自动隐藏：" + (enabled2 ? "开启" : "关闭");
						}
						catch
						{
							text2 += " · 未找到 Windows 任务栏";
						}
					}
					info[hotkey.ActionId].Text = text2;
				}
				syncing = false;
			};
			stateTimer.Tick += delegate
			{
				updateState();
			};
			updateState();
			stateTimer.Start();
			WrapPanel wrapPanel2 = new WrapPanel();
			stackPanel4.Children.Add(wrapPanel2);
			System.Windows.Controls.Button button2 = new System.Windows.Controls.Button
			{
				Content = "恢复默认快捷键",
				Padding = new Thickness(12.0, 7.0, 12.0, 7.0),
				Margin = new Thickness(0.0, 0.0, 8.0, 6.0)
			};
			wrapPanel2.Children.Add(button2);
			button2.Click += delegate
			{
				foreach (HotkeySetting k in HotkeyRules.Defaults())
				{
					Tuple<System.Windows.Controls.CheckBox, System.Windows.Controls.ComboBox, System.Windows.Controls.ComboBox> tuple = controls[k.ActionId];
					tuple.Item1.IsChecked = true;
					tuple.Item2.SelectedIndex = Array.IndexOf(HotkeyRules.ModifierValues, k.Modifiers);
					tuple.Item3.SelectedItem = keyChoices.First((KeyValuePair<string, uint> x) => x.Value == k.Key).Key;
				}
			};
			System.Windows.Controls.Button button3 = new System.Windows.Controls.Button
			{
				Content = "重新注册当前快捷键",
				Padding = new Thickness(12.0, 7.0, 12.0, 7.0),
				Margin = new Thickness(0.0, 0.0, 8.0, 6.0)
			};
			wrapPanel2.Children.Add(button3);
			button3.Click += delegate
			{
				System.Windows.MessageBox.Show(w, Dock.RetryHotkeys(), "快捷键注册结果");
				updateState();
			};
			System.Windows.Controls.Button button4 = new System.Windows.Controls.Button
			{
				Content = "显示任务栏与桌面图标",
				Padding = new Thickness(12.0, 7.0, 12.0, 7.0),
				Margin = new Thickness(0.0, 0.0, 8.0, 6.0)
			};
			wrapPanel2.Children.Add(button4);
			button4.Click += delegate
			{
				ShellAction(3);
				updateState();
			};
			stackPanel4.Children.Add(new TextBlock
			{
				Text = "隐藏状态仅在本次运行中维持；正常退出恢复启动前状态。组合键占用不会阻止直接点击开关。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			});
			stackPanel5.Children.Add(new TextBlock
			{
				Text = "可选组件 · 默认关闭",
				FontSize = 18.0
			});
			stackPanel5.Children.Add(FeatureUi.Button("控制中心 · 开启小球", delegate
			{
				OpenControlCenter();
			}));
			stackPanel5.Children.Add(FeatureUi.Button("控制中心 · 小球设置", delegate
			{
				ControlCenterSettings(w);
			}));
			stackPanel5.Children.Add(FeatureUi.Button("组件外观 DIY · 颜色 / 无框 / 时钟 / 音乐按钮", delegate
			{
				CustomizeWidgets(null, w);
			}));
			Dictionary<string, System.Windows.Controls.ComboBox> routes = new Dictionary<string, System.Windows.Controls.ComboBox>();
			Dictionary<string, ToggleButton> widgetChecks = new Dictionary<string, ToggleButton>();
			bool routeSync = false;
			Action syncRoutes = delegate
			{
				routeSync = true;
				foreach (KeyValuePair<string, System.Windows.Controls.ComboBox> item in routes)
				{
					item.Value.SelectedIndex = WidgetRules.Panel(Prefs.Widgets, item.Key);
				}
				routeSync = false;
			};
			WrapPanel wrapPanel3 = new WrapPanel
			{
				Margin = new Thickness(0.0, 6.0, 0.0, 14.0)
			};
			stackPanel5.Children.Add(wrapPanel3);
			wrapPanel3.Children.Add(FeatureUi.Button("全部融合", delegate
			{
				Prefs.Widgets.Fuse();
				syncRoutes();
				RefreshWidgets();
				Save();
			}));
			wrapPanel3.Children.Add(FeatureUi.Button("全部分离", delegate
			{
				Prefs.Widgets.Separate();
				syncRoutes();
				RefreshWidgets();
				Save();
			}));
			stackPanel5.Children.Add(new TextBlock
			{
				Text = "组件选择同一个面板会融合，选择不同面板会分离。也可点击组件右上角 ••• 调整。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			});
			string[] kinds = WidgetRules.Kinds;
			foreach (string text in kinds)
			{
				string kind = text;
				int num2 = Array.IndexOf(WidgetRules.Kinds, kind);
				Grid grid3 = new Grid
				{
					Margin = new Thickness(0.0, 4.0, 0.0, 9.0)
				};
				grid3.ColumnDefinitions.Add(new ColumnDefinition());
				grid3.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(132.0)
				});
				StackPanel stackPanel9 = new StackPanel
				{
					Orientation = System.Windows.Controls.Orientation.Horizontal,
					VerticalAlignment = VerticalAlignment.Center
				};
				grid3.Children.Add(stackPanel9);
				ToggleButton enable = VisibilitySwitch();
				enable.IsChecked = WidgetRules.Enabled(Prefs.Widgets, kind);
				enable.ToolTip = "开启 / 关闭" + WidgetRules.Names[num2];
				stackPanel9.Children.Add(enable);
				stackPanel9.Children.Add(new TextBlock
				{
					Text = WidgetRules.Names[num2],
					Margin = new Thickness(10.0, 0.0, 0.0, 0.0),
					Foreground = System.Windows.Media.Brushes.White,
					VerticalAlignment = VerticalAlignment.Center
				});
				widgetChecks[kind] = enable;
				enable.Click += delegate
				{
					bool value3 = enable.IsChecked == true;
					SetWidgetEnabled(kind, value3);
				};
				System.Windows.Controls.ComboBox route = new System.Windows.Controls.ComboBox
				{
					ItemsSource = new string[4] { "面板 A", "面板 B", "面板 C", "面板 D" },
					SelectedIndex = WidgetRules.Panel(Prefs.Widgets, kind),
					Height = 34.0
				};
				Grid.SetColumn(route, 1);
				grid3.Children.Add(route);
				routes[kind] = route;
				route.SelectionChanged += delegate
				{
					if (!routeSync && route.SelectedIndex >= 0)
					{
						WidgetRules.Assign(Prefs.Widgets, kind, route.SelectedIndex);
						RefreshWidgets();
						Save();
					}
				};
				stackPanel5.Children.Add(grid3);
			}
			TextBlock componentStatus = new TextBlock
			{
				Text = "组件开关会自动保存，可随时关闭或重新开启。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 6.0, 0.0, 10.0)
			};
			stackPanel5.Children.Add(componentStatus);
			stateTimer.Tick += delegate
			{
				componentStatus.Text = (string.IsNullOrEmpty(WidgetStatus) ? "组件开关会自动保存，可随时关闭或重新开启。" : WidgetStatus);
				routeSync = true;
				try
				{
					foreach (KeyValuePair<string, ToggleButton> item2 in widgetChecks)
					{
						bool flag3 = WidgetRules.Enabled(Prefs.Widgets, item2.Key);
						if (item2.Value.IsChecked != flag3)
						{
							item2.Value.IsChecked = flag3;
						}
					}
				}
				finally
				{
					routeSync = false;
				}
			};
			stackPanel5.Children.Add(FeatureUi.Button("开启全部组件", delegate
			{
				RecoverWidgets();
			}));
			stackPanel5.Children.Add(FeatureUi.Button("重新打开已启用组件", delegate
			{
				ReopenWidgets();
			}));
			func3(stackPanel5, "组件始终置顶", Prefs.Widgets.Topmost, delegate(bool topmost)
			{
				Prefs.Widgets.Topmost = topmost;
				RefreshWidgets();
			});
			func3(stackPanel5, "锁定组件位置", Prefs.Widgets.Locked, delegate(bool locked)
			{
				Prefs.Widgets.Locked = locked;
				RefreshWidgets();
			});
			stackPanel5.Children.Add(new TextBlock
			{
				Text = "天气城市（启用天气后联网查询）",
				Margin = new Thickness(0.0, 14.0, 0.0, 8.0)
			});
			System.Windows.Controls.TextBox city = new System.Windows.Controls.TextBox
			{
				Text = Prefs.Widgets.City,
				MinHeight = 42.0,
				TextWrapping = TextWrapping.Wrap,
				HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
				VerticalContentAlignment = VerticalAlignment.Center
			};
			stackPanel5.Children.Add(city);
			stackPanel5.Children.Add(FeatureUi.Button("应用天气城市", delegate
			{
				Prefs.Widgets.City = city.Text.Trim();
				Prefs.Widgets.Normalize();
				RefreshWidgets();
				Save();
			}));
			func3(stackPanel5, "隐藏小组件右上角关闭和更多按钮", Prefs.Widgets.HideControls, delegate(bool hideControls)
			{
				Prefs.Widgets.HideControls = hideControls;
				foreach (WidgetPanelPosition panel in Prefs.Widgets.Panels)
				{
					panel.HideControls = null;
				}
				RefreshWidgets();
				Save();
			});
			func2(stackPanel5, "组件背景透明度（100% 全透明）", 0.0, 100.0, 100.0 - Prefs.Widgets.OpacityPercent, 5.0, "%", delegate(double num3)
			{
				Prefs.Widgets.OpacityPercent = 100.0 - num3;
				foreach (WidgetPanelPosition panel2 in Prefs.Widgets.Panels)
				{
					panel2.OpacityPercent = null;
				}
				RefreshWidgets();
				Save();
			});
			func2(stackPanel5, "本地音乐音量", 0.0, 1.0, Prefs.Widgets.Volume, 0.05, "", delegate(double volume)
			{
				Prefs.Widgets.Volume = volume;
				RefreshWidgets();
			});
			stackPanel5.Children.Add(new TextBlock
			{
				Text = "音乐支持封面、系统媒体会话、持久播放列表、随机与循环。备忘录自动保存并提供文本导出；切换布局或外观方案保留文字。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray,
				Margin = new Thickness(0.0, 12.0, 0.0, 12.0)
			});
			BuildMaterialEditor(stackPanel5, "小组件玻璃材质 DIY", Prefs.Widgets.Material, delegate
			{
				RefreshWidgets();
				Save();
			});
			stackPanel5.Children.Add(FeatureUi.Button("重置全部组件位置", delegate
			{
				Prefs.Widgets.Panels.Clear();
				Prefs.Placement.WidgetLeft = (Prefs.Placement.WidgetTop = null);
				RefreshWidgets();
				Save();
			}));
			bool flag2 = false;
			string value2 = Prefs.StartupTiming;
			try
			{
				flag2 = StartupService.Enabled;
				if (flag2)
				{
					value2 = StartupService.Mode;
				}
			}
			catch (Exception ex)
			{
				Store.Log(ex);
			}
			System.Windows.Controls.CheckBox startupCheck = new System.Windows.Controls.CheckBox
			{
				Content = "登录 Windows 后自动启动 GlassBoard",
				IsChecked = flag2,
				Foreground = System.Windows.Media.Brushes.White,
				Margin = new Thickness(0.0, 10.0, 0.0, 12.0)
			};
			stackPanel6.Children.Add(startupCheck);
			stackPanel6.Children.Add(new TextBlock
			{
				Text = "自启动优先级",
				Margin = new Thickness(0.0, 4.0, 0.0, 8.0)
			});
			System.Windows.Controls.ComboBox startupMode = new System.Windows.Controls.ComboBox
			{
				ItemsSource = StartupRules.Names,
				SelectedIndex = Array.IndexOf(StartupRules.Modes, StartupRules.Mode(value2)),
				MinHeight = 36.0
			};
			stackPanel6.Children.Add(startupMode);
			TextBlock startupInfo = new TextBlock
			{
				Foreground = System.Windows.Media.Brushes.LightGray,
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(0.0, 10.0, 0.0, 16.0)
			};
			stackPanel6.Children.Add(startupInfo);
			bool startupSync = false;
			Action startupState = delegate
			{
				try
				{
					bool enabled2 = StartupService.Enabled;
					startupInfo.Text = (enabled2 ? ("已开启：" + StartupRules.Names[Array.IndexOf(StartupRules.Modes, StartupService.Mode)] + "。移动程序后请重新应用启动设置。") : "未开启；选择优先级会保存，下次开启时生效。");
				}
				catch (Exception ex2)
				{
					startupInfo.Text = "无法读取启动设置：" + ex2.GetBaseException().Message;
				}
			};
			Action<bool> setStartup = delegate(bool enabled2)
			{
				if (startupSync)
				{
					return;
				}
				try
				{
					string text2 = StartupRules.Modes[Math.Max(0, startupMode.SelectedIndex)];
					StartupService.Set(enabled2, text2);
					Prefs.StartupTiming = text2;
					Save();
					startupState();
				}
				catch (Exception ex2)
				{
					startupSync = true;
					try
					{
						startupCheck.IsChecked = StartupService.Enabled;
						if (startupCheck.IsChecked == true)
						{
							startupMode.SelectedIndex = Array.IndexOf(StartupRules.Modes, StartupService.Mode);
						}
					}
					catch
					{
						startupCheck.IsChecked = false;
					}
					startupSync = false;
					System.Windows.MessageBox.Show(w, ex2.GetBaseException().Message, "无法更新开机启动");
					startupState();
				}
			};
			startupCheck.Checked += delegate
			{
				setStartup(obj: true);
			};
			startupCheck.Unchecked += delegate
			{
				setStartup(obj: false);
			};
			startupMode.SelectionChanged += delegate
			{
				if (!startupSync && startupMode.SelectedIndex >= 0)
				{
					if (startupCheck.IsChecked == true)
					{
						setStartup(obj: true);
					}
					else
					{
						Prefs.StartupTiming = StartupRules.Modes[startupMode.SelectedIndex];
						Save();
					}
				}
			};
			startupState();
			stackPanel6.Children.Add(new TextBlock
			{
				Text = "高：当前用户登录后立即触发计划任务。普通：由 Windows 标准启动项调度。低：登录后延迟 60 秒。Windows 不提供跨软件的严格启动排序；此处控制启动触发方式与延迟。关闭开关会移除本软件的两种启动项。",
				Foreground = System.Windows.Media.Brushes.LightGray,
				TextWrapping = TextWrapping.Wrap
			});
			BuildGameSettings(stackPanel6);
			BuildUpdateSettings(stackPanel6, w);
			stackPanel6.Children.Add(FeatureUi.Button("找回旧版入口与分组", delegate
			{
				RecoverHistoricalEntries(w);
			}));
			stackPanel6.Children.Add(new TextBlock
			{
				Text = "完整备份与恢复",
				FontSize = 18.0,
				Margin = new Thickness(0.0, 22.0, 0.0, 10.0)
			});
			stackPanel6.Children.Add(new TextBlock
			{
				Text = "备份布局、分组、快捷键、组件、便签、外观方案与自定义图标。软件与音乐文件保留在原位置；开机启动按当前电脑设置保留。",
				TextWrapping = TextWrapping.Wrap,
				Foreground = System.Windows.Media.Brushes.LightGray
			});
			WrapPanel wrapPanel4 = new WrapPanel
			{
				Margin = new Thickness(0.0, 12.0, 0.0, 6.0)
			};
			wrapPanel4.Children.Add(FeatureUi.Button("导出完整备份", delegate
			{
				ExportFullBackup();
			}));
			wrapPanel4.Children.Add(FeatureUi.Button("恢复完整备份", delegate
			{
				w.Close();
				Dock.Dispatcher.BeginInvoke((Action)delegate
				{
					RestoreFullBackup();
				});
			}));
			stackPanel6.Children.Add(wrapPanel4);
			System.Windows.Controls.Button button5 = new System.Windows.Controls.Button
			{
				Content = "保存快捷键并完成",
				Height = 42.0,
				Background = Polish.Color("#416AA9"),
				Foreground = System.Windows.Media.Brushes.White,
				Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
			};
			Grid.SetRow(button5, 2);
			grid.Children.Add(button5);
			button5.Click += delegate
			{
				List<HotkeySetting> list = (from row in controls
					select new HotkeySetting
					{
						ActionId = row.Key,
						Enabled = (row.Value.Item1.IsChecked == true),
						Modifiers = HotkeyRules.ModifierValues[row.Value.Item2.SelectedIndex],
						Key = keyChoices[(string)row.Value.Item3.SelectedItem]
					} into k
					orderby k.ActionId
					select k).ToList();
				if (!HotkeyRules.Same(Prefs.Hotkeys, list) && !Dock.ApplyHotkeys(list, out var error))
				{
					System.Windows.MessageBox.Show(w, error, "快捷键未保存");
				}
				else
				{
					Prefs.Hotkeys = list.Select((HotkeySetting k) => k.Copy()).ToList();
					Save();
					RefreshTrayMenu();
					w.Close();
				}
			};
			w.Show();
			flag = true;
		}
		finally
		{
			if (!flag)
			{
				if (settingsWindow != null)
				{
					settingsWindow.Close();
				}
				cleanup();
			}
		}
	}

	public void ShellAction(int action, bool? hidden = null)
	{
		try
		{
			string text;
			switch (action)
			{
			case 1:
			{
				bool flag = hidden ?? (!DesktopVisibility.DesiredHidden(taskbar: true));
				if (flag && TaskbarAutoHide.Enabled)
				{
					TaskbarAutoHide.Set(enabled: false);
				}
				text = DesktopVisibility.SetHidden(taskbar: true, flag);
				break;
			}
			case 2:
				text = (hidden.HasValue ? DesktopVisibility.SetHidden(taskbar: false, hidden.Value) : DesktopVisibility.ToggleIcons());
				break;
			default:
				try
				{
					TaskbarAutoHide.ShowAndClear();
				}
				catch (Exception ex)
				{
					Store.Log(ex);
				}
				DesktopVisibility.ShowAll();
				text = "已执行任务栏与桌面图标恢复";
				break;
			}
			Board.SetStatus(text);
			if (Tray != null)
			{
				Tray.ShowBalloonTip(1500, "GlassBoard", text, ToolTipIcon.Info);
			}
		}
		catch (Exception ex2)
		{
			Store.Log(ex2);
			System.Windows.MessageBox.Show("无法切换系统界面：" + ex2.Message, "GlassBoard");
		}
	}

	public void Quit()
	{
		if (ShuttingDown)
		{
			return;
		}
		try
		{
			if (settingsWindow != null)
			{
				settingsWindow.Close();
			}
			Store.Save(Prefs);
			if (widgets != null && !widgets.Notes.Flush())
			{
				throw new IOException("备忘录未能保存，请先导出备忘录或检查配置目录。");
			}
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show("退出前保存失败，软件仍保持运行，避免丢失当前内容。\n" + ex.Message, "GlassBoard");
			return;
		}
		ShuttingDown = true;
		if (updateCancel != null)
		{
			updateCancel.Cancel();
		}
		try
		{
			DesktopVisibility.RestoreOriginal();
		}
		catch (Exception ex2)
		{
			Store.Log(ex2);
		}
		try
		{
			TaskbarAutoHide.Restore();
		}
		catch (Exception ex3)
		{
			Store.Log(ex3);
		}
		try
		{
			CloseControlCenter();
			CloseWidgets();
		}
		catch (Exception ex4)
		{
			Store.Log(ex4);
		}
		if (Tray != null)
		{
			Tray.Visible = false;
			Tray.Dispose();
		}
		Dock.ReleaseHotkey();
		System.Windows.Application.Current.Shutdown();
	}

	private void BuildMaterialEditor(StackPanel panel, string title, MaterialOptions options, Action changed)
	{
		options.Normalize();
		panel.Children.Add(new TextBlock
		{
			Text = title,
			FontSize = 17.0,
			Margin = new Thickness(0.0, 18.0, 0.0, 8.0)
		});
		System.Windows.Controls.ComboBox types = new System.Windows.Controls.ComboBox
		{
			ItemsSource = new string[4] { "磨砂玻璃", "清透玻璃", "亚克力", "渐变玻璃" },
			SelectedIndex = options.Kind,
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		};
		panel.Children.Add(types);
		types.SelectionChanged += delegate
		{
			if (types.SelectedIndex >= 0)
			{
				options.Kind = types.SelectedIndex;
				changed();
			}
		};
		System.Windows.Controls.TextBox tint = new System.Windows.Controls.TextBox
		{
			Text = options.Tint,
			MinHeight = 36.0,
			ToolTip = "输入 #RRGGBB，例如 #334A70；留空使用当前主题颜色"
		};
		panel.Children.Add(new TextBlock
		{
			Text = "材质色调（#RRGGBB，留空随主题）",
			Margin = new Thickness(0.0, 6.0, 0.0, 5.0)
		});
		panel.Children.Add(tint);
		panel.Children.Add(FeatureUi.Button("应用色调", delegate
		{
			string text = tint.Text.Trim();
			if (text.Length > 0 && !Regex.IsMatch(text, "^#[a-fA-F0-9]{6}$"))
			{
				System.Windows.MessageBox.Show("请输入 #RRGGBB 格式的颜色，例如 #334A70。", "GlassBoard");
			}
			else
			{
				options.Tint = text;
				changed();
			}
		}));
		Action<string, double, Action<double>> obj = delegate(string label, double value, Action<double> set)
		{
			TextBlock caption = new TextBlock
			{
				Text = label + " " + Math.Round(value * 100.0) + "%",
				Margin = new Thickness(0.0, 8.0, 0.0, 4.0)
			};
			panel.Children.Add(caption);
			Slider control = new Slider
			{
				Minimum = 0.0,
				Maximum = 1.0,
				Value = value,
				TickFrequency = 0.05,
				IsSnapToTickEnabled = true
			};
			panel.Children.Add(control);
			control.ValueChanged += delegate
			{
				set(control.Value);
				caption.Text = label + " " + Math.Round(control.Value * 100.0) + "%";
				changed();
			};
		};
		obj("反光", options.Gloss, delegate(double v)
		{
			options.Gloss = v;
		});
		obj("细纹理", options.Grain, delegate(double v)
		{
			options.Grain = v;
		});
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = "显示材质阴影",
			IsChecked = options.Shadow,
			Margin = new Thickness(0.0, 10.0, 0.0, 5.0)
		};
		panel.Children.Add(checkBox);
		checkBox.Checked += delegate
		{
			options.Shadow = true;
			changed();
		};
		checkBox.Unchecked += delegate
		{
			options.Shadow = false;
			changed();
		};
	}

	public void CustomizeWidgets(string selected = null, Window owner = null)
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Window w = FeatureUi.Dialog("组件外观 DIY", owner ?? OwnerWindow, 620.0, 730.0);
			StackPanel stackPanel = new StackPanel
			{
				Margin = new Thickness(24.0)
			};
			w.Content = new ScrollViewer
			{
				Content = stackPanel,
				VerticalScrollBarVisibility = ScrollBarVisibility.Auto
			};
			stackPanel.Children.Add(new TextBlock
			{
				Text = "颜色、无框与样式",
				FontSize = 23.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
			});
			System.Windows.Controls.ComboBox kind = new System.Windows.Controls.ComboBox
			{
				ItemsSource = WidgetRules.Names,
				SelectedIndex = Math.Max(0, Array.IndexOf(WidgetRules.Kinds, selected)),
				MinHeight = 36.0
			};
			stackPanel.Children.Add(kind);
			StackPanel editor = new StackPanel
			{
				Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
			};
			stackPanel.Children.Add(editor);
			Action apply = delegate
			{
				Prefs.Widgets.NormalizeStyles();
				Save();
				RefreshWidgets();
			};
			Action fill = null;
			fill = delegate
			{
				editor.Children.Clear();
				string k = WidgetRules.Kinds[Math.Max(0, kind.SelectedIndex)];
				WidgetStyle s = Prefs.Widgets.Style(k);
				Action<string> label = delegate(string text2)
				{
					editor.Children.Add(new TextBlock
					{
						Text = text2,
						Margin = new Thickness(0.0, 12.0, 0.0, 6.0),
						TextWrapping = TextWrapping.Wrap
					});
				};
				Action<string, bool, Action<bool>> action = delegate(string content, bool value, Action<bool> set)
				{
					System.Windows.Controls.CheckBox b = new System.Windows.Controls.CheckBox
					{
						Content = content,
						IsChecked = value,
						Margin = new Thickness(0.0, 7.0, 0.0, 7.0)
					};
					b.Click += delegate
					{
						set(b.IsChecked == true);
						apply();
					};
					editor.Children.Add(b);
				};
				Action<string, string[], int, Action<int>> action2 = delegate(string obj, string[] items, int index, Action<int> set)
				{
					label(obj);
					System.Windows.Controls.ComboBox b = new System.Windows.Controls.ComboBox
					{
						ItemsSource = items,
						SelectedIndex = index,
						MinHeight = 36.0
					};
					b.SelectionChanged += delegate
					{
						if (b.SelectedIndex >= 0)
						{
							set(b.SelectedIndex);
							apply();
						}
					};
					editor.Children.Add(b);
				};
				Action<string, double, double, double, Action<double>> action3 = delegate(string text2, double min, double max, double value, Action<double> set)
				{
					TextBlock title = new TextBlock
					{
						Text = text2 + " · " + Math.Round(value),
						Margin = new Thickness(0.0, 12.0, 0.0, 6.0)
					};
					editor.Children.Add(title);
					Slider b = new Slider
					{
						Minimum = min,
						Maximum = max,
						Value = value,
						TickFrequency = 1.0,
						IsSnapToTickEnabled = true
					};
					b.ValueChanged += delegate
					{
						title.Text = text2 + " · " + Math.Round(b.Value);
					};
					b.PreviewMouseLeftButtonUp += delegate
					{
						set(b.Value);
						apply();
					};
					b.KeyUp += delegate
					{
						set(b.Value);
						apply();
					};
					editor.Children.Add(b);
				};
				label("文字颜色 · 留空使用主题默认色");
				WrapPanel wrapPanel = new WrapPanel();
				editor.Children.Add(wrapPanel);
				System.Windows.Controls.TextBox hex = new System.Windows.Controls.TextBox
				{
					Text = s.TextColor,
					Width = 135.0,
					MinHeight = 36.0,
					MaxLength = 7,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
				};
				wrapPanel.Children.Add(hex);
				wrapPanel.Children.Add(FeatureUi.Button("调色板", delegate
				{
					using ColorDialog colorDialog = new ColorDialog
					{
						FullOpen = true
					};
					if (s.TextColor != "")
					{
						colorDialog.Color = ColorTranslator.FromHtml(s.TextColor);
					}
					if (colorDialog.ShowDialog(new ColorOwner(w)) == DialogResult.OK)
					{
						s.TextColor = ColorTranslator.ToHtml(colorDialog.Color);
						s.TextColor = "#" + colorDialog.Color.R.ToString("X2") + colorDialog.Color.G.ToString("X2") + colorDialog.Color.B.ToString("X2");
						hex.Text = s.TextColor;
						apply();
					}
				}));
				wrapPanel.Children.Add(FeatureUi.Button("应用色值", delegate
				{
					string text2 = WidgetStyle.Color(hex.Text);
					if (hex.Text.Trim() != "" && text2 == "")
					{
						System.Windows.MessageBox.Show(w, "请输入六位色值，例如 #FFFFFF。");
					}
					else
					{
						s.TextColor = text2;
						hex.Text = text2;
						apply();
					}
				}));
				WrapPanel wrapPanel2 = new WrapPanel
				{
					Margin = new Thickness(0.0, 8.0, 0.0, 0.0)
				};
				editor.Children.Add(wrapPanel2);
				string[] array = new string[6] { "#FFFFFF", "#161A22", "#F3DBB3", "#BBDFFF", "#D8C5FF", "#B8E4CE" };
				foreach (string text in array)
				{
					string chosen = text;
					System.Windows.Controls.Button button = new System.Windows.Controls.Button
					{
						Background = (System.Windows.Media.Brush)new BrushConverter().ConvertFromString(text),
						Width = 32.0,
						Height = 28.0,
						Margin = new Thickness(3.0),
						ToolTip = text
					};
					button.Click += delegate
					{
						s.TextColor = chosen;
						hex.Text = chosen;
						apply();
					};
					wrapPanel2.Children.Add(button);
				}
				action3("文字不透明度 %", 0.0, 100.0, s.TextOpacity, delegate(double v)
				{
					s.TextOpacity = v;
				});
				action("增强可读性 · 轻微文字阴影", s.TextShadow, delegate(bool v)
				{
					s.TextShadow = v;
				});
				action("无框模式 · 隐藏玻璃底板、边框、拖动条和角标", s.Frameless, delegate(bool v)
				{
					s.Frameless = v;
				});
				label("无框时可拖动文字区域移动组件；音乐按钮、备忘录输入正常使用。右键可重新进入 DIY，锁定后可从总设置解锁。");
				action3("所在面板宽度", 240.0, 1000.0, Prefs.Widgets.Position(WidgetRules.Panel(Prefs.Widgets, k)).Width ?? 450.0, delegate(double v)
				{
					Prefs.Widgets.Position(WidgetRules.Panel(Prefs.Widgets, k)).Width = v;
				});
				if (k == "clock")
				{
					action2("时钟样式 · 共 13 款", ClockCatalog.Names, s.ClockStyle, delegate(int v)
					{
						s.ClockStyle = v;
					});
					editor.Children.Add(FeatureUi.Button("使用无框推荐效果", delegate
					{
						s.Frameless = true;
						s.TextShadow = true;
						if (s.TextColor == "")
						{
							s.TextColor = "#FFFFFF";
						}
						apply();
						fill();
					}));
					label("时钟字体 · 可选择或填写已安装字体；留空使用样式默认字体");
					System.Windows.Controls.TextBox font = new System.Windows.Controls.TextBox
					{
						Text = s.Font,
						MinHeight = 36.0
					};
					editor.Children.Add(font);
					System.Windows.Controls.ComboBox fontList = new System.Windows.Controls.ComboBox
					{
						ItemsSource = (from f in Fonts.SystemFontFamilies
							select f.Source into x
							orderby x
							select x).ToList(),
						MinHeight = 34.0,
						Margin = new Thickness(0.0, 6.0, 0.0, 0.0)
					};
					fontList.SelectionChanged += delegate
					{
						if (fontList.SelectedItem != null)
						{
							font.Text = fontList.SelectedItem.ToString();
						}
					};
					editor.Children.Add(fontList);
					editor.Children.Add(FeatureUi.Button("应用字体", delegate
					{
						s.Font = font.Text.Trim();
						apply();
					}));
					action3("时间字号", 28.0, 100.0, s.ClockSize, delegate(double v)
					{
						s.ClockSize = v;
					});
					action("显示日期", s.ShowDate, delegate(bool v)
					{
						s.ShowDate = v;
					});
					action("24 小时制", s.Hour24, delegate(bool v)
					{
						s.Hour24 = v;
					});
				}
				if (k == "music")
				{
					action2("播放按钮样式", new string[5] { "经典圆形", "极简线性", "实心图标", "圆角方形", "玻璃胶囊" }, s.MusicButtons, delegate(int v)
					{
						s.MusicButtons = v;
					});
				}
				WrapPanel wrapPanel3 = new WrapPanel
				{
					Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
				};
				editor.Children.Add(wrapPanel3);
				wrapPanel3.Children.Add(FeatureUi.Button("配色应用到全部组件", delegate
				{
					string[] kinds = WidgetRules.Kinds;
					foreach (string kind2 in kinds)
					{
						WidgetStyle widgetStyle = Prefs.Widgets.Style(kind2);
						widgetStyle.TextColor = s.TextColor;
						widgetStyle.TextOpacity = s.TextOpacity;
						widgetStyle.TextShadow = s.TextShadow;
					}
					apply();
				}));
				wrapPanel3.Children.Add(FeatureUi.Button("无框状态应用到全部", delegate
				{
					string[] kinds = WidgetRules.Kinds;
					foreach (string kind2 in kinds)
					{
						Prefs.Widgets.Style(kind2).Frameless = s.Frameless;
					}
					apply();
				}));
				wrapPanel3.Children.Add(FeatureUi.Button("恢复本组件默认外观", delegate
				{
					Prefs.Widgets.Styles.Remove(s);
					apply();
					fill();
				}));
			};
			kind.SelectionChanged += delegate
			{
				fill();
			};
			fill();
			stackPanel.Children.Add(FeatureUi.Button("完成", delegate
			{
				w.Close();
			}));
			w.ShowDialog();
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public BoardEditState BeginBoardEdit()
	{
		return BoardEditState.Capture(Prefs);
	}

	public void EndBoardEdit(BoardEditState before, string label)
	{
		editHistory.Remember(before, Prefs, label);
		Save();
	}

	public void UndoBoard()
	{
		string text = editHistory.Undo(Prefs);
		if (text != null)
		{
			Board.FinishSelection();
			Refresh();
			Board.SetStatus("已撤销：" + text);
		}
	}

	public void RedoBoard()
	{
		string text = editHistory.Redo(Prefs);
		if (text != null)
		{
			Board.FinishSelection();
			Refresh();
			Board.SetStatus("已重做：" + text);
		}
	}

	public void TransferEntries(string[] paths, string from, string to)
	{
		BoardEditState before = BeginBoardEdit();
		int num = FeatureRules.Transfer(Prefs, paths, from, to);
		EndBoardEdit(before, (from == "全部") ? "添加到分组" : "移动分组");
		Board.FinishSelection();
		Refresh();
		Board.SetStatus("已处理 " + num + " 个入口 · 可按 Ctrl+Z 撤销");
	}

	public void ReorderEntry(string path, Entry target)
	{
		Entry entry = Prefs.Apps.FirstOrDefault((Entry a) => string.Equals(a.Path, path, StringComparison.OrdinalIgnoreCase));
		if (entry != null && entry != target)
		{
			BoardEditState before = BeginBoardEdit();
			int val = Prefs.Apps.IndexOf(target);
			Prefs.Apps.Remove(entry);
			Prefs.Apps.Insert(Math.Min(val, Prefs.Apps.Count), entry);
			EndBoardEdit(before, "调整图标顺序");
			Refresh();
		}
	}

	private void FlushBackupState()
	{
		Store.Save(Prefs);
		if (widgets == null)
		{
			RefreshWidgets();
		}
		if (!widgets.Notes.Flush())
		{
			throw new IOException("备忘录尚未保存，请先处理保存错误");
		}
		NoteFiles.Write(Path.Combine(Store.Folder, "notes.json"), widgets.Notes.Book);
	}

	public void ExportFullBackup()
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				FileName = "GlassBoard_完整备份_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".gbbackup",
				Filter = "GlassBoard 完整备份|*.gbbackup"
			};
			if (saveFileDialog.ShowDialog(OwnerWindow) == true)
			{
				FlushBackupState();
				BackupFiles.Create(Store.Folder, saveFileDialog.FileName);
				System.Windows.MessageBox.Show(OwnerWindow, "布局、分组、快捷键、组件、便签、外观方案与自定义图标已备份。", "备份完成");
			}
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(OwnerWindow, ex.Message, "备份失败");
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	public void RestoreFullBackup()
	{
		if (settingsWindow != null)
		{
			settingsWindow.Close();
		}
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
			{
				Filter = "GlassBoard 完整备份|*.gbbackup"
			};
			if (openFileDialog.ShowDialog(OwnerWindow) != true)
			{
				return;
			}
			BackupFiles.Read(openFileDialog.FileName);
			if (System.Windows.MessageBox.Show(OwnerWindow, "恢复此备份中的布局、分组、快捷键与便签？\n当前配置会先自动保存为恢复前备份。开机启动开关按当前电脑保留。", "恢复完整备份", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
			{
				FlushBackupState();
				string text = Path.Combine(Store.Folder, "backups", "恢复前_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".gbbackup");
				Directory.CreateDirectory(Path.GetDirectoryName(text));
				BackupFiles.Create(Store.Folder, text);
				List<HotkeySetting> hotkeys = Prefs.Hotkeys.Select((HotkeySetting k) => k.Copy()).ToList();
				BackupFiles.Restore(openFileDialog.FileName, Store.Folder);
				Prefs = Store.Load(mergeJournal: false);
				widgets.Notes.Reload();
				string error;
				bool flag = Dock.ApplyHotkeys(Prefs.Hotkeys, out error);
				if (!flag)
				{
					Prefs.Hotkeys = hotkeys;
				}
				editHistory.Clear();
				bool isVisible = Board.IsVisible;
				Refresh();
				widgets.RefreshNotes();
				RefreshTrayMenu();
				if (isVisible)
				{
					Board.Open();
				}
				System.Windows.MessageBox.Show(OwnerWindow, "配置已恢复。恢复前备份已保存到：\n" + text + (flag ? "" : ("\n快捷键与系统冲突，已保留原快捷键：" + error)), "恢复完成");
			}
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(OwnerWindow, ex.Message, "恢复失败");
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	private void RecoverHistoricalEntries(Window owner)
	{
		bool modalBusy = Board.ModalBusy;
		Board.ModalBusy = true;
		try
		{
			List<Entry> list = EntryRecoveryRules.Candidates(Prefs, Store.HistoricalEntries());
			if (list.Count == 0)
			{
				System.Windows.MessageBox.Show(owner, "历史配置中没有找到缺失入口。若旧版已多次覆盖配置，仍可能需要从你保留的完整备份中恢复。", "找回旧版入口");
				return;
			}
			Window w = FeatureUi.Dialog("找回旧版入口与分组", owner, 760.0, 580.0);
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(22.0)
			};
			w.Content = dockPanel;
			TextBlock element = new TextBlock
			{
				Text = "从升级前配置、安全副本和完整备份中找回入口或分组归属。勾选后合并到当前布局；当前 DIY 保留。标注为已移除的入口默认不勾选。",
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
			};
			DockPanel.SetDock(element, System.Windows.Controls.Dock.Top);
			dockPanel.Children.Add(element);
			WrapPanel wrapPanel = new WrapPanel();
			DockPanel.SetDock(wrapPanel, System.Windows.Controls.Dock.Bottom);
			dockPanel.Children.Add(wrapPanel);
			StackPanel stackPanel = new StackPanel();
			dockPanel.Children.Add(new ScrollViewer
			{
				Content = stackPanel,
				VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
				HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
			});
			Dictionary<Entry, System.Windows.Controls.CheckBox> choices = new Dictionary<Entry, System.Windows.Controls.CheckBox>();
			foreach (Entry item in list)
			{
				bool flag = RemovalRules.Blocked(Prefs, item);
				System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox();
				checkBox.Content = new TextBlock
				{
					Text = item.Name + " · " + string.Join("、", FeatureRules.Memberships(item)) + (flag ? " 【曾移除】" : "") + "\n" + item.Path,
					TextWrapping = TextWrapping.Wrap
				};
				checkBox.IsChecked = !flag;
				checkBox.Margin = new Thickness(0.0, 6.0, 0.0, 10.0);
				System.Windows.Controls.CheckBox checkBox2 = checkBox;
				choices.Add(item, checkBox2);
				stackPanel.Children.Add(checkBox2);
			}
			wrapPanel.Children.Add(FeatureUi.Button("全选", delegate
			{
				foreach (System.Windows.Controls.CheckBox value in choices.Values)
				{
					value.IsChecked = true;
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("取消全选", delegate
			{
				foreach (System.Windows.Controls.CheckBox value2 in choices.Values)
				{
					value2.IsChecked = false;
				}
			}));
			wrapPanel.Children.Add(FeatureUi.Button("合并所选入口", delegate
			{
				List<Entry> list2 = (from x in choices
					where x.Value.IsChecked == true
					select x.Key).ToList();
				if (list2.Count != 0)
				{
					FlushBackupState();
					string text = Path.Combine(Store.Folder, "backups", "找回入口前_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".gbbackup");
					Directory.CreateDirectory(Path.GetDirectoryName(text));
					BackupFiles.Create(Store.Folder, text);
					BoardEditState before = BeginBoardEdit();
					int num = EntryRecoveryRules.Restore(Prefs, list2);
					EndBoardEdit(before, "找回旧版入口");
					Refresh();
					System.Windows.MessageBox.Show(w, "已合并 " + num + " 个入口及分组归属。", "找回完成");
					w.Close();
				}
			}));
			w.ShowDialog();
		}
		catch (Exception ex)
		{
			Store.Log(ex);
			System.Windows.MessageBox.Show(owner, ex.Message, "找回未完成");
		}
		finally
		{
			Board.ModalBusy = modalBusy;
		}
	}

	private void UpdateState(string message)
	{
		updateMessage = message;
		this.UpdateChanged?.Invoke();
	}

	private async void StartUpdateCheck()
	{
		if (Prefs.AutoCheckUpdates && UpdateRules.Due(DateTime.UtcNow.Ticks, Prefs.LastUpdateCheckUtc))
		{
			await Task.Delay(3000);
			if (!ShuttingDown && Prefs.AutoCheckUpdates && UpdateRules.Due(DateTime.UtcNow.Ticks, Prefs.LastUpdateCheckUtc))
			{
				await CheckUpdate(manual: false);
			}
		}
	}

	private async Task CheckUpdate(bool manual)
	{
		if (updateBusy || ShuttingDown)
		{
			return;
		}
		updateBusy = true;
		UpdateState("正在检查版本…");
		try
		{
			updateOffer = await UpdateService.Check(Prefs.UpdateDirectConnection);
			if (ShuttingDown)
			{
				return;
			}
			Prefs.LastUpdateCheckUtc = DateTime.UtcNow.Ticks;
			Save();
			WriteUpdateDiagnostics();
			if (ShuttingDown)
			{
				return;
			}
			if (updateOffer == null)
			{
				UpdateState("仓库暂时没有可用的用户版更新包。");
				return;
			}
			if (updateOffer.Version <= CurrentVersion)
			{
				UpdateState("当前无需更新。已安装 v" + CurrentVersion.ToString(3) + "；仓库最新 v" + updateOffer.Version.ToString(3) + "。");
				return;
			}
			UpdateState("发现 v" + updateOffer.Version.ToString(3) + " · " + Math.Round((double)updateOffer.Size / 1024.0) + " KB\n" + updateOffer.Notes);
			if (!manual && Prefs.AutoCheckUpdates && Tray != null)
			{
				Tray.ShowBalloonTip(6000, "GlassBoard 有新版本", "v" + updateOffer.Version.ToString(3) + " 已发布。进入设置 → 通用 → 软件更新查看。", ToolTipIcon.Info);
			}
		}
		catch (Exception ex)
		{
			if (!ShuttingDown)
			{
				WriteUpdateDiagnostics();
				updateOffer = null;
				UpdateState("检查未完成：" + ex.Message + "\n离线功能不受影响，可以稍后手动重试。");
			}
		}
		finally
		{
			updateBusy = false;
			if (!ShuttingDown)
			{
				UpdateState(updateMessage);
			}
		}
	}

	private void WriteUpdateDiagnostics()
	{
		try
		{
			File.WriteAllText(Path.Combine(Store.Folder, "update.log"), UpdateService.LastDiagnostics ?? "尚无更新诊断");
		}
		catch (Exception ex)
		{
			Store.Log(ex);
		}
	}

	private void BuildUpdateSettings(StackPanel panel, Window owner)
	{
		panel.Children.Add(new TextBlock
		{
			Text = "软件更新 · 当前 v" + CurrentVersion.ToString(3),
			FontSize = 18.0,
			Margin = new Thickness(0.0, 22.0, 0.0, 10.0)
		});
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = "启动时自动检查新版本（默认关闭）",
			IsChecked = Prefs.AutoCheckUpdates,
			Foreground = System.Windows.Media.Brushes.White,
			Margin = new Thickness(0.0, 6.0, 0.0, 8.0)
		};
		panel.Children.Add(checkBox);
		checkBox.Checked += delegate
		{
			Prefs.AutoCheckUpdates = true;
			Save();
			StartUpdateCheck();
		};
		checkBox.Unchecked += delegate
		{
			Prefs.AutoCheckUpdates = false;
			Save();
		};
		System.Windows.Controls.ComboBox connection = new System.Windows.Controls.ComboBox
		{
			ItemsSource = new string[2] { "使用 Windows 系统代理（默认）", "直接连接（忽略系统代理）" },
			SelectedIndex = (Prefs.UpdateDirectConnection ? 1 : 0),
			Margin = new Thickness(0.0, 4.0, 0.0, 12.0),
			MinHeight = 36.0
		};
		panel.Children.Add(connection);
		connection.SelectionChanged += delegate
		{
			Prefs.UpdateDirectConnection = connection.SelectedIndex == 1;
			Save();
		};
		panel.Children.Add(new TextBlock
		{
			Text = "开启后最多每天检查一次；发现新版后由你选择更新。无需 GitHub 登录，离线时仍可使用。更新前备份配置，不新增常驻更新进程。",
			TextWrapping = TextWrapping.Wrap,
			Foreground = System.Windows.Media.Brushes.LightGray
		});
		TextBlock status = new TextBlock
		{
			TextWrapping = TextWrapping.Wrap,
			Foreground = System.Windows.Media.Brushes.LightGray,
			Margin = new Thickness(0.0, 10.0, 0.0, 10.0)
		};
		panel.Children.Add(status);
		WrapPanel wrapPanel = new WrapPanel();
		panel.Children.Add(wrapPanel);
		System.Windows.Controls.Button check = FeatureUi.Button("立即检查", async delegate
		{
			await CheckUpdate(manual: true);
		});
		System.Windows.Controls.Button install = FeatureUi.Button("下载并更新", async delegate
		{
			await InstallUpdate();
		});
		System.Windows.Controls.Button cancel = FeatureUi.Button("取消下载", delegate
		{
			if (updateCancel != null)
			{
				updateCancel.Cancel();
			}
		});
		wrapPanel.Children.Add(check);
		wrapPanel.Children.Add(install);
		wrapPanel.Children.Add(cancel);
		wrapPanel.Children.Add(FeatureUi.Button("连接诊断", delegate
		{
			System.Windows.MessageBox.Show(owner, UpdateService.LastDiagnostics ?? "请先点击立即检查。", "更新连接诊断");
		}));
		wrapPanel.Children.Add(FeatureUi.Button("查看发布仓库", delegate
		{
			Process.Start(new ProcessStartInfo("https://github.com/SENLIN-SAMA/win-.-")
			{
				UseShellExecute = true
			});
		}));
		Action refresh = delegate
		{
			status.Text = updateMessage;
			check.IsEnabled = !updateBusy;
			install.IsEnabled = !updateBusy && updateOffer != null && updateOffer.Version > CurrentVersion;
			cancel.IsEnabled = updateCancel != null;
		};
		UpdateChanged += refresh;
		owner.Closed += delegate
		{
			UpdateChanged -= refresh;
		};
		refresh();
	}

	private async Task InstallUpdate()
	{
		if (updateBusy || updateOffer == null || updateOffer.Version <= CurrentVersion)
		{
			return;
		}
		UpdateOffer offer = updateOffer;
		if (System.Windows.MessageBox.Show("下载 v" + offer.Version.ToString(3) + "？\n下载和校验完成后，软件会退出、更新并重新启动。\n你的布局、便签和其他配置会保留，并提前备份。", "GlassBoard 软件更新", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
		{
			return;
		}
		string job = null;
		bool ready = false;
		updateBusy = true;
		updateCancel = new CancellationTokenSource();
		UpdateState("正在下载更新…");
		try
		{
			byte[] bytes = await UpdateService.Download(offer, updateCancel.Token, delegate(long received, long total)
			{
				Dock.Dispatcher.BeginInvoke((Action)delegate
				{
					if (!ShuttingDown)
					{
						UpdateState("正在下载：" + Math.Round((double)received / 1024.0) + " KB" + ((total > 0) ? (" / " + Math.Round((double)total / 1024.0) + " KB") : ""));
					}
				});
			}, Prefs.UpdateDirectConnection);
			updateCancel.Token.ThrowIfCancellationRequested();
			if (ShuttingDown)
			{
				return;
			}
			UpdateState("正在校验并准备更新…");
			job = Path.Combine(Store.Folder, "updates", Guid.NewGuid().ToString("N"));
			string stage = Path.Combine(job, "stage");
			Dictionary<string, string> files = await Task.Run(() => UpdateApply.Extract(bytes, stage, offer.Version));
			updateCancel.Token.ThrowIfCancellationRequested();
			if (ShuttingDown)
			{
				return;
			}
			string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".glassboard-update-probe-" + Guid.NewGuid().ToString("N"));
			try
			{
				using (File.Create(path))
				{
				}
				File.Delete(path);
			}
			catch (Exception innerException)
			{
				throw new IOException("程序目录不可写，请把完整程序文件夹放到可写位置后更新。", innerException);
			}
			FlushBackupState();
			string text = Path.Combine(Store.Folder, "backups", "更新前_" + CurrentVersion.ToString(3) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".gbbackup");
			Directory.CreateDirectory(Path.GetDirectoryName(text));
			BackupFiles.Create(Store.Folder, text);
			string text2 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "GlassBoard.Updater.exe");
			if (!File.Exists(text2))
			{
				throw new FileNotFoundException("缺少更新助手，请解压完整用户版。", text2);
			}
			string text3 = Path.Combine(job, "worker.exe");
			File.Copy(text2, text3);
			UpdatePlan graph = new UpdatePlan
			{
				Pid = Process.GetCurrentProcess().Id,
				Target = AppDomain.CurrentDomain.BaseDirectory,
				Stage = stage,
				Backup = Path.Combine(job, "program-backup"),
				Version = offer.Version.ToString(),
				Files = files
			};
			string text4 = Path.Combine(job, "plan.json");
			using (FileStream stream = File.Create(text4))
			{
				new DataContractJsonSerializer(typeof(UpdatePlan)).WriteObject(stream, graph);
			}
			Process.Start(new ProcessStartInfo(text3, "\"" + text4 + "\"")
			{
				UseShellExecute = true,
				WorkingDirectory = job
			});
			ready = true;
			Save();
			Quit();
		}
		catch (Exception ex)
		{
			if (!ShuttingDown)
			{
				UpdateState(updateCancel.IsCancellationRequested ? "下载已取消，当前版本保持不变。" : ("更新未开始：" + ex.Message + "\n尚未替换程序，可以继续使用当前版本。"));
			}
		}
		finally
		{
			updateCancel.Dispose();
			updateCancel = null;
			updateBusy = false;
			if (!ShuttingDown)
			{
				UpdateState(updateMessage);
			}
			if (!ready && job != null)
			{
				try
				{
					Directory.Delete(job, recursive: true);
				}
				catch
				{
				}
			}
		}
	}

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetCurrentProcess();

	[DllImport("kernel32.dll")]
	private static extern bool SetProcessWorkingSetSize(IntPtr P_0, IntPtr P_1, IntPtr P_2);
}

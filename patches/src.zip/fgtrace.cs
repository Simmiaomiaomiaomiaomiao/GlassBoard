using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

class FgTrace {
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassNameW(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowTextW(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsZoomed(IntPtr h);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowW(string cls, string title);
    [DllImport("user32.dll")] static extern int GetWindowLongW(IntPtr h, int idx);

    [StructLayout(LayoutKind.Sequential)]
    struct RECT { public int Left, Top, Right, Bottom; }

    static string ProcName(uint pid) {
        try { return Process.GetProcessById((int)pid).ProcessName; } catch { return "?"; }
    }

    static string Snap() {
        IntPtr h = GetForegroundWindow();
        var cls = new StringBuilder(256); GetClassNameW(h, cls, 256);
        var ttl = new StringBuilder(256); GetWindowTextW(h, ttl, 256);
        uint pid = 0; GetWindowThreadProcessId(h, out pid);
        RECT r = new RECT(); GetWindowRect(h, out r);
        IntPtr prog = FindWindowW("Progman", null);
        IntPtr tray = FindWindowW("Shell_TrayWnd", null);
        IntPtr dock = FindWindowW(null, "GlassBoard Dock");
        IntPtr board = FindWindowW(null, "GlassBoard 应用启动台");
        int ex = GetWindowLongW(h, -20);
        bool topmost = (ex & 0x8) != 0;
        return string.Format(
            "fg={0} p={1}({2}) vis={3} min={4} max={5} topmost={6} rect={7},{8},{9},{10} cls='{11}' title='{12}' | desktop={13} taskbar={14} dock={15} board={16}",
            h.ToInt64(), pid, ProcName(pid), IsWindowVisible(h), IsIconic(h), IsZoomed(h), topmost,
            r.Left, r.Top, r.Right, r.Bottom, cls, ttl,
            IsWindowVisible(prog), IsWindowVisible(tray), IsWindowVisible(dock), IsWindowVisible(board));
    }

    static void Main() {
        string path = @"D:\GlassBoard\patches\fg_trace.log";
        string last = "";
        var w = new StreamWriter(path, true, new UTF8Encoding(false));
        w.AutoFlush = true;
        w.WriteLine("=== trace start " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        while (true) {
            string s;
            try { s = Snap(); } catch { Thread.Sleep(200); continue; }
            if (s != last) {
                w.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff") + " " + s);
                last = s;
            }
            Thread.Sleep(150);
        }
    }
}

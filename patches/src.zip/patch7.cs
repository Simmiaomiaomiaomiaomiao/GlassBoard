using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch7 {
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch7 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        int removed = 0;

        foreach (var t in mod.Types) {
            foreach (var n in t.NestedTypes) { }
            foreach (var m in t.Methods) {
                if (!m.HasBody) continue;
                foreach (var ins in m.Body.Instructions) {
                    if (ins.OpCode != OpCodes.Ldstr) continue;
                    string s = ins.Operand as string;
                    if (s != null && s.IndexOf("Sama", StringComparison.OrdinalIgnoreCase) >= 0) {
                        ins.Operand = "";
                        removed++;
                        Console.WriteLine("watermark cleared in " + t.Name + "." + m.Name);
                    }
                }
            }
        }

        if (removed == 0) { Console.WriteLine("ERROR: watermark string not found"); return 1; }

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (cleared " + removed + ")");
        return 0;
    }
}

using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch4 {
    static MethodDefinition AddPinvoke(ModuleDefinition mod, TypeDefinition t, string entry, TypeReference ret, TypeReference[] args) {
        var m = new MethodDefinition(entry,
            MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig | MethodAttributes.PInvokeImpl,
            ret);
        foreach (var a in args) m.Parameters.Add(new ParameterDefinition(a));
        ModuleReference mr = mod.ModuleReferences.FirstOrDefault(x =>
            string.Equals(x.Name, "user32", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x.Name, "user32.dll", StringComparison.OrdinalIgnoreCase));
        if (mr == null) { mr = new ModuleReference("user32.dll"); mod.ModuleReferences.Add(mr); }
        m.PInvokeInfo = new PInvokeInfo(PInvokeAttributes.CallConvWinapi, entry, mr);
        m.ImplAttributes |= MethodImplAttributes.PreserveSig;
        t.Methods.Add(m);
        return m;
    }

    static bool IsCallTo(Instruction i, string type, string name) {
        if (i.OpCode != OpCodes.Call && i.OpCode != OpCodes.Callvirt) return false;
        var mr = i.Operand as MethodReference;
        return mr != null && mr.Name == name && mr.DeclaringType != null && mr.DeclaringType.Name == type;
    }

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch4 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var fs = mod.GetType("GlassBoard.FullscreenState");
        if (fs == null) { Console.WriteLine("ERROR: FullscreenState not found"); return 1; }
        var active = fs.Methods.FirstOrDefault(x => x.Name == "Active" && x.HasBody);
        if (active == null) { Console.WriteLine("ERROR: Active() not found"); return 1; }

        // 幂等检查
        if (active.Body.Instructions.Any(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "WindowFromPoint")) {
            Console.WriteLine("ERROR: already patched"); return 1;
        }

        // 严格校验目标构建：第一条必须是 call FullscreenState::GetForegroundWindow，第二条 stloc.0
        var first = active.Body.Instructions[0];
        if (!IsCallTo(first, "FullscreenState", "GetForegroundWindow")) {
            Console.WriteLine("ERROR: unexpected first instruction in Active(): " + first.OpCode.Name + " (abort, do not patch)");
            return 1;
        }
        if (active.Body.Instructions[1].OpCode != OpCodes.Stloc_0) {
            Console.WriteLine("ERROR: instruction[1] is not stloc.0 (abort)");
            return 1;
        }

        var tInt = mod.TypeSystem.Int32;
        var tLong = mod.TypeSystem.Int64;
        var tPtr = mod.TypeSystem.IntPtr;
        var sm = AddPinvoke(mod, fs, "GetSystemMetrics", tInt, new[] { tInt });
        var wfp = AddPinvoke(mod, fs, "WindowFromPoint", tPtr, new[] { tLong });
        var anc = AddPinvoke(mod, fs, "GetAncestor", tPtr, new[] { tPtr, tInt });
        var gwl = AddPinvoke(mod, fs, "GetWindowLongW", tInt, new[] { tPtr, tInt });

        var il = active.Body.GetILProcessor();

        // 1) 探针：屏幕中心最顶层窗口的根窗口
        var seq1 = new Instruction[] {
            il.Create(OpCodes.Ldc_I4_1),
            il.Create(OpCodes.Call, sm),
            il.Create(OpCodes.Ldc_I4_2),
            il.Create(OpCodes.Div),
            il.Create(OpCodes.Conv_I8),
            il.Create(OpCodes.Ldc_I4_S, (sbyte)32),
            il.Create(OpCodes.Shl),
            il.Create(OpCodes.Ldc_I4_0),
            il.Create(OpCodes.Call, sm),
            il.Create(OpCodes.Ldc_I4_2),
            il.Create(OpCodes.Div),
            il.Create(OpCodes.Conv_U8),
            il.Create(OpCodes.Or),
            il.Create(OpCodes.Call, wfp),
            il.Create(OpCodes.Ldc_I4_2),
            il.Create(OpCodes.Call, anc)
        };
        Instruction prev = null;
        foreach (var ins in seq1) {
            if (prev == null) il.InsertBefore(first, ins);
            else il.InsertAfter(prev, ins);
            prev = ins;
        }
        il.Remove(first);

        // 2) 排除带标题栏的窗口：最大化普通窗口的不可见边框会让 GetWindowRect 超过屏幕，误判成全屏
        Instruction contains = null;
        foreach (var i in active.Body.Instructions) {
            if (i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "Contains" && ((MethodReference)i.Operand).DeclaringType.Name == "Enumerable") {
                contains = i; break;
            }
        }
        if (contains == null) { Console.WriteLine("ERROR: class-name filter not found (abort)"); return 1; }
        Instruction branch = contains.Next;
        if (branch.OpCode != OpCodes.Brfalse_S || !(branch.Operand is Instruction)) {
            Console.WriteLine("ERROR: unexpected instruction after Contains (abort)"); return 1;
        }
        Instruction after = (Instruction)branch.Operand;

        var seq2 = new Instruction[] {
            il.Create(OpCodes.Ldloc_0),
            il.Create(OpCodes.Ldc_I4_S, (sbyte)-16),        // GWL_STYLE
            il.Create(OpCodes.Call, gwl),
            il.Create(OpCodes.Ldc_I4, 0x00C00000),          // WS_CAPTION
            il.Create(OpCodes.And),
            il.Create(OpCodes.Brfalse_S, after),
            il.Create(OpCodes.Ldc_I4_0),
            il.Create(OpCodes.Ret)
        };
        prev = null;
        foreach (var ins in seq2) {
            if (prev == null) il.InsertBefore(after, ins);
            else il.InsertAfter(prev, ins);
            prev = ins;
        }
        // 关键：类名过滤的 brfalse 原本直接跳到汇合点，会把上面插入的检查整段绕过（死代码）
        // 把它的目标改到插入序列的第一条，保证两条路径都经过标题栏检查
        branch.Operand = seq2[0];

        if (active.Body.MaxStackSize < 4) active.Body.MaxStackSize = 4;

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1]);
        return 0;
    }
}

using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch9b {
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch9b <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ctrl = mod.GetType("GlassBoard.Controller");
        if (ctrl == null) { Console.WriteLine("ERROR: Controller not found"); return 1; }
        var settings = ctrl.Methods.FirstOrDefault(x => x.Name == "Settings" && x.HasBody);
        if (settings == null) { Console.WriteLine("ERROR: Settings not found"); return 1; }
        var ins = settings.Body.Instructions;

        Instruction stfld = null;
        foreach (var i in ins) {
            if (i.OpCode == OpCodes.Stfld) {
                var fr = i.Operand as FieldReference;
                if (fr != null && fr.Name == "creatorPage") { stfld = i; break; }
            }
        }
        if (stfld == null) { Console.WriteLine("ERROR: creatorPage assignment not found"); return 1; }

        // 赋值前三条是: ldloc.s V_7 / ldstr "支持创作者" / callvirt Func.Invoke
        Instruction callInvoke = stfld.Previous;
        Instruction ldstrIns = callInvoke.Previous;
        Instruction ldlocV7 = ldstrIns.Previous;
        Console.WriteLine("prev chain: " + ldlocV7.OpCode.Name + " / " + ldstrIns.OpCode.Name + " / " + callInvoke.OpCode.Name);

        var il = settings.Body.GetILProcessor();
        // 用 ldnull 顶替 makeTab(...)：Tab 根本不会被创建，也就不会进入 TabControl
        il.InsertBefore(ldstrIns, il.Create(OpCodes.Ldnull));
        il.Remove(ldlocV7);
        il.Remove(ldstrIns);
        il.Remove(callInvoke);

        // 选择索引上限 5 -> 4（只剩 5 个 Tab）
        int clamped = 0;
        for (int k = 0; k < settings.Body.Instructions.Count; k++) {
            var cur = settings.Body.Instructions[k];
            var mrSel = cur.Operand as MethodReference;
            if (cur.OpCode == OpCodes.Callvirt && mrSel != null && mrSel.Name == "set_SelectedIndex") {
                for (int j = k - 1; j >= Math.Max(0, k - 8); j--) {
                    var cand = settings.Body.Instructions[j];
                    if (cand.OpCode == OpCodes.Ldc_I4_5) { cand.OpCode = OpCodes.Ldc_I4_4; clamped++; break; }
                }
            }
        }
        Console.WriteLine("clamped Min(5,...) occurrences: " + clamped);
        if (clamped == 0) { Console.WriteLine("WARN: index clamp not found"); }

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1]);
        return 0;
    }
}

using System;
using System.Runtime.InteropServices;

class HotkeyTest {
    [DllImport("user32.dll", SetLastError = true)] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] static extern IntPtr GetDesktopWindow();
    [DllImport("user32.dll", SetLastError = true)] static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    static void Test(string label, int id, uint mods, uint vk) {
        IntPtr h = GetDesktopWindow();
        bool ok = RegisterHotKey(h, id, mods, vk);
        int err = Marshal.GetLastWin32Error();
        Console.WriteLine(label + " -> " + (ok ? "FREE (可注册)" : "TAKEN (被占用) err=" + err));
        if (ok) UnregisterHotKey(h, id);
    }

    static void Main() {
        uint MOD_WIN = 0x8;
        uint MOD_CONTROL = 0x2;
        uint MOD_ALT = 0x1;
        Test("Win+D        ", 1, MOD_WIN, 0x44);
        Test("Win+E        ", 2, MOD_WIN, 0x45);
        Test("Win+R        ", 3, MOD_WIN, 0x52);
        Test("Win+Tab      ", 4, MOD_WIN, 0x09);
        Test("Ctrl+Alt+D   ", 5, MOD_CONTROL | MOD_ALT, 0x44);
        Test("Ctrl+Alt+Space", 6, MOD_CONTROL | MOD_ALT, 0x20);
    }
}

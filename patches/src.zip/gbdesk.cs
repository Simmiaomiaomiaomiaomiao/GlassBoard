using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

class GbDesk : NativeWindow {
    const int WM_HOTKEY = 0x0312;
    const int HOTKEY_ID = 0xB10C;
    const uint MOD_ALT = 0x1;
    const uint MOD_CONTROL = 0x2;
    const uint MOD_NOREPEAT = 0x4000;

    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowTextW(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowW(string cls, string title);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lp);
    delegate bool EnumProc(IntPtr h, IntPtr lp);

    static readonly string LogPath = @"D:\GlassBoard\patches\gbdesk.log";
    static uint myPid = (uint)System.Diagnostics.Process.GetCurrentProcess().Id;

    static void Log(string s) {
        try { File.AppendAllText(LogPath, DateTime.Now.ToString("HH:mm:ss.fff") + " " + s + "\r\n"); } catch { }
    }

    static int Count = 0;

    public GbDesk() {
        CreateHandle(new CreateParams());
    }

    protected override void WndProc(ref Message m) {
        if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID) {
            Count++;
            Log("hotkey pressed #" + Count);
            ShowDesktop();
            Log("desktop command sent");
        }
        base.WndProc(ref m);
    }

    static void ShowDesktop() {
        IntPtr fg = GetForegroundWindow();
        uint pid = 0;
        if (fg != IntPtr.Zero) GetWindowThreadProcessId(fg, out pid);

        // 先最小化前台窗口（游戏），这是最直接的一步
        if (fg != IntPtr.Zero) ShowWindow(fg, 6);

        // 再把其余仍然可见的顶层窗口最小化，确保桌面真的露出来
        EnumWindows(delegate(IntPtr h, IntPtr lp) {
            if (!IsWindowVisible(h)) return true;
            if (IsIconic(h)) return true;
            uint p = 0;
            GetWindowThreadProcessId(h, out p);
            if (p == myPid) return true;
            if (h == FindWindowW("Shell_TrayWnd", null)) return true;
            if (h == FindWindowW("Shell_SecondaryTrayWnd", null)) return true;
            if (h == FindWindowW("Progman", null)) return true;
            var title = new StringBuilder(200);
            GetWindowTextW(h, title, 200);
            if (title.Length == 0) return true;
            ShowWindow(h, 6);
            return true;
        }, IntPtr.Zero);

        // 恢复任务栏（如果被隐藏）
        IntPtr tray = FindWindowW("Shell_TrayWnd", null);
        if (tray != IntPtr.Zero && !IsWindowVisible(tray)) ShowWindow(tray, 5);
    }

    [STAThread]
    static void Main() {
        var host = new GbDesk();
        bool ok = RegisterHotKey(host.Handle, HOTKEY_ID, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, 0x51); // Ctrl+Alt+Q
        Log("start register=" + ok);
        if (!ok) {
            MessageBox.Show("Ctrl+Alt+Q 注册失败，可能被其它程序占用。", "GlassBoard 回桌面");
            return;
        }
        Application.Run();
    }
}

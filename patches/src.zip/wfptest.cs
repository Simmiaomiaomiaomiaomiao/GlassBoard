using System;
using System.Runtime.InteropServices;
using System.Text;

class WfpTest {
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(long pt);
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassNameW(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowTextW(IntPtr h, StringBuilder sb, int n);

    static void Show(IntPtr h, string label) {
        var c = new StringBuilder(256); GetClassNameW(h, c, 256);
        var t = new StringBuilder(256); GetWindowTextW(h, t, 256);
        Console.WriteLine(label + " hwnd=" + h.ToInt64() + " class=" + c + " title=" + t);
    }

    static void Main() {
        int cx = GetSystemMetrics(0) / 2;
        int cy = GetSystemMetrics(1) / 2;
        long packed = ((long)(uint)cy << 32) | (uint)cx;
        Console.WriteLine("screen center " + cx + "," + cy + " packed=0x" + packed.ToString("X"));
        Show(WindowFromPoint(packed), "WindowFromPoint(center):");
        Show(GetForegroundWindow(), "GetForegroundWindow():");
    }
}

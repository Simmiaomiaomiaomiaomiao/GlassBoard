using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch14 {
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch14 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ww = mod.GetType("GlassBoard.WidgetWindow");
        if (ww == null) { Console.WriteLine("ERROR: WidgetWindow not found"); return 1; }
        var weather = ww.Methods.FirstOrDefault(x => x.Name == "Weather" && x.HasBody);
        if (weather == null) { Console.WriteLine("ERROR: Weather not found"); return 1; }

        var ins = weather.Body.Instructions;
        if (ins.Any(i => i.OpCode == OpCodes.Ldc_R8 && i.Operand != null && Math.Abs((double)i.Operand - 34.0) < 0.001)) {
            Console.WriteLine("already patched (patch14)");
            return 0;
        }

        var il = weather.Body.GetILProcessor();
        var vars = weather.Body.Variables;
        if (vars.Count < 5) { Console.WriteLine("ERROR: unexpected locals"); return 1; }
        var v2 = vars[2];
        var v3 = vars[3];
        var v4 = vars[4];

        var setColumn = RefFrom(ww, "Grid", "SetColumn");
        var getCols = RefFrom(ww, "Grid", "get_ColumnDefinitions");
        var colCtor = RefFrom(ww, "ColumnDefinition", ".ctor");
        var setWidth = RefFrom(ww, "ColumnDefinition", "set_Width");
        var colAdd = RefFrom(ww, "ColumnDefinitionCollection", "Add");
        var getChildren = RefFrom(ww, "Panel", "get_Children");
        var setFont = RefFrom(ww, "Control", "set_FontSize");
        var smallCall = RefFrom(ww, "WidgetWindow", "Small");
        if (setColumn == null || getCols == null || colCtor == null || setWidth == null || colAdd == null ||
            getChildren == null || setFont == null || smallCall == null) {
            Console.WriteLine("ERROR: required references not found");
            return 1;
        }
        var gridLengthCtor = FindInType(ww, "GridLength", ".ctor");
        var setHeight = FindInType(ww, "FrameworkElement", "set_Height");
        var setVAlign = FindInType(ww, "FrameworkElement", "set_VerticalAlignment");
        var thicknessCtor = RefFrom(ww, "Thickness", ".ctor");
        var setMarginRef = RefFrom(ww, "FrameworkElement", "set_Margin");
        if (gridLengthCtor == null || setHeight == null || setVAlign == null || thicknessCtor == null || setMarginRef == null) {
            Console.WriteLine("ERROR: WPF member references not found");
            return 1;
        }
        var glType = ((MethodReference)gridLengthCtor).DeclaringType;
        var autoGetter = new MethodReference("get_Auto", glType, glType);
        autoGetter.HasThis = false;

        // 1) 删除温度行第二个 60px 列（第 5 条 ldc.r8 60 往前 4 条、往后 3 条）
        var col60 = ins.FirstOrDefault(i => i.OpCode == OpCodes.Ldc_R8 && i.Operand != null && Math.Abs((double)i.Operand - 60.0) < 0.001);
        if (col60 == null) { Console.WriteLine("ERROR: 60px column not found"); return 1; }
        var toRemove = new System.Collections.Generic.List<Instruction>();
        var p = col60;
        for (int k = 0; k < 4 && p != null; k++) p = p.Previous;
        for (int k = 0; k < 8 && p != null; k++) { toRemove.Add(p); p = p.Next; }
        if (toRemove.Count != 8 || toRemove.Last().OpCode != OpCodes.Callvirt) { Console.WriteLine("ERROR: column removal pattern mismatch"); return 1; }
        foreach (var x in toRemove) il.Remove(x);

        // 2) 删除 weatherIcon 的 SetColumn + Add（图标不再进入视觉树）
        var setCol = ins.FirstOrDefault(i => i.OpCode == OpCodes.Call && i.Operand == setColumn);
        if (setCol == null) { Console.WriteLine("ERROR: SetColumn call not found"); return 1; }
        var rm2 = new System.Collections.Generic.List<Instruction>();
        p = setCol;
        for (int k = 0; k < 3 && p != null; k++) p = p.Previous;
        for (int k = 0; k < 10 && p != null; k++) { rm2.Add(p); p = p.Next; }
        if (rm2.Count != 10 || rm2.Last().OpCode != OpCodes.Pop) { Console.WriteLine("ERROR: icon removal pattern mismatch"); return 1; }
        foreach (var x in rm2) il.Remove(x);

        // 3) weatherStatus 改为放进 V_2 的第 0 列
        var wsField = ins.FirstOrDefault(i => i.OpCode == OpCodes.Ldfld && i.Operand is FieldReference && ((FieldReference)i.Operand).Name == "weatherStatus");
        if (wsField == null || wsField.Previous == null || wsField.Previous.OpCode != OpCodes.Ldarg_0 ||
            wsField.Previous.Previous == null || wsField.Previous.Previous.OpCode != OpCodes.Callvirt ||
            wsField.Previous.Previous.Previous == null || wsField.Previous.Previous.Previous.OpCode != OpCodes.Ldarg_1) {
            Console.WriteLine("ERROR: weatherStatus add pattern mismatch"); return 1;
        }
        var oldContainer = wsField.Previous.Previous.Previous;
        var seqStatus = new Instruction[] {
            il.Create(OpCodes.Ldarg_0),
            il.Create(OpCodes.Ldfld, wsField.Operand as FieldReference),
            il.Create(OpCodes.Ldc_I4_0),
            il.Create(OpCodes.Call, setColumn)
        };
        Instruction prev = oldContainer.Previous;
        foreach (var x in seqStatus) { il.InsertAfter(prev, x); prev = x; }
        var ldloc2 = il.Create(OpCodes.Ldloc, v2);
        il.InsertBefore(oldContainer, ldloc2);
        il.Remove(oldContainer);

        // 4) V_2 加两列，都按内容宽度（Auto），状态文本与按钮紧挨
        var st2 = ins.FirstOrDefault(i => i.OpCode == OpCodes.Stloc_2);
        if (st2 == null) { Console.WriteLine("ERROR: v2 stloc not found"); return 1; }
        var seqCols = new Instruction[] {
            il.Create(OpCodes.Ldloc, v2),
            il.Create(OpCodes.Callvirt, getCols),
            il.Create(OpCodes.Newobj, colCtor),
            il.Create(OpCodes.Dup),
            il.Create(OpCodes.Call, autoGetter),
            il.Create(OpCodes.Callvirt, setWidth),
            il.Create(OpCodes.Callvirt, colAdd),
            il.Create(OpCodes.Ldloc, v2),
            il.Create(OpCodes.Callvirt, getCols),
            il.Create(OpCodes.Newobj, colCtor),
            il.Create(OpCodes.Dup),
            il.Create(OpCodes.Call, autoGetter),
            il.Create(OpCodes.Callvirt, setWidth),
            il.Create(OpCodes.Callvirt, colAdd)
        };
        InsertAfter(il, st2, seqCols);

        // 5) V_3 放进第 1 列、垂直居中，左侧留一个空格的距离
        var st3 = ins.FirstOrDefault(i => i.OpCode == OpCodes.Stloc_3);
        if (st3 == null) { Console.WriteLine("ERROR: v3 stloc not found"); return 1; }
        var seqBtn = new Instruction[] {
            il.Create(OpCodes.Ldloc, v3),
            il.Create(OpCodes.Ldc_I4_1),
            il.Create(OpCodes.Call, setColumn),
            il.Create(OpCodes.Ldloc, v3),
            il.Create(OpCodes.Ldc_I4_1),
            il.Create(OpCodes.Callvirt, setVAlign),
            il.Create(OpCodes.Ldloc, v3),
            il.Create(OpCodes.Ldc_R8, 5.0),
            il.Create(OpCodes.Ldc_R8, 0.0),
            il.Create(OpCodes.Ldc_R8, 0.0),
            il.Create(OpCodes.Ldc_R8, 0.0),
            il.Create(OpCodes.Newobj, thicknessCtor),
            il.Create(OpCodes.Callvirt, setMarginRef)
        };
        InsertAfter(il, st3, seqBtn);

        // 6) 刷新按钮：宽 45 -> 34，字号 9，高 22
        var small45 = ins.FirstOrDefault(i => i.OpCode == OpCodes.Call && i.Operand == smallCall &&
            i.Previous != null && i.Previous.OpCode == OpCodes.Ldc_R8 && (double)i.Previous.Operand == 45.0);
        if (small45 == null) { Console.WriteLine("ERROR: refresh button not found"); return 1; }
        small45.Previous.Operand = 34.0;
        var seqSmall = new Instruction[] {
            il.Create(OpCodes.Dup),
            il.Create(OpCodes.Ldc_R8, 9.0),
            il.Create(OpCodes.Callvirt, setFont),
            il.Create(OpCodes.Dup),
            il.Create(OpCodes.Ldc_R8, 22.0),
            il.Create(OpCodes.Callvirt, setHeight)
        };
        InsertAfter(il, small45, seqSmall);

        // 7) 天气来源按钮：宽 88 -> 62，字号 10 -> 9，高 22
        var small88 = ins.FirstOrDefault(i => i.OpCode == OpCodes.Call && i.Operand == smallCall &&
            i.Previous != null && i.Previous.OpCode == OpCodes.Ldc_R8 && (double)i.Previous.Operand == 88.0);
        if (small88 == null) { Console.WriteLine("ERROR: source button not found"); return 1; }
        small88.Previous.Operand = 62.0;
        var fontTen = ins.FirstOrDefault(i => i.OpCode == OpCodes.Callvirt && i.Operand == setFont &&
            i.Previous != null && i.Previous.OpCode == OpCodes.Ldc_R8 && (double)i.Previous.Operand == 10.0);
        if (fontTen == null) { Console.WriteLine("ERROR: source font size not found"); return 1; }
        fontTen.Previous.Operand = 9.0;
        var seqSource = new Instruction[] {
            il.Create(OpCodes.Ldloc, v4),
            il.Create(OpCodes.Ldc_R8, 22.0),
            il.Create(OpCodes.Callvirt, setHeight)
        };
        InsertAfter(il, fontTen, seqSource);

        weather.Body.MaxStackSize = 16;
        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (weather icon removed, buttons compacted into status row)");
        return 0;
    }

    static MethodReference RefFrom(TypeDefinition t, string typeName, string name) {
        foreach (var mm in t.Methods) {
            if (!mm.HasBody) continue;
            foreach (var i in mm.Body.Instructions) {
                var mr = i.Operand as MethodReference;
                if (mr != null && mr.Name == name && mr.DeclaringType.Name == typeName) return mr;
            }
        }
        return null;
    }

    static MethodReference FindInType(TypeDefinition t, string typeName, string name) {
        foreach (var mm in t.Methods) {
            if (!mm.HasBody) continue;
            foreach (var i in mm.Body.Instructions) {
                var mr = i.Operand as MethodReference;
                if (mr != null && mr.Name == name && mr.DeclaringType.Name == typeName) return mr;
            }
        }
        return null;
    }

    static void InsertAfter(ILProcessor il, Instruction anchor, Instruction[] seq) {
        Instruction prev = anchor;
        foreach (var x in seq) { il.InsertAfter(prev, x); prev = x; }
    }
}

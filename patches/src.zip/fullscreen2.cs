using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

class FullscreenTest2 : Form {
    public FullscreenTest2() {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = Screen.PrimaryScreen.Bounds;
        TopMost = false;
        BackColor = Color.Black;
        KeyPreview = true;
        var label = new Label();
        label.Text = "BORDERLESS FULLSCREEN (not topmost)";
        label.ForeColor = Color.Lime;
        label.Font = new Font("Consolas", 22);
        label.AutoSize = true;
        label.Location = new Point(60, 60);
        Controls.Add(label);
        Load += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs2.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " START hwnd=" + Handle.ToInt64() + "\r\n");
        };
        FormClosed += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs2.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " CLOSED\r\n");
        };
    }

    [STAThread]
    static void Main() {
        Application.EnableVisualStyles();
        Application.Run(new FullscreenTest2());
    }
}

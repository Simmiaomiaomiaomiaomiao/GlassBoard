using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch8 {
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch8 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ctrl = mod.GetType("GlassBoard.Controller");
        if (ctrl == null) { Console.WriteLine("ERROR: Controller not found"); return 1; }
        var settings = ctrl.Methods.FirstOrDefault(x => x.Name == "Settings" && x.HasBody);
        if (settings == null) { Console.WriteLine("ERROR: Settings not found"); return 1; }

        var ins = settings.Body.Instructions;
        Instruction anchor = null;
        foreach (var i in ins) {
            if (i.OpCode == OpCodes.Stfld) {
                var fr = i.Operand as FieldReference;
                if (fr != null && fr.Name == "creatorPage") { anchor = i; break; }
            }
        }
        if (anchor == null) { Console.WriteLine("ERROR: creatorPage assignment not found"); return 1; }

        // 复用模块里已有的 UIElement.set_Visibility 引用（避免跨程序集导入）
        MethodReference setVis = null;
        foreach (var t in mod.Types) {
            foreach (var m in t.Methods) {
                if (!m.HasBody) continue;
                foreach (var i in m.Body.Instructions) {
                    var mr = i.Operand as MethodReference;
                    if (mr != null && mr.Name == "set_Visibility" && mr.DeclaringType != null && mr.DeclaringType.Name == "UIElement") {
                        setVis = mr; break;
                    }
                }
                if (setVis != null) break;
            }
            if (setVis != null) break;
        }
        if (setVis == null) { Console.WriteLine("ERROR: UIElement.set_Visibility reference not found"); return 1; }

        // 幂等
        if (anchor.Next != null && anchor.Next.OpCode == OpCodes.Ldloc_2 && anchor.Next.Next != null && anchor.Next.Next.OpCode == OpCodes.Ldfld) {
            Console.WriteLine("already patched (patch8)");
            return 0;
        }

        var il = settings.Body.GetILProcessor();
        var seq = new Instruction[] {
            il.Create(OpCodes.Ldloc_2),
            il.Create(OpCodes.Ldfld, (FieldReference)anchor.Operand),
            il.Create(OpCodes.Ldc_I4_2),          // Visibility.Collapsed
            il.Create(OpCodes.Callvirt, setVis)
        };
        Instruction prev = anchor;
        foreach (var i in seq) { il.InsertAfter(prev, i); prev = i; }

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (creator tab collapsed)");
        return 0;
    }
}

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

class WinDFix {
    const int WH_KEYBOARD_LL = 13;
    const int WM_KEYDOWN = 0x0100;
    const int WM_KEYUP = 0x0101;
    const int WM_SYSKEYDOWN = 0x0104;
    const int WM_SYSKEYUP = 0x0105;
    const int VK_LWIN = 0x5B;
    const int VK_RWIN = 0x5C;
    const int VK_D = 0x44;

    delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder sb, int n);

    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll")] static extern bool SetProcessWorkingSetSize(IntPtr proc, IntPtr min, IntPtr max);

    static readonly string LogPath = @"D:\GlassBoard\patches\windfix.log";
    static bool winDown = false;
    static long lastTrigger = 0;
    static LowLevelKeyboardProc proc;

    static void Log(string s) {
        try { File.AppendAllText(LogPath, DateTime.Now.ToString("HH:mm:ss.fff") + " " + s + "\r\n"); } catch { }
    }

    static IntPtr Hook(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            int msg = (int)wParam;
            int vk = Marshal.ReadInt32(lParam);
            bool isDown = msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN;
            bool isUp = msg == WM_KEYUP || msg == WM_SYSKEYUP;

            if (isDown && (vk == VK_LWIN || vk == VK_RWIN)) winDown = true;
            if (isUp && (vk == VK_LWIN || vk == VK_RWIN)) winDown = false;

            if (isDown && vk == VK_D && winDown) {
                long now = Environment.TickCount;
                if (now - lastTrigger > 400) {
                    lastTrigger = now;
                    MinimizeForeground();
                }
            }
        }
        return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    static void MinimizeForeground() {
        IntPtr h = GetForegroundWindow();
        if (h == IntPtr.Zero) { Log("Win+D: no foreground window"); return; }
        var cls = new System.Text.StringBuilder(128);
        GetClassNameW(h, cls, 128);
        bool wasIconic = IsIconic(h);
        ShowWindow(h, 6);
        Log("Win+D -> minimized " + h.ToInt64() + " class=" + cls + " wasIconic=" + wasIconic);
    }

    // 工作集里会累计枚举窗口时加载的系统页面，定期让系统回收（私有内存不受影响）
    static void TrimLoop() {
        while (true) {
            Thread.Sleep(60000);
            try { SetProcessWorkingSetSize(GetCurrentProcess(), new IntPtr(-1), new IntPtr(-1)); } catch { }
        }
    }

    [STAThread]
    static void Main() {
        proc = Hook;
        IntPtr hook = SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(null), 0);
        Log("start hook=" + hook.ToInt64() + " err=" + Marshal.GetLastWin32Error());
        if (hook == IntPtr.Zero) {
            MessageBox.Show("键盘钩子安装失败，Win+D 兜底未生效。", "Win+D 兜底");
            return;
        }
        var t = new Thread(TrimLoop);
        t.IsBackground = true;
        t.Start();
        Application.Run();
        UnhookWindowsHookEx(hook);
    }
}

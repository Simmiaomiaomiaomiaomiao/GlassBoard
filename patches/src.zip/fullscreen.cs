using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

class FullscreenTest : Form {
    public FullscreenTest() {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = Screen.PrimaryScreen.Bounds;
        TopMost = true;
        BackColor = Color.Black;
        KeyPreview = true;
        var label = new Label();
        label.Text = "FULLSCREEN TEST - Alt+F4 or double click to close";
        label.ForeColor = Color.Lime;
        label.Font = new Font("Consolas", 24);
        label.AutoSize = true;
        label.Location = new Point(60, 60);
        Controls.Add(label);
        DoubleClick += delegate { Close(); };
        Load += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " START hwnd=" + Handle.ToInt64() + " pid=" + System.Diagnostics.Process.GetCurrentProcess().Id + "\r\n");
        };
        FormClosed += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " CLOSED\r\n");
        };
    }

    [STAThread]
    static void Main() {
        Application.EnableVisualStyles();
        Application.Run(new FullscreenTest());
    }
}

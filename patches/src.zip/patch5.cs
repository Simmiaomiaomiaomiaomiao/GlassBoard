using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch5 {
    static MethodDefinition AddPinvoke(ModuleDefinition mod, TypeDefinition t, string entry, TypeReference ret, TypeReference[] args) {
        var m = new MethodDefinition(entry,
            MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig | MethodAttributes.PInvokeImpl,
            ret);
        foreach (var a in args) m.Parameters.Add(new ParameterDefinition(a));
        ModuleReference mr = mod.ModuleReferences.FirstOrDefault(x =>
            string.Equals(x.Name, "user32", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x.Name, "user32.dll", StringComparison.OrdinalIgnoreCase));
        if (mr == null) { mr = new ModuleReference("user32.dll"); mod.ModuleReferences.Add(mr); }
        m.PInvokeInfo = new PInvokeInfo(PInvokeAttributes.CallConvWinapi, entry, mr);
        m.ImplAttributes |= MethodImplAttributes.PreserveSig;
        t.Methods.Add(m);
        return m;
    }

    static bool IsCallTo(Instruction i, string type, string name) {
        if (i.OpCode != OpCodes.Call && i.OpCode != OpCodes.Callvirt) return false;
        var mr = i.Operand as MethodReference;
        return mr != null && mr.Name == name && mr.DeclaringType != null && mr.DeclaringType.Name == type;
    }

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch5 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;

        // ================= 1. 全屏判定 =================
        var fs = mod.GetType("GlassBoard.FullscreenState");
        if (fs == null) { Console.WriteLine("ERROR: FullscreenState not found"); return 1; }
        var active = fs.Methods.FirstOrDefault(x => x.Name == "Active" && x.HasBody);
        if (active == null) { Console.WriteLine("ERROR: Active() not found"); return 1; }

        bool already = active.Body.Instructions.Any(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "WindowFromPoint");
        if (!already) {
            var first = active.Body.Instructions[0];
            if (!IsCallTo(first, "FullscreenState", "GetForegroundWindow")) {
                Console.WriteLine("ERROR: unexpected first instruction in Active(): " + first.OpCode.Name);
                return 1;
            }
            if (active.Body.Instructions[1].OpCode != OpCodes.Stloc_0) {
                Console.WriteLine("ERROR: instruction[1] is not stloc.0");
                return 1;
            }

            var tInt = mod.TypeSystem.Int32;
            var tLong = mod.TypeSystem.Int64;
            var tPtr = mod.TypeSystem.IntPtr;
            var sm = AddPinvoke(mod, fs, "GetSystemMetrics", tInt, new[] { tInt });
            var wfp = AddPinvoke(mod, fs, "WindowFromPoint", tPtr, new[] { tLong });
            var anc = AddPinvoke(mod, fs, "GetAncestor", tPtr, new[] { tPtr, tInt });
            var gwl = AddPinvoke(mod, fs, "GetWindowLongW", tInt, new[] { tPtr, tInt });

            var il = active.Body.GetILProcessor();

            // 探针：屏幕中心最顶层窗口的根窗口
            var seq1 = new Instruction[] {
                il.Create(OpCodes.Ldc_I4_1),
                il.Create(OpCodes.Call, sm),
                il.Create(OpCodes.Ldc_I4_2),
                il.Create(OpCodes.Div),
                il.Create(OpCodes.Conv_I8),
                il.Create(OpCodes.Ldc_I4_S, (sbyte)32),
                il.Create(OpCodes.Shl),
                il.Create(OpCodes.Ldc_I4_0),
                il.Create(OpCodes.Call, sm),
                il.Create(OpCodes.Ldc_I4_2),
                il.Create(OpCodes.Div),
                il.Create(OpCodes.Conv_U8),
                il.Create(OpCodes.Or),
                il.Create(OpCodes.Call, wfp),
                il.Create(OpCodes.Ldc_I4_2),
                il.Create(OpCodes.Call, anc)
            };
            Instruction prev = null;
            foreach (var ins in seq1) {
                if (prev == null) il.InsertBefore(first, ins);
                else il.InsertAfter(prev, ins);
                prev = ins;
            }
            il.Remove(first);

            // 排除带标题栏的窗口（最大化普通窗口的不可见边框会误判成全屏）
            Instruction contains = null;
            foreach (var i in active.Body.Instructions) {
                if (i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "Contains" && ((MethodReference)i.Operand).DeclaringType.Name == "Enumerable") {
                    contains = i; break;
                }
            }
            if (contains == null) { Console.WriteLine("ERROR: class-name filter not found"); return 1; }
            Instruction branch = contains.Next;
            if (branch.OpCode != OpCodes.Brfalse_S || !(branch.Operand is Instruction)) {
                Console.WriteLine("ERROR: unexpected instruction after Contains"); return 1;
            }
            Instruction after = (Instruction)branch.Operand;

            var seq2 = new Instruction[] {
                il.Create(OpCodes.Ldloc_0),
                il.Create(OpCodes.Ldc_I4_S, (sbyte)-16),
                il.Create(OpCodes.Call, gwl),
                il.Create(OpCodes.Ldc_I4, 0x00C00000),
                il.Create(OpCodes.And),
                il.Create(OpCodes.Brfalse_S, after),
                il.Create(OpCodes.Ldc_I4_0),
                il.Create(OpCodes.Ret)
            };
            prev = null;
            foreach (var ins in seq2) {
                if (prev == null) il.InsertBefore(after, ins);
                else il.InsertAfter(prev, ins);
                prev = ins;
            }
            branch.Operand = seq2[0];

            if (active.Body.MaxStackSize < 4) active.Body.MaxStackSize = 4;
            Console.WriteLine("fullscreen probe: patched");
        } else {
            Console.WriteLine("fullscreen probe: already patched, skipped");
        }

        // ================= 2. Dock 滚轮灵敏度 =================
        var wheelType = mod.GetType("GlassBoard.DockWheelState");
        if (wheelType == null) { Console.WriteLine("ERROR: DockWheelState not found"); return 1; }
        var scroll = wheelType.Methods.FirstOrDefault(x => x.Name == "Scroll" && x.HasBody);
        if (scroll == null) { Console.WriteLine("ERROR: DockWheelState.Scroll not found"); return 1; }

        var sins = scroll.Body.Instructions;
        bool throttleChanged = false;
        foreach (var i in sins) {
            if (i.OpCode == OpCodes.Ldc_I4 && i.Operand is int && (int)i.Operand == 280) {
                i.Operand = 100;              // 280ms 节流 -> 100ms
                throttleChanged = true;
                break;
            }
        }
        if (!throttleChanged) { Console.WriteLine("ERROR: throttle constant 280 not found in Scroll()"); return 1; }

        // 节流分支里的 accumulated = 0 去掉：快速滚动时保留累积，而不是整段丢弃
        Instruction[] drop = null;
        for (int k = 0; k + 2 < sins.Count; k++) {
            if (sins[k].OpCode == OpCodes.Ldarg_0 && sins[k + 1].OpCode == OpCodes.Ldc_I4_0 && sins[k + 2].OpCode == OpCodes.Stfld) {
                var fr = sins[k + 2].Operand as FieldReference;
                if (fr != null && fr.Name == "accumulated") {
                    drop = new[] { sins[k], sins[k + 1], sins[k + 2] };
                    break;
                }
            }
        }
        if (drop == null) { Console.WriteLine("ERROR: throttle reset sequence not found in Scroll()"); return 1; }
        var wil = scroll.Body.GetILProcessor();
        foreach (var d in drop) wil.Remove(d);
        Console.WriteLine("wheel throttle: 280 -> 100ms, throttle no longer clears accumulator");

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1]);
        return 0;
    }
}

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

class FullscreenTest3 : Form {
    public FullscreenTest3() {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = Screen.PrimaryScreen.Bounds;
        TopMost = false;
        ShowInTaskbar = true;
        MinimizeBox = true;
        MaximizeBox = false;
        BackColor = Color.Black;
        Text = "FS3 borderless fullscreen with taskbar button";
        var label = new Label();
        label.Text = "BORDERLESS FULLSCREEN + taskbar button\r\nWin+D should minimize this window";
        label.ForeColor = Color.Lime;
        label.Font = new Font("Consolas", 20);
        label.AutoSize = true;
        label.Location = new Point(60, 60);
        Controls.Add(label);
        Load += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs3.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " START hwnd=" + Handle.ToInt64() + "\r\n");
        };
        Resize += delegate {
            File.AppendAllText(@"D:\download\gbpatch\fs3.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " RESIZE state=" + WindowState + "\r\n");
        };
    }

    [STAThread]
    static void Main() {
        Application.EnableVisualStyles();
        Application.Run(new FullscreenTest3());
    }
}

using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch10 {
    static MethodDefinition AddPinvoke(ModuleDefinition mod, TypeDefinition t, string dll, string entry, TypeReference ret, TypeReference[] args) {
        var m = new MethodDefinition(entry,
            MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig | MethodAttributes.PInvokeImpl,
            ret);
        foreach (var a in args) m.Parameters.Add(new ParameterDefinition(a));
        ModuleReference mr = mod.ModuleReferences.FirstOrDefault(x =>
            string.Equals(x.Name, dll, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x.Name, dll + ".dll", StringComparison.OrdinalIgnoreCase));
        if (mr == null) { mr = new ModuleReference(dll + ".dll"); mod.ModuleReferences.Add(mr); }
        m.PInvokeInfo = new PInvokeInfo(PInvokeAttributes.CallConvWinapi, entry, mr);
        m.ImplAttributes |= MethodImplAttributes.PreserveSig;
        t.Methods.Add(m);
        return m;
    }

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch10 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ctrl = mod.GetType("GlassBoard.Controller");
        if (ctrl == null) { Console.WriteLine("ERROR: Controller not found"); return 1; }
        var apply = ctrl.Methods.FirstOrDefault(x => x.Name == "ApplyGameMode" && x.HasBody);
        if (apply == null) { Console.WriteLine("ERROR: ApplyGameMode not found"); return 1; }

        foreach (var i in apply.Body.Instructions) {
            if (i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "SetProcessWorkingSetSize") {
                Console.WriteLine("already patched (patch10)");
                return 0;
            }
        }

        // 找 Board.Hide() 那条 callvirt
        Instruction boardHide = null;
        foreach (var i in apply.Body.Instructions) {
            if (i.OpCode == OpCodes.Callvirt) {
                var mr = i.Operand as MethodReference;
                if (mr != null && mr.Name == "Hide") {
                    var fld = i.Previous != null ? (i.Previous.Operand as FieldReference) : null;
                    if (fld != null && fld.Name == "Board") { boardHide = i; break; }
                }
            }
        }
        if (boardHide == null) { Console.WriteLine("ERROR: Board.Hide() not found in ApplyGameMode"); return 1; }

        var tPtr = mod.TypeSystem.IntPtr;
        var getProc = AddPinvoke(mod, ctrl, "kernel32", "GetCurrentProcess", tPtr, new TypeReference[0]);
        var setWs = AddPinvoke(mod, ctrl, "kernel32", "SetProcessWorkingSetSize", mod.TypeSystem.Boolean, new[] { tPtr, tPtr, tPtr });

        // SetProcessWorkingSetSize(GetCurrentProcess(), -1, -1)  -> 让系统回收物理页
        var il = apply.Body.GetILProcessor();
        var seq = new Instruction[] {
            il.Create(OpCodes.Call, getProc),
            il.Create(OpCodes.Ldc_I4_M1),
            il.Create(OpCodes.Conv_I8),
            il.Create(OpCodes.Conv_I),
            il.Create(OpCodes.Ldc_I4_M1),
            il.Create(OpCodes.Conv_I8),
            il.Create(OpCodes.Conv_I),
            il.Create(OpCodes.Call, setWs),
            il.Create(OpCodes.Pop)
        };
        Instruction prev = boardHide;
        foreach (var i in seq) { il.InsertAfter(prev, i); prev = i; }

        if (apply.Body.MaxStackSize < 4) apply.Body.MaxStackSize = 4;

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (trim working set on game mode entry)");
        return 0;
    }
}

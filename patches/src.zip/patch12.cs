using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch12 {
    static TypeDefinition FindType(ModuleDefinition mod, string name) {
        foreach (var t in mod.Types) {
            if (t.Name == name) return t;
            foreach (var n in t.NestedTypes) if (n.Name == name) return n;
        }
        return null;
    }

    static MethodDefinition Pin(TypeDefinition fs, string n) {
        var m = fs.Methods.FirstOrDefault(x => x.Name == n && x.IsPInvokeImpl);
        if (m == null) throw new Exception("P/Invoke not found: " + n);
        return m;
    }

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch12 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var fs = mod.GetType("GlassBoard.FullscreenState");
        if (fs == null) { Console.WriteLine("ERROR: FullscreenState not found"); return 1; }
        var active = fs.Methods.FirstOrDefault(x => x.Name == "Active" && x.HasBody);
        if (active == null) { Console.WriteLine("ERROR: Active not found"); return 1; }
        bool already = false;
        foreach (var ins in active.Body.Instructions) {
            var mr = ins.Operand as MethodReference;
            if (mr != null && mr.Name == "get_AllScreens") { already = true; break; }
        }
        if (already) {
            Console.WriteLine("already patched (patch12)");
            return 0;
        }

        var rectRef = active.Body.Variables.Select(v => v.VariableType).FirstOrDefault(t => t.Name == "RECT");
        var miRef = active.Body.Variables.Select(v => v.VariableType).FirstOrDefault(t => t.Name == "MONITORINFO");
        if (rectRef == null || miRef == null) { Console.WriteLine("ERROR: RECT/MONITORINFO locals not found"); return 1; }
        var rectT = rectRef.Resolve();
        var miT = miRef.Resolve();
        if (rectT == null || miT == null) { Console.WriteLine("ERROR: RECT/MONITORINFO resolve failed"); return 1; }

        var contains = active.Body.Instructions
            .Select(i => i.Operand as MethodReference)
            .FirstOrDefault(m => m != null && m.Name == "Contains");
        if (contains == null) { Console.WriteLine("ERROR: Enumerable.Contains not found"); return 1; }

        var screenRef = mod.ImportReference(typeof(System.Windows.Forms.Screen));
        var drawRect = mod.ImportReference(typeof(System.Drawing.Rectangle));
        var allScreens = mod.ImportReference(typeof(System.Windows.Forms.Screen).GetProperty("AllScreens").GetGetMethod());
        var boundsGetter = mod.ImportReference(typeof(System.Windows.Forms.Screen).GetProperty("Bounds").GetGetMethod());
        var fx = mod.ImportReference(typeof(System.Drawing.Rectangle).GetProperty("X").GetGetMethod());
        var fy = mod.ImportReference(typeof(System.Drawing.Rectangle).GetProperty("Y").GetGetMethod());
        var fw = mod.ImportReference(typeof(System.Drawing.Rectangle).GetProperty("Width").GetGetMethod());
        var fh = mod.ImportReference(typeof(System.Drawing.Rectangle).GetProperty("Height").GetGetMethod());
        var sbCtor = mod.ImportReference(typeof(System.Text.StringBuilder).GetConstructor(new[] { typeof(int) }));
        var objToString = mod.ImportReference(typeof(object).GetMethod("ToString", Type.EmptyTypes));
        var intPtrEq = mod.ImportReference(typeof(IntPtr).GetMethod("op_Equality", new[] { typeof(IntPtr), typeof(IntPtr) }));
        var intPtrZero = mod.ImportReference(typeof(IntPtr).GetField("Zero"));
        var procCurrent = mod.ImportReference(typeof(System.Diagnostics.Process).GetMethod("GetCurrentProcess", Type.EmptyTypes));
        var procId = mod.ImportReference(typeof(System.Diagnostics.Process).GetProperty("Id").GetGetMethod());
        var marshalSizeOf = mod.ImportReference(typeof(System.Runtime.InteropServices.Marshal).GetMethod("SizeOf", new[] { typeof(Type) }));
        var typeGetFromHandle = mod.ImportReference(typeof(Type).GetMethod("GetTypeFromHandle", new[] { typeof(RuntimeTypeHandle) }));
        bool debug = args.Length > 2;
        var storeLog = debug ? mod.GetType("GlassBoard.Store").Methods.First(m => m.Name == "Log") : null;

        var miSize = miT.Fields.First(f => f.Name == "Size");
        var miMonitor = miT.Fields.First(f => f.Name == "Monitor");
        var rLeft = rectT.Fields.First(f => f.Name == "Left");
        var rTop = rectT.Fields.First(f => f.Name == "Top");
        var rRight = rectT.Fields.First(f => f.Name == "Right");
        var rBottom = rectT.Fields.First(f => f.Name == "Bottom");

        var vHwnd = new VariableDefinition(mod.TypeSystem.IntPtr);
        var vPid = new VariableDefinition(mod.TypeSystem.UInt32);
        var vCls = new VariableDefinition(mod.ImportReference(typeof(System.Text.StringBuilder)));
        var vRect = new VariableDefinition(rectRef);
        var vMi = new VariableDefinition(miRef);
        var vScreens = new VariableDefinition(new ArrayType(screenRef));
        var vI = new VariableDefinition(mod.TypeSystem.Int32);
        var vScreen = new VariableDefinition(screenRef);
        var vBounds = new VariableDefinition(drawRect);

        var il = active.Body.GetILProcessor();
        active.Body.Instructions.Clear();
        active.Body.Variables.Clear();
        active.Body.ExceptionHandlers.Clear();
        active.Body.InitLocals = true;
        active.Body.MaxStackSize = 8;
        foreach (var v in new[] { vHwnd, vPid, vCls, vRect, vMi, vScreens, vI, vScreen, vBounds }) active.Body.Variables.Add(v);

        var loop = il.Create(OpCodes.Ldloc, vI);
        var nextInc = il.Create(OpCodes.Ldloc, vI);
        var end = il.Create(OpCodes.Ldc_I4_0);

        Action<OpCode> E0 = op => il.Append(il.Create(op));
        Action<OpCode, Instruction> E1 = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, VariableDefinition> EV = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, MethodReference> EM = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, FieldReference> EF = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, TypeReference> ET = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, sbyte> ES = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, int> EN = (op, t) => il.Append(il.Create(op, t));
        Action<OpCode, string> EStr = (op, t) => il.Append(il.Create(op, t));
        Action logBool = () => {
            if (debug) {
                E0(OpCodes.Dup);
                ET(OpCodes.Box, mod.TypeSystem.Boolean);
                EM(OpCodes.Call, storeLog);
            }
        };

        // screens = Screen.AllScreens; i = 0
        EM(OpCodes.Call, allScreens);
        EV(OpCodes.Stloc, vScreens);
        if (debug) {
            EV(OpCodes.Ldloc, vScreens);
            E0(OpCodes.Ldlen);
            E0(OpCodes.Conv_I4);
            ET(OpCodes.Box, mod.TypeSystem.Int32);
            EM(OpCodes.Call, storeLog);
        }
        E0(OpCodes.Ldc_I4_0);
        EV(OpCodes.Stloc, vI);

        // loop: if (i >= screens.Length) return false
        il.Append(loop);
        EV(OpCodes.Ldloc, vScreens);
        E0(OpCodes.Ldlen);
        E0(OpCodes.Conv_I4);
        E1(OpCodes.Bge, end);

        // screen = screens[i]; bounds = screen.Bounds
        EV(OpCodes.Ldloc, vScreens);
        EV(OpCodes.Ldloc, vI);
        E0(OpCodes.Ldelem_Ref);
        EV(OpCodes.Stloc, vScreen);
        EV(OpCodes.Ldloc, vScreen);
        EM(OpCodes.Callvirt, boundsGetter);
        EV(OpCodes.Stloc, vBounds);

        // hwnd = GetAncestor(WindowFromPoint(((long)cy << 32) | (uint)cx), GA_ROOT)
        EV(OpCodes.Ldloca, vBounds);
        EM(OpCodes.Call, fy);
        EV(OpCodes.Ldloca, vBounds);
        EM(OpCodes.Call, fh);
        E0(OpCodes.Ldc_I4_2);
        E0(OpCodes.Div);
        E0(OpCodes.Add);
        E0(OpCodes.Conv_I8);
        ES(OpCodes.Ldc_I4_S, (sbyte)32);
        E0(OpCodes.Shl);
        EV(OpCodes.Ldloca, vBounds);
        EM(OpCodes.Call, fx);
        EV(OpCodes.Ldloca, vBounds);
        EM(OpCodes.Call, fw);
        E0(OpCodes.Ldc_I4_2);
        E0(OpCodes.Div);
        E0(OpCodes.Add);
        E0(OpCodes.Conv_U4);   // 副屏 X 可能为负，先零扩展低 32 位
        E0(OpCodes.Conv_U8);
        E0(OpCodes.Or);
        EM(OpCodes.Call, Pin(fs, "WindowFromPoint"));
        E0(OpCodes.Ldc_I4_2);
        EM(OpCodes.Call, Pin(fs, "GetAncestor"));
        EV(OpCodes.Stloc, vHwnd);
        if (debug) {
            EV(OpCodes.Ldloc, vHwnd);
            ET(OpCodes.Box, mod.TypeSystem.IntPtr);
            EM(OpCodes.Call, storeLog);
        }

        // if (hwnd == 0) continue
        EV(OpCodes.Ldloc, vHwnd);
        EF(OpCodes.Ldsfld, intPtrZero);
        EM(OpCodes.Call, intPtrEq);
                logBool();
        E1(OpCodes.Brtrue, nextInc);

        // pid = GetWindowThreadProcessId(hwnd); if (pid == current) continue
        EV(OpCodes.Ldloc, vHwnd);
        EV(OpCodes.Ldloca, vPid);
        EM(OpCodes.Call, Pin(fs, "GetWindowThreadProcessId"));
        E0(OpCodes.Pop);
        EV(OpCodes.Ldloc, vPid);
        EM(OpCodes.Call, procCurrent);
        EM(OpCodes.Callvirt, procId);
                logBool();
        E1(OpCodes.Beq, nextInc);

        // cls = new StringBuilder(256); GetClassName(hwnd, cls, 256)
        EN(OpCodes.Ldc_I4, 256);
        EM(OpCodes.Newobj, sbCtor);
        EV(OpCodes.Stloc, vCls);
        EV(OpCodes.Ldloc, vHwnd);
        EV(OpCodes.Ldloc, vCls);
        EN(OpCodes.Ldc_I4, 256);
        EM(OpCodes.Call, Pin(fs, "GetClassName"));
        E0(OpCodes.Pop);

        // if (黑名单.Contains(cls.ToString())) continue
        E0(OpCodes.Ldc_I4_4);
        ET(OpCodes.Newarr, mod.TypeSystem.String);
        E0(OpCodes.Dup);
        E0(OpCodes.Ldc_I4_0);
        EStr(OpCodes.Ldstr, "Progman");
        E0(OpCodes.Stelem_Ref);
        E0(OpCodes.Dup);
        E0(OpCodes.Ldc_I4_1);
        EStr(OpCodes.Ldstr, "WorkerW");
        E0(OpCodes.Stelem_Ref);
        E0(OpCodes.Dup);
        E0(OpCodes.Ldc_I4_2);
        EStr(OpCodes.Ldstr, "Shell_TrayWnd");
        E0(OpCodes.Stelem_Ref);
        E0(OpCodes.Dup);
        E0(OpCodes.Ldc_I4_3);
        EStr(OpCodes.Ldstr, "Shell_SecondaryTrayWnd");
        E0(OpCodes.Stelem_Ref);
        EV(OpCodes.Ldloc, vCls);
        EM(OpCodes.Callvirt, objToString);
        EM(OpCodes.Call, contains);
                logBool();
        E1(OpCodes.Brtrue, nextInc);

        // if ((GetWindowLongW(hwnd, -16) & 0x00C00000) != 0) continue
        EV(OpCodes.Ldloc, vHwnd);
        ES(OpCodes.Ldc_I4_S, (sbyte)-16);
        EM(OpCodes.Call, Pin(fs, "GetWindowLongW"));
        EN(OpCodes.Ldc_I4, 12582912);
        E0(OpCodes.And);
                logBool();
        E1(OpCodes.Brtrue, nextInc);

        // if (!GetWindowRect(hwnd, ref rect)) continue
        EV(OpCodes.Ldloc, vHwnd);
        EV(OpCodes.Ldloca, vRect);
        EM(OpCodes.Call, Pin(fs, "GetWindowRect"));
                logBool();
        E1(OpCodes.Brfalse, nextInc);

        // mi = default; mi.Size = sizeof(MONITORINFO)
        EV(OpCodes.Ldloca, vMi);
        ET(OpCodes.Initobj, miT);
        EV(OpCodes.Ldloca, vMi);
        ET(OpCodes.Ldtoken, miT);
        EM(OpCodes.Call, typeGetFromHandle);
        EM(OpCodes.Call, marshalSizeOf);
        EF(OpCodes.Stfld, miSize);

        // if (!GetMonitorInfo(MonitorFromWindow(hwnd, 2), ref mi)) continue
        EV(OpCodes.Ldloc, vHwnd);
        E0(OpCodes.Ldc_I4_2);
        EM(OpCodes.Call, Pin(fs, "MonitorFromWindow"));
        EV(OpCodes.Ldloca, vMi);
        EM(OpCodes.Call, Pin(fs, "GetMonitorInfo"));
                logBool();
        E1(OpCodes.Brfalse, nextInc);

        // rect 必须完整覆盖该窗口所在显示器
        EV(OpCodes.Ldloca, vRect); EF(OpCodes.Ldfld, rLeft);
        EV(OpCodes.Ldloca, vMi); EF(OpCodes.Ldflda, miMonitor); EF(OpCodes.Ldfld, rLeft);
                logBool();
        E1(OpCodes.Bgt, nextInc);
        EV(OpCodes.Ldloca, vRect); EF(OpCodes.Ldfld, rTop);
        EV(OpCodes.Ldloca, vMi); EF(OpCodes.Ldflda, miMonitor); EF(OpCodes.Ldfld, rTop);
                logBool();
        E1(OpCodes.Bgt, nextInc);
        EV(OpCodes.Ldloca, vRect); EF(OpCodes.Ldfld, rRight);
        EV(OpCodes.Ldloca, vMi); EF(OpCodes.Ldflda, miMonitor); EF(OpCodes.Ldfld, rRight);
                logBool();
        E1(OpCodes.Blt, nextInc);
        EV(OpCodes.Ldloca, vRect); EF(OpCodes.Ldfld, rBottom);
        EV(OpCodes.Ldloca, vMi); EF(OpCodes.Ldflda, miMonitor); EF(OpCodes.Ldfld, rBottom);
                logBool();
        E1(OpCodes.Blt, nextInc);

        // 兜底：前台是桌面时最小化该全屏窗口
        var skipMin = il.Create(OpCodes.Ldc_I4_1);
        EM(OpCodes.Call, Pin(fs, "GetForegroundWindow"));
        EM(OpCodes.Call, Pin(fs, "GetShellWindow"));
        EM(OpCodes.Call, intPtrEq);
        E1(OpCodes.Brfalse, skipMin);
        EV(OpCodes.Ldloc, vHwnd);
        E0(OpCodes.Ldc_I4_6);
        EM(OpCodes.Call, Pin(fs, "ShowWindow"));
        E0(OpCodes.Pop);
        il.Append(skipMin);
        E0(OpCodes.Ret);

        // nextInc: i++; goto loop
        il.Append(nextInc);
        E0(OpCodes.Ldc_I4_1);
        E0(OpCodes.Add);
        EV(OpCodes.Stloc, vI);
        E1(OpCodes.Br, loop);

        // end: return false
        il.Append(end);
        E0(OpCodes.Ret);

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (probe every monitor center)");
        return 0;
    }
}

using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch9 {
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch9 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ctrl = mod.GetType("GlassBoard.Controller");
        if (ctrl == null) { Console.WriteLine("ERROR: Controller not found"); return 1; }
        var settings = ctrl.Methods.FirstOrDefault(x => x.Name == "Settings" && x.HasBody);
        if (settings == null) { Console.WriteLine("ERROR: Settings not found"); return 1; }
        var ins = settings.Body.Instructions;

        Instruction anchor = null;
        foreach (var i in ins) {
            if (i.OpCode == OpCodes.Stfld) {
                var fr = i.Operand as FieldReference;
                if (fr != null && fr.Name == "creatorPage") { anchor = i; break; }
            }
        }
        if (anchor == null) { Console.WriteLine("ERROR: creatorPage assignment not found"); return 1; }

        MethodReference getItems = null;
        foreach (var i in ins) {
            var mr = i.Operand as MethodReference;
            if (mr != null && mr.Name == "get_Items" && mr.DeclaringType != null && mr.DeclaringType.Name == "ItemsControl") { getItems = mr; break; }
        }
        if (getItems == null) { Console.WriteLine("ERROR: ItemsControl.get_Items not found"); return 1; }
        var itemCollType = getItems.ReturnType;

        // 手工构造 ItemCollection.Remove(object)
        var removeRef = new MethodReference("Remove", mod.TypeSystem.Void, itemCollType);
        removeRef.HasThis = true;
        removeRef.Parameters.Add(new ParameterDefinition(mod.TypeSystem.Object));

        var il = settings.Body.GetILProcessor();
        var seq = new Instruction[] {
            il.Create(OpCodes.Ldloc_2),              // closure
            il.Create(OpCodes.Ldfld, getItems.DeclaringType.Name == "ItemsControl" ? GetTabsField(anchor) : GetTabsField(anchor)),
            il.Create(OpCodes.Callvirt, getItems),
            il.Create(OpCodes.Ldloc_2),
            il.Create(OpCodes.Ldfld, (FieldReference)anchor.Operand),
            il.Create(OpCodes.Callvirt, removeRef),
            il.Create(OpCodes.Pop)
        };
        Instruction prev = anchor;
        foreach (var i in seq) { il.InsertAfter(prev, i); prev = i; }

        // 兜底：把选择索引上限从 5 改成 4（Tab 少了一个）
        int clamped = 0;
        foreach (var i in ins) {
            if (i.OpCode == OpCodes.Ldc_I4_5 && i.Next != null && i.Next.OpCode == OpCodes.Ldarg_1 && i.Next.Next != null && i.Next.Next.OpCode == OpCodes.Call && ((MethodReference)i.Next.Next.Operand).Name == "Min") {
                i.OpCode = OpCodes.Ldc_I4_4;
                clamped++;
            }
        }
        Console.WriteLine("clamped index constants: " + clamped);

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (creator tab removed from Items)");
        return 0;
    }

    static FieldReference GetTabsField(Instruction anchor) {
        // 在同一方法里找 <>c__DisplayClass78_1::tabs 的字段引用
        foreach (var i in anchor.Method.Body.Instructions) {
            var fr = i.Operand as FieldReference;
            if (fr != null && fr.Name == "tabs") return fr;
        }
        return null;
    }
}

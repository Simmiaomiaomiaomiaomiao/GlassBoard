using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch {
    static int Main(string[] args) {
        string src = args[0];
        string dst = args[1];
        var asm = AssemblyDefinition.ReadAssembly(src);
        var fs = asm.MainModule.GetType("GlassBoard.FullscreenState");
        if (fs == null) { Console.WriteLine("FullscreenState not found"); return 1; }
        var active = fs.Methods.FirstOrDefault(x => x.Name == "Active" && x.HasBody);
        if (active == null) { Console.WriteLine("Active not found"); return 1; }
        var dv = asm.MainModule.GetType("GlassBoard.DesktopVisibility");
        var isVisible = dv.Methods.FirstOrDefault(x => x.Name == "IsWindowVisible");
        if (isVisible == null) { Console.WriteLine("IsWindowVisible not found"); return 1; }

        // 已经打过补丁就不重复插入
        foreach (var i in active.Body.Instructions) {
            if (i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "IsWindowVisible") {
                Console.WriteLine("already patched");
                return 0;
            }
        }

        // IsWindowVisible 原本是 private，跨类调用会抛 MemberAccessException，改为 public
        isVisible.Attributes = (isVisible.Attributes & ~Mono.Cecil.MethodAttributes.MemberAccessMask) | Mono.Cecil.MethodAttributes.Public;
        Console.WriteLine("IsWindowVisible visibility -> " + isVisible.Attributes);

        var il = active.Body.GetILProcessor();
        Instruction stloc0 = active.Body.Instructions.First(x => x.OpCode == OpCodes.Stloc_0);
        Instruction target = stloc0.Next;

        var l1 = il.Create(OpCodes.Ldloc_0);
        var l2 = il.Create(OpCodes.Call, isVisible);
        var l3 = il.Create(OpCodes.Brtrue_S, target);
        var l4 = il.Create(OpCodes.Ldc_I4_0);
        var l5 = il.Create(OpCodes.Ret);

        il.InsertAfter(stloc0, l1);
        il.InsertAfter(l1, l2);
        il.InsertAfter(l2, l3);
        il.InsertAfter(l3, l4);
        il.InsertAfter(l4, l5);

        asm.Write(dst);
        Console.WriteLine("patched -> " + dst);
        return 0;
    }
}

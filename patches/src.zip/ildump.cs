using System;
using Mono.Cecil;
using Mono.Cecil.Cil;

class IlDump {
    static void Main(string[] args) {
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        string filter = args.Length > 1 ? args[1] : "";
        foreach (var t in asm.MainModule.Types) DumpType(t, filter);
    }

    static void DumpType(TypeDefinition t, string filter) {
        foreach (var n in t.NestedTypes) DumpType(n, filter);
        foreach (var m in t.Methods) {
            string full = t.FullName + "." + m.Name;
            if (filter.Length > 0 && full.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) continue;
            if (!m.HasBody) continue;
            Console.WriteLine("==== " + full + " (" + m.ReturnType.Name + ")");
            foreach (var v in m.Body.Variables) Console.WriteLine("  .local " + v.Index + " " + v.VariableType.Name);
            foreach (var i in m.Body.Instructions) {
                string op = i.OpCode.Name;
                string operand = "";
                if (i.Operand != null) {
                    MethodReference mr = i.Operand as MethodReference;
                    FieldReference fr = i.Operand as FieldReference;
                    TypeReference tr = i.Operand as TypeReference;
                    string s = i.Operand as string;
                    if (mr != null) operand = mr.DeclaringType.Name + "::" + mr.Name;
                    else if (fr != null) operand = fr.DeclaringType.Name + "::" + fr.Name;
                    else if (tr != null) operand = tr.Name;
                    else if (s != null) operand = "\"" + s + "\"";
                    else operand = i.Operand.ToString();
                }
                Console.WriteLine("  IL_" + i.Offset.ToString("X4") + ": " + op + " " + operand);
            }
            Console.WriteLine();
        }
    }
}

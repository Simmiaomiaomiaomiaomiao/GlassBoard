using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch2 {
    static MethodDefinition AddPinvoke(ModuleDefinition mod, TypeDefinition t, string name, TypeReference ret, TypeReference[] args) {
        var m = new MethodDefinition(name,
            MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig | MethodAttributes.PInvokeImpl,
            ret);
        foreach (var a in args) m.Parameters.Add(new ParameterDefinition(a));
        ModuleReference mr = mod.ModuleReferences.FirstOrDefault(x => x.Name == "user32");
        if (mr == null) { mr = new ModuleReference("user32"); mod.ModuleReferences.Add(mr); }
        m.PInvokeInfo = new PInvokeInfo(PInvokeAttributes.CallConvWinapi, name, mr);
        m.ImplAttributes |= MethodImplAttributes.PreserveSig;
        t.Methods.Add(m);
        return m;
    }

    static int Main(string[] args) {
        string src = args[0], dst = args[1];
        var asm = AssemblyDefinition.ReadAssembly(src);
        var mod = asm.MainModule;
        var fs = mod.GetType("GlassBoard.FullscreenState");
        var active = fs.Methods.First(x => x.Name == "Active" && x.HasBody);

        if (active.Body.Instructions.Any(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "WindowFromPoint")) {
            Console.WriteLine("already patched");
            return 0;
        }

        var tInt = mod.TypeSystem.Int32;
        var tLong = mod.TypeSystem.Int64;
        var tPtr = mod.TypeSystem.IntPtr;
        var sm = AddPinvoke(mod, fs, "GetSystemMetrics", tInt, new[] { tInt });
        var wfp = AddPinvoke(mod, fs, "WindowFromPoint", tPtr, new[] { tLong });
        var anc = AddPinvoke(mod, fs, "GetAncestor", tPtr, new[] { tPtr, tInt });

        var il = active.Body.GetILProcessor();
        var old = active.Body.Instructions[0];   // call GetForegroundWindow

        var seq = new Instruction[] {
            il.Create(OpCodes.Ldc_I4_1),                       // SM_CYSCREEN
            il.Create(OpCodes.Call, sm),
            il.Create(OpCodes.Ldc_I4_2),
            il.Create(OpCodes.Div),                            // cy/2
            il.Create(OpCodes.Conv_I8),
            il.Create(OpCodes.Ldc_I4_S, (sbyte)32),
            il.Create(OpCodes.Shl),                            // (long)(cy/2) << 32
            il.Create(OpCodes.Ldc_I4_0),                       // SM_CXSCREEN
            il.Create(OpCodes.Call, sm),
            il.Create(OpCodes.Ldc_I4_2),
            il.Create(OpCodes.Div),                            // cx/2
            il.Create(OpCodes.Conv_U8),
            il.Create(OpCodes.Or),                             // packed POINT as long
            il.Create(OpCodes.Call, wfp),                      // WindowFromPoint(center)
            il.Create(OpCodes.Ldc_I4_2),                       // GA_ROOT
            il.Create(OpCodes.Call, anc)                       // -> top level window at screen center
        };

        Instruction prev = null;
        foreach (var ins in seq) {
            if (prev == null) il.InsertBefore(old, ins);
            else il.InsertAfter(prev, ins);
            prev = ins;
        }
        il.Remove(old);
        if (active.Body.MaxStackSize < 4) active.Body.MaxStackSize = 4;

        asm.Write(dst);
        Console.WriteLine("patched -> " + dst);
        return 0;
    }
}

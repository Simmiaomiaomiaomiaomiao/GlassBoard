using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class ListSama {
    static void Main(string[] args) {
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        foreach (var t in mod.Types) {
            foreach (var m in t.Methods) {
                if (!m.HasBody) continue;
                foreach (var ins in m.Body.Instructions) {
                    if (ins.OpCode != OpCodes.Ldstr) continue;
                    string s = ins.Operand as string;
                    if (s != null && s.IndexOf("Sama", StringComparison.OrdinalIgnoreCase) >= 0) {
                        Console.WriteLine(t.Name + "." + m.Name + "  ==>  [" + s + "]");
                    }
                }
            }
        }
    }
}

using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch6 {
    static MethodDefinition AddPinvoke(ModuleDefinition mod, TypeDefinition t, string entry, TypeReference ret, TypeReference[] args) {
        var m = new MethodDefinition(entry,
            MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig | MethodAttributes.PInvokeImpl,
            ret);
        foreach (var a in args) m.Parameters.Add(new ParameterDefinition(a));
        ModuleReference mr = mod.ModuleReferences.FirstOrDefault(x =>
            string.Equals(x.Name, "user32", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(x.Name, "user32.dll", StringComparison.OrdinalIgnoreCase));
        if (mr == null) { mr = new ModuleReference("user32.dll"); mod.ModuleReferences.Add(mr); }
        m.PInvokeInfo = new PInvokeInfo(PInvokeAttributes.CallConvWinapi, entry, mr);
        m.ImplAttributes |= MethodImplAttributes.PreserveSig;
        t.Methods.Add(m);
        return m;
    }

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch6 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var fs = mod.GetType("GlassBoard.FullscreenState");
        if (fs == null) { Console.WriteLine("ERROR: FullscreenState not found"); return 1; }
        var active = fs.Methods.FirstOrDefault(x => x.Name == "Active" && x.HasBody);
        if (active == null) { Console.WriteLine("ERROR: Active() not found"); return 1; }

        var ins = active.Body.Instructions;
        // 必须已经打过 patch5（有 WindowFromPoint）
        if (!ins.Any(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "WindowFromPoint")) {
            Console.WriteLine("ERROR: patch5 not detected, apply patch5 first");
            return 1;
        }
        if (ins.Any(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "GetShellWindow")) {
            Console.WriteLine("already patched (patch6)");
            return 0;
        }

        // 定位返回 true 的那条 ret：ceq 后紧跟 ret
        Instruction retTrue = null;
        for (int i = 0; i + 2 < ins.Count; i++) {
            if (ins[i].OpCode == OpCodes.Ceq && ins[i + 1].OpCode == OpCodes.Ret) {
                retTrue = ins[i + 1];
            }
        }
        if (retTrue == null) { Console.WriteLine("ERROR: true-return point not found"); return 1; }
        Instruction falseTarget = retTrue.Next;
        if (falseTarget == null || falseTarget.OpCode != OpCodes.Ldc_I4_0) {
            Console.WriteLine("ERROR: unexpected instruction after true-return"); return 1;
        }

        Instruction eqIns = ins.FirstOrDefault(i => i.Operand is MethodReference && ((MethodReference)i.Operand).Name == "op_Equality"
            && ((MethodReference)i.Operand).DeclaringType.Name == "IntPtr");
        if (eqIns == null) { Console.WriteLine("ERROR: IntPtr.op_Equality reference not found"); return 1; }
        var eqRef = (MethodReference)eqIns.Operand;

        var tInt = mod.TypeSystem.Int32;
        var tPtr = mod.TypeSystem.IntPtr;
        var getFg = AddPinvoke(mod, fs, "GetForegroundWindow", tPtr, new TypeReference[0]);
        var getShell = AddPinvoke(mod, fs, "GetShellWindow", tPtr, new TypeReference[0]);
        var showWin = AddPinvoke(mod, fs, "ShowWindow", mod.TypeSystem.Boolean, new[] { tPtr, tInt });

        var il = active.Body.GetILProcessor();
        var tail = il.Create(OpCodes.Ldc_I4_1);     // 真正的 "return true"

        var seq = new Instruction[] {
            il.Create(OpCodes.Brfalse_S, falseTarget),   // 矩形不覆盖 → 返回 false
            il.Create(OpCodes.Call, getFg),              // 前台窗口
            il.Create(OpCodes.Call, getShell),           // 桌面(Progman)窗口
            il.Create(OpCodes.Call, eqRef),              // 前台是不是桌面
            il.Create(OpCodes.Brfalse_S, tail),          // 不是桌面 → 直接 true
            il.Create(OpCodes.Ldloc_0),                  // 是桌面：把仍占屏的全屏窗口最小化
            il.Create(OpCodes.Ldc_I4_6),                 // SW_MINIMIZE
            il.Create(OpCodes.Call, showWin),
            il.Create(OpCodes.Pop),
            tail,
            il.Create(OpCodes.Ret)
        };

        Instruction prev = null;
        foreach (var i in seq) {
            if (prev == null) il.InsertBefore(retTrue, i);
            else il.InsertAfter(prev, i);
            prev = i;
        }
        il.Remove(retTrue);

        if (active.Body.MaxStackSize < 4) active.Body.MaxStackSize = 4;

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1]);
        return 0;
    }
}

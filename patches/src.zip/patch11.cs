using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch11 {
    // 桌面层窗口的 z-order：RefreshOrder 在前台是桌面时用 HWND_TOP 把 Dock/组件/面板提到
    // 所有普通窗口之上，导致点一下桌面，这些窗口就盖住仍然显示的小窗。
    // 改为与另一分支一致，统一 HWND_BOTTOM，保持"桌面层"语义（owner 是 shell window，
    // 窗口仍在桌面之上，但不会越过其它窗口）。
    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch11 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var t = mod.GetType("GlassBoard.DesktopPersistence");
        if (t == null) { Console.WriteLine("ERROR: DesktopPersistence not found"); return 1; }
        var m = t.Methods.FirstOrDefault(x => x.Name == "RefreshOrder" && x.HasBody);
        if (m == null) { Console.WriteLine("ERROR: RefreshOrder not found"); return 1; }

        var il = m.Body.GetILProcessor();
        Instruction setPos = null;
        foreach (var i in m.Body.Instructions) {
            if (i.OpCode == OpCodes.Call) {
                var mr = i.Operand as MethodReference;
                if (mr != null && mr.DeclaringType.Name == "DesktopPersistence" && mr.Name == "SetWindowPos") { setPos = i; break; }
            }
        }
        if (setPos == null) { Console.WriteLine("ERROR: SetWindowPos call not found"); return 1; }

        // 紧挨 SetWindowPos 之前压入 hWndInsertAfter 的 ldsfld System.IntPtr::Zero 就是 HWND_TOP 分支
        Instruction top = null;
        for (var i = setPos.Previous; i != null; i = i.Previous) {
            if (i.OpCode == OpCodes.Ldsfld) {
                var fr = i.Operand as FieldReference;
                if (fr != null && fr.Name == "Zero" && fr.DeclaringType.FullName == "System.IntPtr") { top = i; break; }
            }
            if (i.OpCode == OpCodes.Ldloc_1) break;   // 已越过整段参数压栈
        }
        if (top == null) { Console.WriteLine("already patched (patch11)"); return 0; }

        var intPtrCtor = mod.ImportReference(typeof(IntPtr).GetConstructor(new[] { typeof(int) }));
        var ldc = il.Create(OpCodes.Ldc_I4_1);            // HWND_BOTTOM
        var ctor = il.Create(OpCodes.Newobj, intPtrCtor);

        // 分支目标指向这条 ldsfld（brtrue.s），替换前先重定向，避免留下悬空引用
        foreach (var i in m.Body.Instructions) {
            if (i.Operand == top) i.Operand = ldc;
        }
        il.InsertBefore(top, ldc);
        il.InsertBefore(top, ctor);
        il.Remove(top);

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (desktop foreground keeps glass windows at HWND_BOTTOM)");
        return 0;
    }
}

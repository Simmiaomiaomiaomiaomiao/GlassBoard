using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch13 {
    // 手动 + 自动游戏模式同时开启时 Dock 会一直隐藏（Suppressed = manual || (auto && fullscreen)）。
    // 在设置页"游戏模式"说明文字末尾补一句提示。
    const string Suffix = "\n提示：手动开关与自动检测请二选一，同时开启时手动开关会让 Dock 一直隐藏。";

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch13 <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var ctrl = mod.GetType("GlassBoard.Controller");
        if (ctrl == null) { Console.WriteLine("ERROR: Controller not found"); return 1; }
        var build = ctrl.Methods.FirstOrDefault(x => x.Name == "BuildGameSettings" && x.HasBody);
        if (build == null) { Console.WriteLine("ERROR: BuildGameSettings not found"); return 1; }

        Instruction target = null;
        string current = null;
        foreach (var i in build.Body.Instructions) {
            if (i.OpCode == OpCodes.Ldstr) {
                var s = i.Operand as string;
                if (s != null && s.StartsWith("游戏模式期间玻璃窗口完全隐藏")) { target = i; current = s; break; }
            }
        }
        if (target == null) { Console.WriteLine("ERROR: game mode description not found"); return 1; }
        if (current.Contains("请二选一")) { Console.WriteLine("already patched (patch13)"); return 0; }

        target.Operand = current + Suffix;

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (game mode mutex hint)");
        return 0;
    }
}

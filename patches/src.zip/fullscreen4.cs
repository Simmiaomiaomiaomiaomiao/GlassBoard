using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

class FullscreenTest4 : Form {
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr SetActiveWindow(IntPtr h);

    public FullscreenTest4() {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = Screen.PrimaryScreen.Bounds;
        TopMost = false;
        ShowInTaskbar = true;
        BackColor = Color.Black;
        Text = "FS4 borderless fullscreen";
        var label = new Label();
        label.Text = "BORDERLESS FULLSCREEN (self-activated)";
        label.ForeColor = Color.Lime;
        label.Font = new Font("Consolas", 20);
        label.AutoSize = true;
        label.Location = new Point(60, 60);
        Controls.Add(label);
        Shown += delegate {
            BringWindowToTop(Handle);
            SetForegroundWindow(Handle);
            SetActiveWindow(Handle);
            File.AppendAllText(@"D:\download\gbpatch\fs4.log",
                DateTime.Now.ToString("HH:mm:ss.fff") + " SHOWN hwnd=" + Handle.ToInt64() + " fg=" + GetForegroundWindow().ToInt64() + "\r\n");
        };
    }

    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();

    [STAThread]
    static void Main() {
        Application.EnableVisualStyles();
        Application.Run(new FullscreenTest4());
    }
}

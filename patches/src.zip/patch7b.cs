using System;
using System.Collections.Generic;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class Patch7b {
    // 只处理这 4 个界面文案；更新用的 SENLIN-SAMA URL 一律不动
    static readonly string[,] Targets = {
        { "BoardWindow", "MoreMenu" },
        { "BoardWindow", "Build" },
        { "Controller", "ShowCreatorImage" },
        { "Controller", "BuildCreatorSupport" }
    };

    static int Main(string[] args) {
        if (args.Length < 2) { Console.WriteLine("usage: patch7b <src.exe> <dst.exe>"); return 2; }
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var mod = asm.MainModule;
        var done = new Dictionary<string, bool>();
        int cleared = 0;

        for (int k = 0; k < Targets.GetLength(0); k++) {
            string typeName = Targets[k, 0];
            string methodName = Targets[k, 1];
            var t = mod.GetType("GlassBoard." + typeName);
            if (t == null) { Console.WriteLine("ERROR: type not found " + typeName); return 1; }
            var m = t.Methods.FirstOrDefault(x => x.Name == methodName && x.HasBody);
            if (m == null) { Console.WriteLine("ERROR: method not found " + typeName + "." + methodName); return 1; }
            foreach (var ins in m.Body.Instructions) {
                if (ins.OpCode != OpCodes.Ldstr) continue;
                string s = ins.Operand as string;
                if (s != null && s.IndexOf("sama", StringComparison.OrdinalIgnoreCase) >= 0) {
                    ins.Operand = "";
                    cleared++;
                    done[typeName + "." + methodName] = true;
                }
            }
        }

        if (cleared == 0) { Console.WriteLine("ERROR: nothing cleared"); return 1; }
        foreach (var kv in done) Console.WriteLine("cleared " + kv.Key);

        asm.Write(args[1]);
        Console.WriteLine("patched -> " + args[1] + " (" + cleared + " strings)");
        return 0;
    }
}

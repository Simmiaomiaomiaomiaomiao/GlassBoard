using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class DumpSettings {
    static void Main(string[] args) {
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var t = asm.MainModule.GetType("GlassBoard.Controller");
        var m = t.Methods.First(x => x.Name == "Settings" && x.HasBody);
        Console.WriteLine("Settings IL count = " + m.Body.Instructions.Count);
        int n = 0;
        foreach (var i in m.Body.Instructions) {
            n++;
            if (i.OpCode == OpCodes.Ldstr) {
                Console.WriteLine("  [" + n + "] IL_" + i.Offset.ToString("X4") + " ldstr [" + i.Operand + "]");
            }
        }
    }
}
